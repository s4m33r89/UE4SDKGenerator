// Battlegrounds Mobile India (1.8.0) SDK by Dyno

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Client.AsyncLoadHelper.SetMaxTaskNum
// ()
// Parameters:
// int                            Num                            (Parm, ZeroConstructor, IsPlainOldData)

void UAsyncLoadHelper::SetMaxTaskNum(int Num)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncLoadHelper.SetMaxTaskNum");

	UAsyncLoadHelper_SetMaxTaskNum_Params params;
	params.Num = Num;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AsyncLoadHelper.RunNextTask
// ()

void UAsyncLoadHelper::RunNextTask()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncLoadHelper.RunNextTask");

	UAsyncLoadHelper_RunNextTask_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AsyncLoadHelper.OnLoadCallBack
// ()
// Parameters:
// struct FSoftObjectPath         softObjPath                    (Parm)

void UAsyncLoadHelper::OnLoadCallBack(const struct FSoftObjectPath& softObjPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncLoadHelper.OnLoadCallBack");

	UAsyncLoadHelper_OnLoadCallBack_Params params;
	params.softObjPath = softObjPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AsyncLoadHelper.ClearOneTask
// ()
// Parameters:
// struct FString                 ObjectPath                     (Parm, ZeroConstructor)

void UAsyncLoadHelper::ClearOneTask(const struct FString& ObjectPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncLoadHelper.ClearOneTask");

	UAsyncLoadHelper_ClearOneTask_Params params;
	params.ObjectPath = ObjectPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AsyncLoadHelper.ClearAllTask
// ()

void UAsyncLoadHelper::ClearAllTask()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncLoadHelper.ClearAllTask");

	UAsyncLoadHelper_ClearAllTask_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AsyncLoadHelper.AddTask
// ()
// Parameters:
// struct FString                 ObjectPath                     (Parm, ZeroConstructor)
// int                            LoadPriority                   (Parm, ZeroConstructor, IsPlainOldData)

void UAsyncLoadHelper::AddTask(const struct FString& ObjectPath, int LoadPriority)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncLoadHelper.AddTask");

	UAsyncLoadHelper_AddTask_Params params;
	params.ObjectPath = ObjectPath;
	params.LoadPriority = LoadPriority;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AsyncTaskCDNDownloader.DownloadCDNContent
// ()
// Parameters:
// struct FString                 URL                            (ConstParm, Parm, ZeroConstructor)
// int                            loaderType                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 savedDir                       (ConstParm, Parm, ZeroConstructor)
// bool                           breakpointContinualTransfer    (Parm, ZeroConstructor, IsPlainOldData)
// class UAsyncTaskCDNDownloader* ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UAsyncTaskCDNDownloader* UAsyncTaskCDNDownloader::DownloadCDNContent(const struct FString& URL, int loaderType, const struct FString& savedDir, bool breakpointContinualTransfer)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncTaskCDNDownloader.DownloadCDNContent");

	UAsyncTaskCDNDownloader_DownloadCDNContent_Params params;
	params.URL = URL;
	params.loaderType = loaderType;
	params.savedDir = savedDir;
	params.breakpointContinualTransfer = breakpointContinualTransfer;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.AsyncTaskDownloader.DownloadContent
// ()
// Parameters:
// struct FString                 URL                            (ConstParm, Parm, ZeroConstructor)
// int                            loaderType                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 savedDir                       (ConstParm, Parm, ZeroConstructor)
// bool                           breakpointContinualTransfer    (Parm, ZeroConstructor, IsPlainOldData)
// class UAsyncTaskDownloader*    ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UAsyncTaskDownloader* UAsyncTaskDownloader::DownloadContent(const struct FString& URL, int loaderType, const struct FString& savedDir, bool breakpointContinualTransfer)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AsyncTaskDownloader.DownloadContent");

	UAsyncTaskDownloader_DownloadContent_Params params;
	params.URL = URL;
	params.loaderType = loaderType;
	params.savedDir = savedDir;
	params.breakpointContinualTransfer = breakpointContinualTransfer;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleScriptHelper.SyncNewBattlePlayer
// ()
// Parameters:
// class UBattleUtils*            Utils                          (Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       UId                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FPlayerInfoData         Info                           (ConstParm, Parm, OutParm, ReferenceParm)
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UBattleScriptHelper::SyncNewBattlePlayer(class UBattleUtils* Utils, uint64_t UId, const struct FPlayerInfoData& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleScriptHelper.SyncNewBattlePlayer");

	UBattleScriptHelper_SyncNewBattlePlayer_Params params;
	params.Utils = Utils;
	params.UId = UId;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleScriptHelper.SyncGameInfo
// ()
// Parameters:
// class UBattleUtils*            Utils                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FBattleGameInfo         Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UBattleScriptHelper::SyncGameInfo(class UBattleUtils* Utils, const struct FBattleGameInfo& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleScriptHelper.SyncGameInfo");

	UBattleScriptHelper_SyncGameInfo_Params params;
	params.Utils = Utils;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleScriptHelper.SyncGameExit
// ()
// Parameters:
// class UBattleUtils*            Utils                          (Parm, ZeroConstructor, IsPlainOldData)

void UBattleScriptHelper::SyncGameExit(class UBattleUtils* Utils)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleScriptHelper.SyncGameExit");

	UBattleScriptHelper_SyncGameExit_Params params;
	params.Utils = Utils;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleScriptHelper.SyncBattlePlayerExit
// ()
// Parameters:
// class UBattleUtils*            Utils                          (Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       UId                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   PlayerType                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Reason                         (Parm, ZeroConstructor)

void UBattleScriptHelper::SyncBattlePlayerExit(class UBattleUtils* Utils, uint64_t UId, const struct FName& PlayerType, const struct FString& Reason)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleScriptHelper.SyncBattlePlayerExit");

	UBattleScriptHelper_SyncBattlePlayerExit_Params params;
	params.Utils = Utils;
	params.UId = UId;
	params.PlayerType = PlayerType;
	params.Reason = Reason;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleScriptHelper.ResponPlayerWeaponDIYData
// ()
// Parameters:
// class UBattleUtils*            Utils                          (Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       PlayerUID                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FWeaponDIYData          InWeaponDIYData                (Parm)

void UBattleScriptHelper::ResponPlayerWeaponDIYData(class UBattleUtils* Utils, uint64_t PlayerUID, const struct FWeaponDIYData& InWeaponDIYData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleScriptHelper.ResponPlayerWeaponDIYData");

	UBattleScriptHelper_ResponPlayerWeaponDIYData_Params params;
	params.Utils = Utils;
	params.PlayerUID = PlayerUID;
	params.InWeaponDIYData = InWeaponDIYData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleScriptHelper.GenerateAIPlayerParams
// ()
// Parameters:
// class UBattleUtils*            Utils                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FPlayerInfoData         Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UBattleScriptHelper::GenerateAIPlayerParams(class UBattleUtils* Utils, const struct FPlayerInfoData& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleScriptHelper.GenerateAIPlayerParams");

	UBattleScriptHelper_GenerateAIPlayerParams_Params params;
	params.Utils = Utils;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattlePlayer.ExtractGameModePlayerParams
// ()
// Parameters:
// struct FGameModePlayerParams   ReturnValue                    (Parm, OutParm, ReturnParm)

struct FGameModePlayerParams UBattlePlayer::ExtractGameModePlayerParams()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattlePlayer.ExtractGameModePlayerParams");

	UBattlePlayer_ExtractGameModePlayerParams_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleAIPlayer.ExtractGameModeAIPlayerParams
// ()
// Parameters:
// struct FGameModeAIPlayerParams ReturnValue                    (Parm, OutParm, ReturnParm)

struct FGameModeAIPlayerParams UBattleAIPlayer::ExtractGameModeAIPlayerParams()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleAIPlayer.ExtractGameModeAIPlayerParams");

	UBattleAIPlayer_ExtractGameModeAIPlayerParams_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.SyncNewBattlePlayer
// ()
// Parameters:
// uint64_t                       UId                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FPlayerInfoData         Info                           (ConstParm, Parm, OutParm, ReferenceParm)
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UBattleUtils::SyncNewBattlePlayer(uint64_t UId, const struct FPlayerInfoData& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.SyncNewBattlePlayer");

	UBattleUtils_SyncNewBattlePlayer_Params params;
	params.UId = UId;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.SyncGameInfo
// ()
// Parameters:
// struct FBattleGameInfo         Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UBattleUtils::SyncGameInfo(const struct FBattleGameInfo& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.SyncGameInfo");

	UBattleUtils_SyncGameInfo_Params params;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.SyncGameExit
// ()

void UBattleUtils::SyncGameExit()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.SyncGameExit");

	UBattleUtils_SyncGameExit_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.SyncBattlePlayerExit
// ()
// Parameters:
// uint64_t                       UId                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   PlayerType                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Reason                         (Parm, ZeroConstructor)

void UBattleUtils::SyncBattlePlayerExit(uint64_t UId, const struct FName& PlayerType, const struct FString& Reason)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.SyncBattlePlayerExit");

	UBattleUtils_SyncBattlePlayerExit_Params params;
	params.UId = UId;
	params.PlayerType = PlayerType;
	params.Reason = Reason;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.RetrievePlayerParams
// ()
// Parameters:
// struct FPlayerID               PlayerID                       (Parm)
// struct FGameModePlayerParams   ReturnValue                    (Parm, OutParm, ReturnParm)

struct FGameModePlayerParams UBattleUtils::RetrievePlayerParams(const struct FPlayerID& PlayerID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.RetrievePlayerParams");

	UBattleUtils_RetrievePlayerParams_Params params;
	params.PlayerID = PlayerID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.RetrieveAIPlayerParams
// ()
// Parameters:
// struct FPlayerID               PlayerID                       (Parm)
// struct FGameModeAIPlayerParams ReturnValue                    (Parm, OutParm, ReturnParm)

struct FGameModeAIPlayerParams UBattleUtils::RetrieveAIPlayerParams(const struct FPlayerID& PlayerID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.RetrieveAIPlayerParams");

	UBattleUtils_RetrieveAIPlayerParams_Params params;
	params.PlayerID = PlayerID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.ResponPlayerWeaponDIYData
// ()
// Parameters:
// uint64_t                       PlayerUID                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FWeaponDIYData          InWeaponDIYData                (Parm)

void UBattleUtils::ResponPlayerWeaponDIYData(uint64_t PlayerUID, const struct FWeaponDIYData& InWeaponDIYData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.ResponPlayerWeaponDIYData");

	UBattleUtils_ResponPlayerWeaponDIYData_Params params;
	params.PlayerUID = PlayerUID;
	params.InWeaponDIYData = InWeaponDIYData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.RequestSomePlayersBattleData
// ()
// Parameters:
// TArray<uint64_t>               PlayerUIDList                  (Parm, ZeroConstructor)
// unsigned char                  DataType                       (Parm, ZeroConstructor, IsPlainOldData)

void UBattleUtils::RequestSomePlayersBattleData(TArray<uint64_t> PlayerUIDList, unsigned char DataType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.RequestSomePlayersBattleData");

	UBattleUtils_RequestSomePlayersBattleData_Params params;
	params.PlayerUIDList = PlayerUIDList;
	params.DataType = DataType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.RequestPlayerWeaponDIYData
// ()
// Parameters:
// uint64_t                       PlayerUID                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            WeaponSkinID                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            PlanID                         (Parm, ZeroConstructor, IsPlainOldData)

void UBattleUtils::RequestPlayerWeaponDIYData(uint64_t PlayerUID, int WeaponSkinID, int PlanID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.RequestPlayerWeaponDIYData");

	UBattleUtils_RequestPlayerWeaponDIYData_Params params;
	params.PlayerUID = PlayerUID;
	params.WeaponSkinID = WeaponSkinID;
	params.PlanID = PlanID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.RequestOnePlayersBattleData
// ()
// Parameters:
// uint64_t                       PlayerUID                      (Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  DataType                       (Parm, ZeroConstructor, IsPlainOldData)

void UBattleUtils::RequestOnePlayersBattleData(uint64_t PlayerUID, unsigned char DataType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.RequestOnePlayersBattleData");

	UBattleUtils_RequestOnePlayersBattleData_Params params;
	params.PlayerUID = PlayerUID;
	params.DataType = DataType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.RequestAllPlayersBattleData
// ()
// Parameters:
// unsigned char                  DataType                       (Parm, ZeroConstructor, IsPlainOldData)

void UBattleUtils::RequestAllPlayersBattleData(unsigned char DataType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.RequestAllPlayersBattleData");

	UBattleUtils_RequestAllPlayersBattleData_Params params;
	params.DataType = DataType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.OnPostLoadMapWithWorld
// ()
// Parameters:
// class UWorld*                  World                          (Parm, ZeroConstructor, IsPlainOldData)

void UBattleUtils::OnPostLoadMapWithWorld(class UWorld* World)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.OnPostLoadMapWithWorld");

	UBattleUtils_OnPostLoadMapWithWorld_Params params;
	params.World = World;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.NewBattlePlayer
// ()
// Parameters:
// class UBattlePlayer*           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UBattlePlayer* UBattleUtils::NewBattlePlayer()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.NewBattlePlayer");

	UBattleUtils_NewBattlePlayer_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.NewBattleAIPlayer
// ()
// Parameters:
// class UBattleAIPlayer*         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UBattleAIPlayer* UBattleUtils::NewBattleAIPlayer()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.NewBattleAIPlayer");

	UBattleUtils_NewBattleAIPlayer_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.HandleGameModeStateChanged
// ()
// Parameters:
// struct FGameModeStateChangedParams Params                         (ConstParm, Parm, OutParm, ReferenceParm)

void UBattleUtils::HandleGameModeStateChanged(const struct FGameModeStateChangedParams& Params)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.HandleGameModeStateChanged");

	UBattleUtils_HandleGameModeStateChanged_Params params;
	params.Params = Params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.GetBattleGameMode
// ()
// Parameters:
// class AUAEGameMode*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class AUAEGameMode* UBattleUtils::GetBattleGameMode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.GetBattleGameMode");

	UBattleUtils_GetBattleGameMode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.GenerateAIPlayerParams
// ()
// Parameters:
// struct FPlayerInfoData         Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UBattleUtils::GenerateAIPlayerParams(const struct FPlayerInfoData& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.GenerateAIPlayerParams");

	UBattleUtils_GenerateAIPlayerParams_Params params;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleUtils.FindPlayerByUID
// ()
// Parameters:
// uint64_t                       UId                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   PlayerType                     (Parm, ZeroConstructor, IsPlainOldData)
// class UBattlePlayer*           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UBattlePlayer* UBattleUtils::FindPlayerByUID(uint64_t UId, const struct FName& PlayerType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.FindPlayerByUID");

	UBattleUtils_FindPlayerByUID_Params params;
	params.UId = UId;
	params.PlayerType = PlayerType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.FindPlayerByPlayerName
// ()
// Parameters:
// struct FString                 PlayerName                     (Parm, ZeroConstructor)
// struct FName                   PlayerType                     (Parm, ZeroConstructor, IsPlainOldData)
// class UBattlePlayer*           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UBattlePlayer* UBattleUtils::FindPlayerByPlayerName(const struct FString& PlayerName, const struct FName& PlayerType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.FindPlayerByPlayerName");

	UBattleUtils_FindPlayerByPlayerName_Params params;
	params.PlayerName = PlayerName;
	params.PlayerType = PlayerType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleUtils.FindPlayerByPlayerKey
// ()
// Parameters:
// uint32_t                       PlayerKey                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   PlayerType                     (Parm, ZeroConstructor, IsPlainOldData)
// class UBattlePlayer*           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UBattlePlayer* UBattleUtils::FindPlayerByPlayerKey(uint32_t PlayerKey, const struct FName& PlayerType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleUtils.FindPlayerByPlayerKey");

	UBattleUtils_FindPlayerByPlayerKey_Params params;
	params.PlayerKey = PlayerKey;
	params.PlayerType = PlayerType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BattleWindowMgr.ShowUI
// ()
// Parameters:
// class UObject*                 WorldContextObject             (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 WindowName                     (Parm, ZeroConstructor)
// class UObject*                 ObjectParam                    (Parm, ZeroConstructor, IsPlainOldData)

void UBattleWindowMgr::ShowUI(class UObject* WorldContextObject, const struct FString& WindowName, class UObject* ObjectParam)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleWindowMgr.ShowUI");

	UBattleWindowMgr_ShowUI_Params params;
	params.WorldContextObject = WorldContextObject;
	params.WindowName = WindowName;
	params.ObjectParam = ObjectParam;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleWindowMgr.SetInstance
// ()
// Parameters:
// class UBattleWindowMgrLuaUtils* InInstance                     (Parm, ZeroConstructor, IsPlainOldData)
// class ULuaStateWrapper*        InLuaStateWrapper              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UBattleWindowMgr::SetInstance(class UBattleWindowMgrLuaUtils* InInstance, class ULuaStateWrapper* InLuaStateWrapper)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleWindowMgr.SetInstance");

	UBattleWindowMgr_SetInstance_Params params;
	params.InInstance = InInstance;
	params.InLuaStateWrapper = InLuaStateWrapper;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleWindowMgr.HideUI
// ()
// Parameters:
// class UObject*                 WorldContextObject             (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 WindowName                     (Parm, ZeroConstructor)

void UBattleWindowMgr::HideUI(class UObject* WorldContextObject, const struct FString& WindowName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleWindowMgr.HideUI");

	UBattleWindowMgr_HideUI_Params params;
	params.WorldContextObject = WorldContextObject;
	params.WindowName = WindowName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BattleWindowMgr.CheckWindowOpen
// ()
// Parameters:
// class UObject*                 WorldContextObject             (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 WindowName                     (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBattleWindowMgr::CheckWindowOpen(class UObject* WorldContextObject, const struct FString& WindowName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BattleWindowMgr.CheckWindowOpen");

	UBattleWindowMgr_CheckWindowOpen_Params params;
	params.WorldContextObject = WorldContextObject;
	params.WindowName = WindowName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BugReporter.SendScreenShot
// ()
// Parameters:
// struct FString                 errorReason                    (Parm, ZeroConstructor)
// struct FString                 errorDescription               (Parm, ZeroConstructor)
// struct FString                 ImagePath                      (Parm, ZeroConstructor)
// float                          X                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Y                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Z                              (Parm, ZeroConstructor, IsPlainOldData)

void UBugReporter::SendScreenShot(const struct FString& errorReason, const struct FString& errorDescription, const struct FString& ImagePath, float X, float Y, float Z)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BugReporter.SendScreenShot");

	UBugReporter_SendScreenShot_Params params;
	params.errorReason = errorReason;
	params.errorDescription = errorDescription;
	params.ImagePath = ImagePath;
	params.X = X;
	params.Y = Y;
	params.Z = Z;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BugReporter.SendLog
// ()
// Parameters:
// struct FString                 errorReason                    (Parm, ZeroConstructor)
// struct FString                 errorDescription               (Parm, ZeroConstructor)
// float                          X                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Y                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Z                              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           pullAll                        (Parm, ZeroConstructor, IsPlainOldData)
// bool                           zipLogUpload                   (Parm, ZeroConstructor, IsPlainOldData)

void UBugReporter::SendLog(const struct FString& errorReason, const struct FString& errorDescription, float X, float Y, float Z, bool pullAll, bool zipLogUpload)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BugReporter.SendLog");

	UBugReporter_SendLog_Params params;
	params.errorReason = errorReason;
	params.errorDescription = errorDescription;
	params.X = X;
	params.Y = Y;
	params.Z = Z;
	params.pullAll = pullAll;
	params.zipLogUpload = zipLogUpload;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BugReporter.ReadZipLog
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)

void UBugReporter::ReadZipLog(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BugReporter.ReadZipLog");

	UBugReporter_ReadZipLog_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BugReporter.CompressLog
// ()
// Parameters:
// bool                           pullAllLog                     (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<unsigned char> UBugReporter::CompressLog(bool pullAllLog)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BugReporter.CompressLog");

	UBugReporter_CompressLog_Params params;
	params.pullAllLog = pullAllLog;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.UIGetResWithPath
// ()
// Parameters:
// struct FString                 DesManagerName                 (Parm, ZeroConstructor)
// class UObject*                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UObject* UBusinessHelper::UIGetResWithPath(const struct FString& DesManagerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.UIGetResWithPath");

	UBusinessHelper_UIGetResWithPath_Params params;
	params.DesManagerName = DesManagerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.UIGetLuaManagerByName
// ()
// Parameters:
// class UUAEUserWidget*          pUIClass                       (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// struct FString                 InManagerName                  (Parm, ZeroConstructor)
// class ALuaClassObj*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ALuaClassObj* UBusinessHelper::UIGetLuaManagerByName(class UUAEUserWidget* pUIClass, const struct FString& InManagerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.UIGetLuaManagerByName");

	UBusinessHelper_UIGetLuaManagerByName_Params params;
	params.pUIClass = pUIClass;
	params.InManagerName = InManagerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.UIGetLuaManager
// ()
// Parameters:
// class UUAEUserWidget*          pUIClass                       (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class ALuaClassObj*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ALuaClassObj* UBusinessHelper::UIGetLuaManager(class UUAEUserWidget* pUIClass)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.UIGetLuaManager");

	UBusinessHelper_UIGetLuaManager_Params params;
	params.pUIClass = pUIClass;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.StopUIStat
// ()
// Parameters:
// struct FString                 UIName                         (Parm, ZeroConstructor)
// bool                           bReport                        (Parm, ZeroConstructor, IsPlainOldData)

void UBusinessHelper::StopUIStat(const struct FString& UIName, bool bReport)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.StopUIStat");

	UBusinessHelper_StopUIStat_Params params;
	params.UIName = UIName;
	params.bReport = bReport;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BusinessHelper.StopTimeWatch
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UBusinessHelper::StopTimeWatch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.StopTimeWatch");

	UBusinessHelper_StopTimeWatch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.StartUIStat
// ()
// Parameters:
// struct FString                 UIName                         (Parm, ZeroConstructor)

void UBusinessHelper::StartUIStat(const struct FString& UIName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.StartUIStat");

	UBusinessHelper_StartUIStat_Params params;
	params.UIName = UIName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BusinessHelper.StartTimeWatch
// ()

void UBusinessHelper::StartTimeWatch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.StartTimeWatch");

	UBusinessHelper_StartTimeWatch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BusinessHelper.SetUIStatMaxClickTimes
// ()
// Parameters:
// int                            Times                          (Parm, ZeroConstructor, IsPlainOldData)

void UBusinessHelper::SetUIStatMaxClickTimes(int Times)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.SetUIStatMaxClickTimes");

	UBusinessHelper_SetUIStatMaxClickTimes_Params params;
	params.Times = Times;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BusinessHelper.ReportUIStat
// ()
// Parameters:
// struct FString                 UIName                         (Parm, ZeroConstructor)
// bool                           bGStatTime                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bReport                        (Parm, ZeroConstructor, IsPlainOldData)
// float                          TotalTime                      (Parm, ZeroConstructor, IsPlainOldData)

void UBusinessHelper::ReportUIStat(const struct FString& UIName, bool bGStatTime, bool bReport, float TotalTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.ReportUIStat");

	UBusinessHelper_ReportUIStat_Params params;
	params.UIName = UIName;
	params.bGStatTime = bGStatTime;
	params.bReport = bReport;
	params.TotalTime = TotalTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BusinessHelper.LoadAssetFromPath
// ()
// Parameters:
// struct FString                 DesManagerName                 (Parm, ZeroConstructor)
// class UObject*                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UObject* UBusinessHelper::LoadAssetFromPath(const struct FString& DesManagerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.LoadAssetFromPath");

	UBusinessHelper_LoadAssetFromPath_Params params;
	params.DesManagerName = DesManagerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.IsSplitMiniPakVersion
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBusinessHelper::IsSplitMiniPakVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.IsSplitMiniPakVersion");

	UBusinessHelper_IsSplitMiniPakVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.IsSplitMapPakVersion
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBusinessHelper::IsSplitMapPakVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.IsSplitMapPakVersion");

	UBusinessHelper_IsSplitMapPakVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.IsFit
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBusinessHelper::IsFit()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.IsFit");

	UBusinessHelper_IsFit_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.IsClassOf
// ()
// Parameters:
// class UObject*                 Object                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class UClass*                  Class                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBusinessHelper::IsClassOf(class UObject* Object, class UClass* Class)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.IsClassOf");

	UBusinessHelper_IsClassOf_Params params;
	params.Object = Object;
	params.Class = Class;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.IsCEVersion
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBusinessHelper::IsCEVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.IsCEVersion");

	UBusinessHelper_IsCEVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.IsAppFromStore
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBusinessHelper::IsAppFromStore()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.IsAppFromStore");

	UBusinessHelper_IsAppFromStore_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.HasDownloadedBasePak
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UBusinessHelper::HasDownloadedBasePak()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.HasDownloadedBasePak");

	UBusinessHelper_HasDownloadedBasePak_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetWidgetByName
// ()
// Parameters:
// class UUAEUserWidget*          pUIClass                       (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// struct FString                 InManagerName                  (Parm, ZeroConstructor)
// struct FString                 InWidgtName                    (Parm, ZeroConstructor)
// class UUAEUserWidget*          ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UUAEUserWidget* UBusinessHelper::GetWidgetByName(class UUAEUserWidget* pUIClass, const struct FString& InManagerName, const struct FString& InWidgtName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetWidgetByName");

	UBusinessHelper_GetWidgetByName_Params params;
	params.pUIClass = pUIClass;
	params.InManagerName = InManagerName;
	params.InWidgtName = InWidgtName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetTime
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UBusinessHelper::GetTime()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetTime");

	UBusinessHelper_GetTime_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetSplitMapConfigInfo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetSplitMapConfigInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetSplitMapConfigInfo");

	UBusinessHelper_GetSplitMapConfigInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetPublishRegionID
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UBusinessHelper::GetPublishRegionID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetPublishRegionID");

	UBusinessHelper_GetPublishRegionID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetPublishRegion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetPublishRegion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetPublishRegion");

	UBusinessHelper_GetPublishRegion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetPackChannel
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetPackChannel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetPackChannel");

	UBusinessHelper_GetPackChannel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetOpenId
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetOpenId()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetOpenId");

	UBusinessHelper_GetOpenId_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetMobileBasePath
// ()
// Parameters:
// struct FString                 InPath                         (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetMobileBasePath(const struct FString& InPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetMobileBasePath");

	UBusinessHelper_GetMobileBasePath_Params params;
	params.InPath = InPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetLuaManagerByName
// ()
// Parameters:
// class UUAEUserWidget*          pUIClass                       (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// struct FString                 InManagerName                  (Parm, ZeroConstructor)
// class ALuaClassObj*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ALuaClassObj* UBusinessHelper::GetLuaManagerByName(class UUAEUserWidget* pUIClass, const struct FString& InManagerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetLuaManagerByName");

	UBusinessHelper_GetLuaManagerByName_Params params;
	params.pUIClass = pUIClass;
	params.InManagerName = InManagerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetITopGameId
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetITopGameId()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetITopGameId");

	UBusinessHelper_GetITopGameId_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetInGameLocalConnectURL
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetInGameLocalConnectURL()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetInGameLocalConnectURL");

	UBusinessHelper_GetInGameLocalConnectURL_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetIMSDKEnv
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UBusinessHelper::GetIMSDKEnv()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetIMSDKEnv");

	UBusinessHelper_GetIMSDKEnv_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetDeviceQualityLevel
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UBusinessHelper::GetDeviceQualityLevel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetDeviceQualityLevel");

	UBusinessHelper_GetDeviceQualityLevel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetDeviceOrientation
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UBusinessHelper::GetDeviceOrientation()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetDeviceOrientation");

	UBusinessHelper_GetDeviceOrientation_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetDataTable
// ()
// Parameters:
// struct FString                 tableName                      (Parm, ZeroConstructor)
// class UUAEDataTable*           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UUAEDataTable* UBusinessHelper::GetDataTable(const struct FString& tableName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetDataTable");

	UBusinessHelper_GetDataTable_Params params;
	params.tableName = tableName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetCurrentNetworkState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UBusinessHelper::GetCurrentNetworkState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetCurrentNetworkState");

	UBusinessHelper_GetCurrentNetworkState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetChildByName
// ()
// Parameters:
// class UUserWidget*             pParent                        (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// struct FString                 Name                           (Parm, ZeroConstructor)
// class UWidget*                 ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidget* UBusinessHelper::GetChildByName(class UUserWidget* pParent, const struct FString& Name)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetChildByName");

	UBusinessHelper_GetChildByName_Params params;
	params.pParent = pParent;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetBuildURL
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetBuildURL()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetBuildURL");

	UBusinessHelper_GetBuildURL_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetBuildNo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetBuildNo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetBuildNo");

	UBusinessHelper_GetBuildNo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetBranchName
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetBranchName()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetBranchName");

	UBusinessHelper_GetBranchName_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetBase64Key
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetBase64Key()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetBase64Key");

	UBusinessHelper_GetBase64Key_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetAppVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetAppVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetAppVersion");

	UBusinessHelper_GetAppVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetAOSSHOPID
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UBusinessHelper::GetAOSSHOPID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetAOSSHOPID");

	UBusinessHelper_GetAOSSHOPID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.GetAOSSHOP
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UBusinessHelper::GetAOSSHOP()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.GetAOSSHOP");

	UBusinessHelper_GetAOSSHOP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.BusinessHelper.ClearDisplayLookupTable
// ()

void UBusinessHelper::ClearDisplayLookupTable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.ClearDisplayLookupTable");

	UBusinessHelper_ClearDisplayLookupTable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BusinessHelper.BroadCastMSG
// ()
// Parameters:
// class UFrontendHUD*            FrontendHUD                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 DesManagerName                 (Parm, ZeroConstructor)
// struct FString                 Msg                            (Parm, ZeroConstructor)

void UBusinessHelper::BroadCastMSG(class UFrontendHUD* FrontendHUD, const struct FString& DesManagerName, const struct FString& Msg)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.BroadCastMSG");

	UBusinessHelper_BroadCastMSG_Params params;
	params.FrontendHUD = FrontendHUD;
	params.DesManagerName = DesManagerName;
	params.Msg = Msg;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.BusinessHelper.AddKnownMissingPackage
// ()
// Parameters:
// struct FString                 PackageName                    (Parm, ZeroConstructor)
// class UObject*                 BindObj                        (Parm, ZeroConstructor, IsPlainOldData)

void UBusinessHelper::AddKnownMissingPackage(const struct FString& PackageName, class UObject* BindObj)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.BusinessHelper.AddKnownMissingPackage");

	UBusinessHelper_AddKnownMissingPackage_Params params;
	params.PackageName = PackageName;
	params.BindObj = BindObj;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.UpdateXGPushNightTag
// ()
// Parameters:
// bool                           BInit                          (Parm, ZeroConstructor, IsPlainOldData)

void UIntlHelper::UpdateXGPushNightTag(bool BInit)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.UpdateXGPushNightTag");

	UIntlHelper_UpdateXGPushNightTag_Params params;
	params.BInit = BInit;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.UpdateXGPushDayTag
// ()
// Parameters:
// bool                           BInit                          (Parm, ZeroConstructor, IsPlainOldData)

void UIntlHelper::UpdateXGPushDayTag(bool BInit)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.UpdateXGPushDayTag");

	UIntlHelper_UpdateXGPushDayTag_Params params;
	params.BInit = BInit;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.UpdateVoiceUrl
// ()
// Parameters:
// struct FString                 regionVoiceUrl                 (Parm, ZeroConstructor)

void UIntlHelper::UpdateVoiceUrl(const struct FString& regionVoiceUrl)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.UpdateVoiceUrl");

	UIntlHelper_UpdateVoiceUrl_Params params;
	params.regionVoiceUrl = regionVoiceUrl;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.UnInitTweenMaker
// ()

void UIntlHelper::UnInitTweenMaker()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.UnInitTweenMaker");

	UIntlHelper_UnInitTweenMaker_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.TimeFormatString
// ()
// Parameters:
// struct FString                 Format                         (Parm, ZeroConstructor)
// int                            hours                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            Mins                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            secs                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::TimeFormatString(const struct FString& Format, int hours, int Mins, int secs)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.TimeFormatString");

	UIntlHelper_TimeFormatString_Params params;
	params.Format = Format;
	params.hours = hours;
	params.Mins = Mins;
	params.secs = secs;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.SaveXGTags
// ()
// Parameters:
// struct FString                 Language                       (Parm, ZeroConstructor)
// struct FString                 timezone                       (Parm, ZeroConstructor)
// struct FString                 Region                         (Parm, ZeroConstructor)

void UIntlHelper::SaveXGTags(const struct FString& Language, const struct FString& timezone, const struct FString& Region)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.SaveXGTags");

	UIntlHelper_SaveXGTags_Params params;
	params.Language = Language;
	params.timezone = timezone;
	params.Region = Region;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.OnSwitchLanguage
// ()

void UIntlHelper::OnSwitchLanguage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.OnSwitchLanguage");

	UIntlHelper_OnSwitchLanguage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.OnChoosingZone
// ()
// Parameters:
// int                            ZoneID                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 AddrIP                         (Parm, ZeroConstructor)
// struct FString                 regionVoiceUrl                 (Parm, ZeroConstructor)

void UIntlHelper::OnChoosingZone(int ZoneID, const struct FString& AddrIP, const struct FString& regionVoiceUrl)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.OnChoosingZone");

	UIntlHelper_OnChoosingZone_Params params;
	params.ZoneID = ZoneID;
	params.AddrIP = AddrIP;
	params.regionVoiceUrl = regionVoiceUrl;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.IsRemoteNotificationsEnabled
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UIntlHelper::IsRemoteNotificationsEnabled()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.IsRemoteNotificationsEnabled");

	UIntlHelper_IsRemoteNotificationsEnabled_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.IsHelpshiftEnable4CurrentChannel
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UIntlHelper::IsHelpshiftEnable4CurrentChannel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.IsHelpshiftEnable4CurrentChannel");

	UIntlHelper_IsHelpshiftEnable4CurrentChannel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.IsHelpshiftEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UIntlHelper::IsHelpshiftEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.IsHelpshiftEnable");

	UIntlHelper_IsHelpshiftEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.InitTweenMaker
// ()

void UIntlHelper::InitTweenMaker()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.InitTweenMaker");

	UIntlHelper_InitTweenMaker_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.HelpshiftUploadLog
// ()

void UIntlHelper::HelpshiftUploadLog()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftUploadLog");

	UIntlHelper_HelpshiftUploadLog_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.HelpshiftShowFAQsWithInfo
// ()
// Parameters:
// struct FString                 PlayerName                     (Parm, ZeroConstructor)
// struct FString                 PlayerLevel                    (Parm, ZeroConstructor)
// struct FString                 PlayerGold                     (Parm, ZeroConstructor)
// int                            PlayerRecharge                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            PlayerRegisterTime             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ExtraTags                      (Parm, ZeroConstructor)

void UIntlHelper::HelpshiftShowFAQsWithInfo(const struct FString& PlayerName, const struct FString& PlayerLevel, const struct FString& PlayerGold, int PlayerRecharge, int PlayerRegisterTime, const struct FString& ExtraTags)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftShowFAQsWithInfo");

	UIntlHelper_HelpshiftShowFAQsWithInfo_Params params;
	params.PlayerName = PlayerName;
	params.PlayerLevel = PlayerLevel;
	params.PlayerGold = PlayerGold;
	params.PlayerRecharge = PlayerRecharge;
	params.PlayerRegisterTime = PlayerRegisterTime;
	params.ExtraTags = ExtraTags;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.HelpshiftShowFAQs
// ()

void UIntlHelper::HelpshiftShowFAQs()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftShowFAQs");

	UIntlHelper_HelpshiftShowFAQs_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.HelpshiftShowConversionWithInfo
// ()
// Parameters:
// struct FString                 Name                           (Parm, ZeroConstructor)
// struct FString                 Level                          (Parm, ZeroConstructor)
// struct FString                 Gold                           (Parm, ZeroConstructor)

void UIntlHelper::HelpshiftShowConversionWithInfo(const struct FString& Name, const struct FString& Level, const struct FString& Gold)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftShowConversionWithInfo");

	UIntlHelper_HelpshiftShowConversionWithInfo_Params params;
	params.Name = Name;
	params.Level = Level;
	params.Gold = Gold;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.HelpshiftShowConversion
// ()

void UIntlHelper::HelpshiftShowConversion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftShowConversion");

	UIntlHelper_HelpshiftShowConversion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.HelpshiftRequestUnreadMessagesCount
// ()

void UIntlHelper::HelpshiftRequestUnreadMessagesCount()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftRequestUnreadMessagesCount");

	UIntlHelper_HelpshiftRequestUnreadMessagesCount_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.HelpshiftGetUnreadMessgesCount
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UIntlHelper::HelpshiftGetUnreadMessgesCount()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftGetUnreadMessgesCount");

	UIntlHelper_HelpshiftGetUnreadMessgesCount_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.HelpshiftClearUnreadMessgesCount
// ()

void UIntlHelper::HelpshiftClearUnreadMessgesCount()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.HelpshiftClearUnreadMessgesCount");

	UIntlHelper_HelpshiftClearUnreadMessgesCount_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.GetSavedXGTimezoneTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetSavedXGTimezoneTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetSavedXGTimezoneTag");

	UIntlHelper_GetSavedXGTimezoneTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetSavedXGRegionTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetSavedXGRegionTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetSavedXGRegionTag");

	UIntlHelper_GetSavedXGRegionTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetSavedXGPushNightTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetSavedXGPushNightTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetSavedXGPushNightTag");

	UIntlHelper_GetSavedXGPushNightTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetSavedXGPushDayTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetSavedXGPushDayTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetSavedXGPushDayTag");

	UIntlHelper_GetSavedXGPushDayTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetSavedXGLanguageTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetSavedXGLanguageTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetSavedXGLanguageTag");

	UIntlHelper_GetSavedXGLanguageTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetPlayerUCLevel
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetPlayerUCLevel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetPlayerUCLevel");

	UIntlHelper_GetPlayerUCLevel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalTimezone
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UIntlHelper::GetLocalTimezone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalTimezone");

	UIntlHelper_GetLocalTimezone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalizeStringWithString
// ()
// Parameters:
// struct FString                 sourceString                   (Parm, ZeroConstructor)
// int                            numStringIndex                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 string1                        (Parm, ZeroConstructor)
// struct FString                 string2                        (Parm, ZeroConstructor)
// struct FString                 string3                        (Parm, ZeroConstructor)
// struct FString                 string4                        (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetLocalizeStringWithString(const struct FString& sourceString, int numStringIndex, const struct FString& string1, const struct FString& string2, const struct FString& string3, const struct FString& string4)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalizeStringWithString");

	UIntlHelper_GetLocalizeStringWithString_Params params;
	params.sourceString = sourceString;
	params.numStringIndex = numStringIndex;
	params.string1 = string1;
	params.string2 = string2;
	params.string3 = string3;
	params.string4 = string4;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalizeStringWithNum
// ()
// Parameters:
// int                            ID                             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            numStringIndex                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 string1                        (Parm, ZeroConstructor)
// struct FString                 string2                        (Parm, ZeroConstructor)
// struct FString                 string3                        (Parm, ZeroConstructor)
// struct FString                 string4                        (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetLocalizeStringWithNum(int ID, int numStringIndex, const struct FString& string1, const struct FString& string2, const struct FString& string3, const struct FString& string4)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalizeStringWithNum");

	UIntlHelper_GetLocalizeStringWithNum_Params params;
	params.ID = ID;
	params.numStringIndex = numStringIndex;
	params.string1 = string1;
	params.string2 = string2;
	params.string3 = string3;
	params.string4 = string4;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalizeStrByStr
// ()
// Parameters:
// struct FString                 Source                         (Parm, ZeroConstructor)
// struct FString                 string1                        (Parm, ZeroConstructor)
// struct FString                 string2                        (Parm, ZeroConstructor)
// struct FString                 string3                        (Parm, ZeroConstructor)
// struct FString                 string4                        (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetLocalizeStrByStr(const struct FString& Source, const struct FString& string1, const struct FString& string2, const struct FString& string3, const struct FString& string4)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalizeStrByStr");

	UIntlHelper_GetLocalizeStrByStr_Params params;
	params.Source = Source;
	params.string1 = string1;
	params.string2 = string2;
	params.string3 = string3;
	params.string4 = string4;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalizeStrByID
// ()
// Parameters:
// int                            ID                             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 string1                        (Parm, ZeroConstructor)
// struct FString                 string2                        (Parm, ZeroConstructor)
// struct FString                 string3                        (Parm, ZeroConstructor)
// struct FString                 string4                        (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetLocalizeStrByID(int ID, const struct FString& string1, const struct FString& string2, const struct FString& string3, const struct FString& string4)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalizeStrByID");

	UIntlHelper_GetLocalizeStrByID_Params params;
	params.ID = ID;
	params.string1 = string1;
	params.string2 = string2;
	params.string3 = string3;
	params.string4 = string4;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalizationStringWithID
// ()
// Parameters:
// int                            ID                             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetLocalizationStringWithID(int ID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalizationStringWithID");

	UIntlHelper_GetLocalizationStringWithID_Params params;
	params.ID = ID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalizationString
// ()
// Parameters:
// struct FString                 Key                            (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetLocalizationString(const struct FString& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalizationString");

	UIntlHelper_GetLocalizationString_Params params;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetLocalizationBattleStringWithID
// ()
// Parameters:
// int                            ID                             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetLocalizationBattleStringWithID(int ID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetLocalizationBattleStringWithID");

	UIntlHelper_GetLocalizationBattleStringWithID_Params params;
	params.ID = ID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetHistoryErrorCode
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetHistoryErrorCode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetHistoryErrorCode");

	UIntlHelper_GetHistoryErrorCode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetGameMasterVID
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::GetGameMasterVID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetGameMasterVID");

	UIntlHelper_GetGameMasterVID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.GetCurrentZoneID
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UIntlHelper::GetCurrentZoneID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.GetCurrentZoneID");

	UIntlHelper_GetCurrentZoneID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.FormatLocalizeStrByStr
// ()
// Parameters:
// struct FString                 Source                         (Parm, ZeroConstructor)
// TArray<struct FString>         stringArr                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UIntlHelper::FormatLocalizeStrByStr(const struct FString& Source, TArray<struct FString> stringArr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.FormatLocalizeStrByStr");

	UIntlHelper_FormatLocalizeStrByStr_Params params;
	params.Source = Source;
	params.stringArr = stringArr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IntlHelper.DownloadTranslation
// ()
// Parameters:
// struct FString                 PatchName                      (Parm, ZeroConstructor)

void UIntlHelper::DownloadTranslation(const struct FString& PatchName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.DownloadTranslation");

	UIntlHelper_DownloadTranslation_Params params;
	params.PatchName = PatchName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.DownloadServerList
// ()

void UIntlHelper::DownloadServerList()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.DownloadServerList");

	UIntlHelper_DownloadServerList_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.DownloadCDNFile
// ()
// Parameters:
// struct FString                 cdnUrl                         (Parm, ZeroConstructor)
// struct FString                 savePath                       (Parm, ZeroConstructor)

void UIntlHelper::DownloadCDNFile(const struct FString& cdnUrl, const struct FString& savePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.DownloadCDNFile");

	UIntlHelper_DownloadCDNFile_Params params;
	params.cdnUrl = cdnUrl;
	params.savePath = savePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.DirectToNotificationSetup
// ()

void UIntlHelper::DirectToNotificationSetup()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.DirectToNotificationSetup");

	UIntlHelper_DirectToNotificationSetup_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.ClearAdjustDeepLink
// ()

void UIntlHelper::ClearAdjustDeepLink()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.ClearAdjustDeepLink");

	UIntlHelper_ClearAdjustDeepLink_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.AdjustParaAnalysis
// ()

void UIntlHelper::AdjustParaAnalysis()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.AdjustParaAnalysis");

	UIntlHelper_AdjustParaAnalysis_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IntlHelper.AddErrorCodeToHistory
// ()
// Parameters:
// struct FString                 InErrorCode                    (Parm, ZeroConstructor)

void UIntlHelper::AddErrorCodeToHistory(const struct FString& InErrorCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IntlHelper.AddErrorCodeToHistory");

	UIntlHelper_AddErrorCodeToHistory_Params params;
	params.InErrorCode = InErrorCode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.TestHUD.TestFunctionNOParam
// ()

void ATestHUD::TestFunctionNOParam()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.TestFunctionNOParam");

	ATestHUD_TestFunctionNOParam_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.TestHUD.TestFunctionBP_LUA
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::TestFunctionBP_LUA()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.TestFunctionBP_LUA");

	ATestHUD_TestFunctionBP_LUA_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.TestFunctionBP
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::TestFunctionBP()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.TestFunctionBP");

	ATestHUD_TestFunctionBP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_Lua
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_Lua()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_Lua");

	ATestHUD_Function_Lua_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_CPlus_Call
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_CPlus_Call()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_CPlus_Call");

	ATestHUD_Function_CPlus_Call_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_CPlus
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_CPlus()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_CPlus");

	ATestHUD_Function_CPlus_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_BP_CPP
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_BP_CPP()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_BP_CPP");

	ATestHUD_Function_BP_CPP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_BP_Call_LUA
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_BP_Call_LUA()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_BP_Call_LUA");

	ATestHUD_Function_BP_Call_LUA_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_BP_Call_CPP
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_BP_Call_CPP()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_BP_Call_CPP");

	ATestHUD_Function_BP_Call_CPP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_BP_Call_CPlus
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_BP_Call_CPlus()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_BP_Call_CPlus");

	ATestHUD_Function_BP_Call_CPlus_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_BP_Call
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_BP_Call()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_BP_Call");

	ATestHUD_Function_BP_Call_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TestHUD.Function_BP
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ATestHUD::Function_BP()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TestHUD.Function_BP");

	ATestHUD_Function_BP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.CDNUpdate.StartUpdateApp
// ()

void UCDNUpdate::StartUpdateApp()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.StartUpdateApp");

	UCDNUpdate_StartUpdateApp_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CDNUpdate.StartAppUpdate
// ()
// Parameters:
// bool                           StartGrayUpdate                (Parm, ZeroConstructor, IsPlainOldData)

void UCDNUpdate::StartAppUpdate(bool StartGrayUpdate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.StartAppUpdate");

	UCDNUpdate_StartAppUpdate_Params params;
	params.StartGrayUpdate = StartGrayUpdate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CDNUpdate.OnRequestProgress
// ()
// Parameters:
// struct FCDNDownloaderInfo      Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UCDNUpdate::OnRequestProgress(const struct FCDNDownloaderInfo& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.OnRequestProgress");

	UCDNUpdate_OnRequestProgress_Params params;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CDNUpdate.OnRequestComplete
// ()
// Parameters:
// struct FCDNDownloaderInfo      Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UCDNUpdate::OnRequestComplete(const struct FCDNDownloaderInfo& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.OnRequestComplete");

	UCDNUpdate_OnRequestComplete_Params params;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CDNUpdate.IsUpdating
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCDNUpdate::IsUpdating()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.IsUpdating");

	UCDNUpdate_IsUpdating_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.CDNUpdate.IsGrayUpdate
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCDNUpdate::IsGrayUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.IsGrayUpdate");

	UCDNUpdate_IsGrayUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.CDNUpdate.GetCurStage
// ()
// Parameters:
// float                          percent                        (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            GetCurVal                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            GetMaxVal                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UCDNUpdate::GetCurStage(float* percent, int* GetCurVal, int* GetMaxVal)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.GetCurStage");

	UCDNUpdate_GetCurStage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (percent != nullptr)
		*percent = params.percent;
	if (GetCurVal != nullptr)
		*GetCurVal = params.GetCurVal;
	if (GetMaxVal != nullptr)
		*GetMaxVal = params.GetMaxVal;

	return params.ReturnValue;
}


// Function Client.CDNUpdate.FinishUpdate
// ()

void UCDNUpdate::FinishUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.FinishUpdate");

	UCDNUpdate_FinishUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CDNUpdate.ContinueUpdate
// ()

void UCDNUpdate::ContinueUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.ContinueUpdate");

	UCDNUpdate_ContinueUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CDNUpdate.CancelUpdate
// ()

void UCDNUpdate::CancelUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CDNUpdate.CancelUpdate");

	UCDNUpdate_CancelUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CompressTextureHelper.TestGetTexture2DFromDisk_KTX2
// ()
// Parameters:
// struct FString                 PathName                       (Parm, ZeroConstructor)
// class UTexture2D*              ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UTexture2D* UCompressTextureHelper::TestGetTexture2DFromDisk_KTX2(const struct FString& PathName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CompressTextureHelper.TestGetTexture2DFromDisk_KTX2");

	UCompressTextureHelper_TestGetTexture2DFromDisk_KTX2_Params params;
	params.PathName = PathName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.CrashContextProcessor.TriggerLoginCrashTest
// ()

void UCrashContextProcessor::TriggerLoginCrashTest()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CrashContextProcessor.TriggerLoginCrashTest");

	UCrashContextProcessor_TriggerLoginCrashTest_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CrashContextProcessor.TriggerLobbyCrashTest
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)

void UCrashContextProcessor::TriggerLobbyCrashTest(int Type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CrashContextProcessor.TriggerLobbyCrashTest");

	UCrashContextProcessor_TriggerLobbyCrashTest_Params params;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CrashContextProcessor.Initialize
// ()

void UCrashContextProcessor::Initialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CrashContextProcessor.Initialize");

	UCrashContextProcessor_Initialize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.CrashContextProcessor.GetInstance
// ()
// Parameters:
// class UCrashContextProcessor*  ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UCrashContextProcessor* UCrashContextProcessor::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CrashContextProcessor.GetInstance");

	UCrashContextProcessor_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.CrashContextProcessor.AddAttachFileString
// ()
// Parameters:
// struct FString                 Type                           (Parm, ZeroConstructor)
// bool                           bClear                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 strinfo                        (Parm, OutParm, ZeroConstructor)

void UCrashContextProcessor::AddAttachFileString(const struct FString& Type, bool bClear, struct FString* strinfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.CrashContextProcessor.AddAttachFileString");

	UCrashContextProcessor_AddAttachFileString_Params params;
	params.Type = Type;
	params.bClear = bClear;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (strinfo != nullptr)
		*strinfo = params.strinfo;
}


// Function Client.GameBackendUtils.GetTableManager
// ()
// Parameters:
// class UUAETableManager*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UUAETableManager* UGameBackendUtils::GetTableManager()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBackendUtils.GetTableManager");

	UGameBackendUtils_GetTableManager_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameBackendHUD.GetUtils
// ()
// Parameters:
// class UGameBackendUtils*       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGameBackendUtils* UGameBackendHUD::GetUtils()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBackendHUD.GetUtils");

	UGameBackendHUD_GetUtils_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameBackendHUD.GetInstance
// ()
// Parameters:
// class UGameBackendHUD*         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGameBackendHUD* UGameBackendHUD::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBackendHUD.GetInstance");

	UGameBackendHUD_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameBackendHUD.GetGameFrontendHUDByGameInstance
// ()
// Parameters:
// class UGameInstance*           GameInstance                   (Parm, ZeroConstructor, IsPlainOldData)
// class UGameFrontendHUD*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGameFrontendHUD* UGameBackendHUD::GetGameFrontendHUDByGameInstance(class UGameInstance* GameInstance)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBackendHUD.GetGameFrontendHUDByGameInstance");

	UGameBackendHUD_GetGameFrontendHUDByGameInstance_Params params;
	params.GameInstance = GameInstance;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameBackendHUD.GetFirstGameFrontendHUD
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class UGameFrontendHUD*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGameFrontendHUD* UGameBackendHUD::GetFirstGameFrontendHUD(class UObject* WorldContextObject)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBackendHUD.GetFirstGameFrontendHUD");

	UGameBackendHUD_GetFirstGameFrontendHUD_Params params;
	params.WorldContextObject = WorldContextObject;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameBusinessManager.GetWidget
// ()
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)
// class UUAEUserWidget*          ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UUAEUserWidget* UGameBusinessManager::GetWidget(int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBusinessManager.GetWidget");

	UGameBusinessManager_GetWidget_Params params;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameBusinessManager.GetLuaObject
// ()
// Parameters:
// class ALuaClassObj*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ALuaClassObj* UGameBusinessManager::GetLuaObject()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBusinessManager.GetLuaObject");

	UGameBusinessManager_GetLuaObject_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameBusinessManager.GetGameFrontendHUD
// ()
// Parameters:
// class UGameFrontendHUD*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGameFrontendHUD* UGameBusinessManager::GetGameFrontendHUD()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameBusinessManager.GetGameFrontendHUD");

	UGameBusinessManager_GetGameFrontendHUD_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.VNGPostPersonalInfo
// ()
// Parameters:
// struct FString                 OpenID                         (Parm, ZeroConstructor)
// struct FString                 Name                           (Parm, ZeroConstructor)
// struct FString                 passportId                     (Parm, ZeroConstructor)
// struct FString                 email                          (Parm, ZeroConstructor)
// struct FString                 phone                          (Parm, ZeroConstructor)
// struct FString                 address                        (Parm, ZeroConstructor)

void UGameFrontendHUD::VNGPostPersonalInfo(const struct FString& OpenID, const struct FString& Name, const struct FString& passportId, const struct FString& email, const struct FString& phone, const struct FString& address)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.VNGPostPersonalInfo");

	UGameFrontendHUD_VNGPostPersonalInfo_Params params;
	params.OpenID = OpenID;
	params.Name = Name;
	params.passportId = passportId;
	params.email = email;
	params.phone = phone;
	params.address = address;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.UnRegisterUIShowHideEventDelegate
// ()
// Parameters:
// struct FString                 Source                         (Parm, ZeroConstructor)

void UGameFrontendHUD::UnRegisterUIShowHideEventDelegate(const struct FString& Source)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.UnRegisterUIShowHideEventDelegate");

	UGameFrontendHUD_UnRegisterUIShowHideEventDelegate_Params params;
	params.Source = Source;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.TimeStatisticStop
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Name                           (Parm, ZeroConstructor)

void UGameFrontendHUD::TimeStatisticStop(int Type, const struct FString& Name)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.TimeStatisticStop");

	UGameFrontendHUD_TimeStatisticStop_Params params;
	params.Type = Type;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.TimeStatisticStart
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::TimeStatisticStart(int Type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.TimeStatisticStart");

	UGameFrontendHUD_TimeStatisticStart_Params params;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.TickUdpCollector
// ()
// Parameters:
// float                          DeltaTime                      (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::TickUdpCollector(float DeltaTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.TickUdpCollector");

	UGameFrontendHUD_TickUdpCollector_Params params;
	params.DeltaTime = DeltaTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.StatisVisibilityWidget
// ()
// Parameters:
// class UWidget*                 Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UGameFrontendHUD::StatisVisibilityWidget(class UWidget* Widget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.StatisVisibilityWidget");

	UGameFrontendHUD_StatisVisibilityWidget_Params params;
	params.Widget = Widget;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.StatisLoadedTexture
// ()
// Parameters:
// class UTexture*                Texture                        (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::StatisLoadedTexture(class UTexture* Texture)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.StatisLoadedTexture");

	UGameFrontendHUD_StatisLoadedTexture_Params params;
	params.Texture = Texture;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.StartGrayUpdate
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::StartGrayUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.StartGrayUpdate");

	UGameFrontendHUD_StartGrayUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.StartDolphinUpdateAfterCDNUpdateFailed
// ()

void UGameFrontendHUD::StartDolphinUpdateAfterCDNUpdateFailed()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.StartDolphinUpdateAfterCDNUpdateFailed");

	UGameFrontendHUD_StartDolphinUpdateAfterCDNUpdateFailed_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.StartCDNUpdateAfterDolphinUpdateFailed
// ()

void UGameFrontendHUD::StartCDNUpdateAfterDolphinUpdateFailed()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.StartCDNUpdateAfterDolphinUpdateFailed");

	UGameFrontendHUD_StartCDNUpdateAfterDolphinUpdateFailed_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.ShutdownUnrealNetwork
// ()

void UGameFrontendHUD::ShutdownUnrealNetwork()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.ShutdownUnrealNetwork");

	UGameFrontendHUD_ShutdownUnrealNetwork_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.SetShouldShowAdaptTipInLobby
// ()
// Parameters:
// bool                           bShoudShow                     (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::SetShouldShowAdaptTipInLobby(bool bShoudShow)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.SetShouldShowAdaptTipInLobby");

	UGameFrontendHUD_SetShouldShowAdaptTipInLobby_Params params;
	params.bShoudShow = bShoudShow;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.SetGameSubMode
// ()
// Parameters:
// struct FString                 SubMode                        (Parm, ZeroConstructor)

void UGameFrontendHUD::SetGameSubMode(const struct FString& SubMode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.SetGameSubMode");

	UGameFrontendHUD_SetGameSubMode_Params params;
	params.SubMode = SubMode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.SetGameStatusMap
// ()
// Parameters:
// TMap<struct FName, struct FString> InGameStatusMap                (Parm, ZeroConstructor)

void UGameFrontendHUD::SetGameStatusMap(TMap<struct FName, struct FString> InGameStatusMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.SetGameStatusMap");

	UGameFrontendHUD_SetGameStatusMap_Params params;
	params.InGameStatusMap = InGameStatusMap;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.SetClientEnterBattleStage
// ()
// Parameters:
// struct FString                 InStageStr                     (Parm, ZeroConstructor)

void UGameFrontendHUD::SetClientEnterBattleStage(const struct FString& InStageStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.SetClientEnterBattleStage");

	UGameFrontendHUD_SetClientEnterBattleStage_Params params;
	params.InStageStr = InStageStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.SetAccountByWebLogin
// ()
// Parameters:
// int                            Channel                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 OpenID                         (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)
// struct FString                 TokenID                        (Parm, ZeroConstructor)
// int                            ExpireTime                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::SetAccountByWebLogin(int Channel, const struct FString& OpenID, const struct FString& userId, const struct FString& TokenID, int ExpireTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.SetAccountByWebLogin");

	UGameFrontendHUD_SetAccountByWebLogin_Params params;
	params.Channel = Channel;
	params.OpenID = OpenID;
	params.userId = userId;
	params.TokenID = TokenID;
	params.ExpireTime = ExpireTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.SaveUserSettingsByDelegate
// ()
// Parameters:
// class USaveGame*               SaveGame                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 LayoutName                     (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::SaveUserSettingsByDelegate(class USaveGame* SaveGame, const struct FString& LayoutName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.SaveUserSettingsByDelegate");

	UGameFrontendHUD_SaveUserSettingsByDelegate_Params params;
	params.SaveGame = SaveGame;
	params.LayoutName = LayoutName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.RetryDownload
// ()

void UGameFrontendHUD::RetryDownload()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RetryDownload");

	UGameFrontendHUD_RetryDownload_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.RetryCDNDownload
// ()

void UGameFrontendHUD::RetryCDNDownload()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RetryCDNDownload");

	UGameFrontendHUD_RetryCDNDownload_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.ResetUserSettings
// ()

void UGameFrontendHUD::ResetUserSettings()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.ResetUserSettings");

	UGameFrontendHUD_ResetUserSettings_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.ReleaseBattleUtils
// ()

void UGameFrontendHUD::ReleaseBattleUtils()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.ReleaseBattleUtils");

	UGameFrontendHUD_ReleaseBattleUtils_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Int
// ()
// Parameters:
// struct FString                 PropertyName                   (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate                       (Parm, ZeroConstructor)

void UGameFrontendHUD::RegisterUserSettingsDelegate_Int(const struct FString& PropertyName, const struct FScriptDelegate& Delegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Int");

	UGameFrontendHUD_RegisterUserSettingsDelegate_Int_Params params;
	params.PropertyName = PropertyName;
	params.Delegate = Delegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Float
// ()
// Parameters:
// struct FString                 PropertyName                   (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate                       (Parm, ZeroConstructor)

void UGameFrontendHUD::RegisterUserSettingsDelegate_Float(const struct FString& PropertyName, const struct FScriptDelegate& Delegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Float");

	UGameFrontendHUD_RegisterUserSettingsDelegate_Float_Params params;
	params.PropertyName = PropertyName;
	params.Delegate = Delegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Enum
// ()
// Parameters:
// struct FString                 PropertyName                   (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate                       (Parm, ZeroConstructor)

void UGameFrontendHUD::RegisterUserSettingsDelegate_Enum(const struct FString& PropertyName, const struct FScriptDelegate& Delegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Enum");

	UGameFrontendHUD_RegisterUserSettingsDelegate_Enum_Params params;
	params.PropertyName = PropertyName;
	params.Delegate = Delegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Bool
// ()
// Parameters:
// struct FString                 PropertyName                   (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate                       (Parm, ZeroConstructor)

void UGameFrontendHUD::RegisterUserSettingsDelegate_Bool(const struct FString& PropertyName, const struct FScriptDelegate& Delegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RegisterUserSettingsDelegate_Bool");

	UGameFrontendHUD_RegisterUserSettingsDelegate_Bool_Params params;
	params.PropertyName = PropertyName;
	params.Delegate = Delegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.RegisterUserSettingsDelegate
// ()
// Parameters:
// struct FScriptDelegate         Delegate                       (Parm, ZeroConstructor)

void UGameFrontendHUD::RegisterUserSettingsDelegate(const struct FScriptDelegate& Delegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RegisterUserSettingsDelegate");

	UGameFrontendHUD_RegisterUserSettingsDelegate_Params params;
	params.Delegate = Delegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.RegisterUIShowHideEventDelegate
// ()
// Parameters:
// struct FString                 Source                         (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate                       (Parm, ZeroConstructor)

void UGameFrontendHUD::RegisterUIShowHideEventDelegate(const struct FString& Source, const struct FScriptDelegate& Delegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.RegisterUIShowHideEventDelegate");

	UGameFrontendHUD_RegisterUIShowHideEventDelegate_Params params;
	params.Source = Source;
	params.Delegate = Delegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnWebviewNotify
// ()
// Parameters:
// struct FWebviewInfoWrapper     webviewinfo                    (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnWebviewNotify(const struct FWebviewInfoWrapper& webviewinfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnWebviewNotify");

	UGameFrontendHUD_OnWebviewNotify_Params params;
	params.webviewinfo = webviewinfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnWebviewActionNotify
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)

void UGameFrontendHUD::OnWebviewActionNotify(const struct FString& URL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnWebviewActionNotify");

	UGameFrontendHUD_OnWebviewActionNotify_Params params;
	params.URL = URL;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnUAAssistantEvent
// ()
// Parameters:
// struct FUAAssistantInfoWrapper UAAssistentInfo                (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnUAAssistantEvent(const struct FUAAssistantInfoWrapper& UAAssistentInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnUAAssistantEvent");

	UGameFrontendHUD_OnUAAssistantEvent_Params params;
	params.UAAssistentInfo = UAAssistentInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnSDKCallbackEvent
// ()
// Parameters:
// struct FSDKCallbackInfoWrapper sdkCallbackInfo                (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnSDKCallbackEvent(const struct FSDKCallbackInfoWrapper& sdkCallbackInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnSDKCallbackEvent");

	UGameFrontendHUD_OnSDKCallbackEvent_Params params;
	params.sdkCallbackInfo = sdkCallbackInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnRequestComplete
// ()
// Parameters:
// struct FCDNDownloaderInfo      Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnRequestComplete(const struct FCDNDownloaderInfo& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnRequestComplete");

	UGameFrontendHUD_OnRequestComplete_Params params;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnRefreshAccountInfo
// ()
// Parameters:
// bool                           Result                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            InChannel                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 InOpenId                       (Parm, ZeroConstructor)

void UGameFrontendHUD::OnRefreshAccountInfo(bool Result, int InChannel, const struct FString& InOpenId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnRefreshAccountInfo");

	UGameFrontendHUD_OnRefreshAccountInfo_Params params;
	params.Result = Result;
	params.InChannel = InChannel;
	params.InOpenId = InOpenId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnQuickLoginNotify
// ()
// Parameters:
// struct FWakeupInfoWrapper      wakeupinfo                     (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnQuickLoginNotify(const struct FWakeupInfoWrapper& wakeupinfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnQuickLoginNotify");

	UGameFrontendHUD_OnQuickLoginNotify_Params params;
	params.wakeupinfo = wakeupinfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnPlatformFriendNotify
// ()
// Parameters:
// struct FPlatformFriendInfoMap  PlatformFriendInfoMap          (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnPlatformFriendNotify(const struct FPlatformFriendInfoMap& PlatformFriendInfoMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnPlatformFriendNotify");

	UGameFrontendHUD_OnPlatformFriendNotify_Params params;
	params.PlatformFriendInfoMap = PlatformFriendInfoMap;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnNotUpdateFinished
// ()

void UGameFrontendHUD::OnNotUpdateFinished()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnNotUpdateFinished");

	UGameFrontendHUD_OnNotUpdateFinished_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnLoginFlowNotify
// ()
// Parameters:
// int                            _Flow                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            _Param                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ExtraData                      (Parm, ZeroConstructor)

void UGameFrontendHUD::OnLoginFlowNotify(int _Flow, int _Param, const struct FString& ExtraData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnLoginFlowNotify");

	UGameFrontendHUD_OnLoginFlowNotify_Params params;
	params._Flow = _Flow;
	params._Param = _Param;
	params.ExtraData = ExtraData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnHttpImgResponse
// ()
// Parameters:
// class UTexture2D*              Texture                        (Parm, ZeroConstructor, IsPlainOldData)
// class UImageDownloader*        downloader                     (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::OnHttpImgResponse(class UTexture2D* Texture, class UImageDownloader* downloader)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnHttpImgResponse");

	UGameFrontendHUD_OnHttpImgResponse_Params params;
	params.Texture = Texture;
	params.downloader = downloader;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnGroupNotify
// ()
// Parameters:
// struct FGroupInfoWrapper       groupInfo                      (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnGroupNotify(const struct FGroupInfoWrapper& groupInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnGroupNotify");

	UGameFrontendHUD_OnGroupNotify_Params params;
	params.groupInfo = groupInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnGetTicketNotify
// ()
// Parameters:
// struct FString                 Ticket                         (Parm, ZeroConstructor)

void UGameFrontendHUD::OnGetTicketNotify(const struct FString& Ticket)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnGetTicketNotify");

	UGameFrontendHUD_OnGetTicketNotify_Params params;
	params.Ticket = Ticket;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnGetShortUrlNotify
// ()
// Parameters:
// int                            Ret                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ShortUrl                       (Parm, ZeroConstructor)

void UGameFrontendHUD::OnGetShortUrlNotify(int Ret, const struct FString& ShortUrl)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnGetShortUrlNotify");

	UGameFrontendHUD_OnGetShortUrlNotify_Params params;
	params.Ret = Ret;
	params.ShortUrl = ShortUrl;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnGetCountryNoNotify
// ()
// Parameters:
// int                            country                        (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::OnGetCountryNoNotify(int country)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnGetCountryNoNotify");

	UGameFrontendHUD_OnGetCountryNoNotify_Params params;
	params.country = country;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnGenQRImgNotify
// ()
// Parameters:
// int                            Ret                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            Size                           (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 imgPath                        (Parm, ZeroConstructor)

void UGameFrontendHUD::OnGenQRImgNotify(int Ret, int Size, const struct FString& imgPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnGenQRImgNotify");

	UGameFrontendHUD_OnGenQRImgNotify_Params params;
	params.Ret = Ret;
	params.Size = Size;
	params.imgPath = imgPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnGCloudNetStateChangeNotify
// ()
// Parameters:
// int                            State                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            EventParam1                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            EventParam2                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            EventParam3                    (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::OnGCloudNetStateChangeNotify(int State, int EventParam1, int EventParam2, int EventParam3)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnGCloudNetStateChangeNotify");

	UGameFrontendHUD_OnGCloudNetStateChangeNotify_Params params;
	params.State = State;
	params.EventParam1 = EventParam1;
	params.EventParam2 = EventParam2;
	params.EventParam3 = EventParam3;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnGameMasterEvent
// ()
// Parameters:
// struct FString                 EventName                      (Parm, ZeroConstructor)
// int                            Ret                            (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::OnGameMasterEvent(const struct FString& EventName, int Ret)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnGameMasterEvent");

	UGameFrontendHUD_OnGameMasterEvent_Params params;
	params.EventName = EventName;
	params.Ret = Ret;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.OnCheckUpdateStateFinished
// ()
// Parameters:
// struct FDownloaderInfo         Info                           (ConstParm, Parm, OutParm, ReferenceParm)

void UGameFrontendHUD::OnCheckUpdateStateFinished(const struct FDownloaderInfo& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.OnCheckUpdateStateFinished");

	UGameFrontendHUD_OnCheckUpdateStateFinished_Params params;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.NotifyLoadingUIOperation
// ()
// Parameters:
// int                            OperationType                  (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::NotifyLoadingUIOperation(int OperationType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.NotifyLoadingUIOperation");

	UGameFrontendHUD_NotifyLoadingUIOperation_Params params;
	params.OperationType = OperationType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.MakeToSuppotAdaptation
// ()
// Parameters:
// class UPanelSlot*              PanelSlot                      (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UGameFrontendHUD::MakeToSuppotAdaptation(class UPanelSlot* PanelSlot)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.MakeToSuppotAdaptation");

	UGameFrontendHUD_MakeToSuppotAdaptation_Params params;
	params.PanelSlot = PanelSlot;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.LuaDoString
// ()
// Parameters:
// struct FString                 LuaString                      (Parm, ZeroConstructor)

void UGameFrontendHUD::LuaDoString(const struct FString& LuaString)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.LuaDoString");

	UGameFrontendHUD_LuaDoString_Params params;
	params.LuaString = LuaString;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.IsWindowOB
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::IsWindowOB()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.IsWindowOB");

	UGameFrontendHUD_IsWindowOB_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.IsInstallPlatform
// ()
// Parameters:
// struct FString                 Platform                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::IsInstallPlatform(const struct FString& Platform)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.IsInstallPlatform");

	UGameFrontendHUD_IsInstallPlatform_Params params;
	params.Platform = Platform;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.IsCEHideLobbyUI
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::IsCEHideLobbyUI()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.IsCEHideLobbyUI");

	UGameFrontendHUD_IsCEHideLobbyUI_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.HasAnyNetMsgToHandle
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::HasAnyNetMsgToHandle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.HasAnyNetMsgToHandle");

	UGameFrontendHUD_HasAnyNetMsgToHandle_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetWidgetRenderCanChange
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::GetWidgetRenderCanChange()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetWidgetRenderCanChange");

	UGameFrontendHUD_GetWidgetRenderCanChange_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetUserSettingsProperty_Int
// ()
// Parameters:
// struct FString                 PropertyName                   (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGameFrontendHUD::GetUserSettingsProperty_Int(const struct FString& PropertyName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetUserSettingsProperty_Int");

	UGameFrontendHUD_GetUserSettingsProperty_Int_Params params;
	params.PropertyName = PropertyName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetUserSettingsProperty_Bool
// ()
// Parameters:
// struct FString                 PropertyName                   (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::GetUserSettingsProperty_Bool(const struct FString& PropertyName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetUserSettingsProperty_Bool");

	UGameFrontendHUD_GetUserSettingsProperty_Bool_Params params;
	params.PropertyName = PropertyName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetUserSettingsByDelegate
// ()
// Parameters:
// struct FString                 LayoutName                     (Parm, ZeroConstructor)
// class USaveGame*               ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class USaveGame* UGameFrontendHUD::GetUserSettingsByDelegate(const struct FString& LayoutName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetUserSettingsByDelegate");

	UGameFrontendHUD_GetUserSettingsByDelegate_Params params;
	params.LayoutName = LayoutName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetUserSettings
// ()
// Parameters:
// class USaveGame*               ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class USaveGame* UGameFrontendHUD::GetUserSettings()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetUserSettings");

	UGameFrontendHUD_GetUserSettings_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetUpdater
// ()
// Parameters:
// class UGDolphinUpdater*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGDolphinUpdater* UGameFrontendHUD::GetUpdater()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetUpdater");

	UGameFrontendHUD_GetUpdater_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetTranslator
// ()
// Parameters:
// class UTranslator*             ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UTranslator* UGameFrontendHUD::GetTranslator()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetTranslator");

	UGameFrontendHUD_GetTranslator_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetShouldShowAdaptTipInLobby
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameFrontendHUD::GetShouldShowAdaptTipInLobby()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetShouldShowAdaptTipInLobby");

	UGameFrontendHUD_GetShouldShowAdaptTipInLobby_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetPufferDownloader
// ()
// Parameters:
// class UGCPufferDownloader*     ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGCPufferDownloader* UGameFrontendHUD::GetPufferDownloader()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetPufferDownloader");

	UGameFrontendHUD_GetPufferDownloader_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetPingReportInfo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGameFrontendHUD::GetPingReportInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetPingReportInfo");

	UGameFrontendHUD_GetPingReportInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetPacketLossReportInfo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGameFrontendHUD::GetPacketLossReportInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetPacketLossReportInfo");

	UGameFrontendHUD_GetPacketLossReportInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetLuaStateWrapper
// ()
// Parameters:
// class ULuaStateWrapper*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ULuaStateWrapper* UGameFrontendHUD::GetLuaStateWrapper()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetLuaStateWrapper");

	UGameFrontendHUD_GetLuaStateWrapper_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetLuaEventBridge
// ()
// Parameters:
// class ULuaEventBridge*         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ULuaEventBridge* UGameFrontendHUD::GetLuaEventBridge()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetLuaEventBridge");

	UGameFrontendHUD_GetLuaEventBridge_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetLuaBlueprintSysMgr
// ()
// Parameters:
// class ULuaBlueprintMgr*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ULuaBlueprintMgr* UGameFrontendHUD::GetLuaBlueprintSysMgr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetLuaBlueprintSysMgr");

	UGameFrontendHUD_GetLuaBlueprintSysMgr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetHttpWrapper
// ()
// Parameters:
// class UHttpWrapper*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UHttpWrapper* UGameFrontendHUD::GetHttpWrapper()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetHttpWrapper");

	UGameFrontendHUD_GetHttpWrapper_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetGVoiceInterface
// ()
// Parameters:
// class UGVoiceInterface*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGVoiceInterface* UGameFrontendHUD::GetGVoiceInterface()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetGVoiceInterface");

	UGameFrontendHUD_GetGVoiceInterface_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetGameSubMode
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGameFrontendHUD::GetGameSubMode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetGameSubMode");

	UGameFrontendHUD_GetGameSubMode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetGameState
// ()
// Parameters:
// class AGameStateBase*          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class AGameStateBase* UGameFrontendHUD::GetGameState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetGameState");

	UGameFrontendHUD_GetGameState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetFPSReportInfo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGameFrontendHUD::GetFPSReportInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetFPSReportInfo");

	UGameFrontendHUD_GetFPSReportInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetEffectSettingMgr
// ()
// Parameters:
// class UEffectSettingMgr*       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UEffectSettingMgr* UGameFrontendHUD::GetEffectSettingMgr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetEffectSettingMgr");

	UGameFrontendHUD_GetEffectSettingMgr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetDetailNetInfoFromGCloud
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGameFrontendHUD::GetDetailNetInfoFromGCloud()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetDetailNetInfoFromGCloud");

	UGameFrontendHUD_GetDetailNetInfoFromGCloud_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetCustomSetting
// ()
// Parameters:
// struct FString                 InSlotName                     (Parm, ZeroConstructor)
// class USaveGame*               ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class USaveGame* UGameFrontendHUD::GetCustomSetting(const struct FString& InSlotName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetCustomSetting");

	UGameFrontendHUD_GetCustomSetting_Params params;
	params.InSlotName = InSlotName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetColorBlindnessMgr
// ()
// Parameters:
// class UColorBlindnessMgr*      ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UColorBlindnessMgr* UGameFrontendHUD::GetColorBlindnessMgr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetColorBlindnessMgr");

	UGameFrontendHUD_GetColorBlindnessMgr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetClientNetObj
// ()
// Parameters:
// class UObject*                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UObject* UGameFrontendHUD::GetClientNetObj()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetClientNetObj");

	UGameFrontendHUD_GetClientNetObj_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetClientEnterBattleStage
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGameFrontendHUD::GetClientEnterBattleStage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetClientEnterBattleStage");

	UGameFrontendHUD_GetClientEnterBattleStage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetBugReporter
// ()
// Parameters:
// class UBugReporter*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UBugReporter* UGameFrontendHUD::GetBugReporter()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetBugReporter");

	UGameFrontendHUD_GetBugReporter_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetBattleUtils
// ()
// Parameters:
// class UBattleUtils*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UBattleUtils* UGameFrontendHUD::GetBattleUtils()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetBattleUtils");

	UGameFrontendHUD_GetBattleUtils_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetBattleIDHexStr
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGameFrontendHUD::GetBattleIDHexStr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetBattleIDHexStr");

	UGameFrontendHUD_GetBattleIDHexStr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetAutoRunModID
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGameFrontendHUD::GetAutoRunModID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetAutoRunModID");

	UGameFrontendHUD_GetAutoRunModID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.GetAsyncLoadHelper
// ()
// Parameters:
// class UAsyncLoadHelper*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UAsyncLoadHelper* UGameFrontendHUD::GetAsyncLoadHelper()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.GetAsyncLoadHelper");

	UGameFrontendHUD_GetAsyncLoadHelper_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameFrontendHUD.FinishModifyUserSettings
// ()

void UGameFrontendHUD::FinishModifyUserSettings()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.FinishModifyUserSettings");

	UGameFrontendHUD_FinishModifyUserSettings_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.EnableFPSAndMemoryLog
// ()
// Parameters:
// bool                           bEnable                        (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::EnableFPSAndMemoryLog(bool bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.EnableFPSAndMemoryLog");

	UGameFrontendHUD_EnableFPSAndMemoryLog_Params params;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.DispatchLongTimeNoOperation
// ()
// Parameters:
// int                            TimeOutCounter                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void UGameFrontendHUD::DispatchLongTimeNoOperation(int TimeOutCounter)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.DispatchLongTimeNoOperation");

	UGameFrontendHUD_DispatchLongTimeNoOperation_Params params;
	params.TimeOutCounter = TimeOutCounter;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.DispatchConfirmMisKill
// ()
// Parameters:
// struct FString                 KillerName                     (Parm, ZeroConstructor)

void UGameFrontendHUD::DispatchConfirmMisKill(const struct FString& KillerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.DispatchConfirmMisKill");

	UGameFrontendHUD_DispatchConfirmMisKill_Params params;
	params.KillerName = KillerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.CreateBattleUtils
// ()

void UGameFrontendHUD::CreateBattleUtils()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.CreateBattleUtils");

	UGameFrontendHUD_CreateBattleUtils_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.ClearUIElemSettings
// ()

void UGameFrontendHUD::ClearUIElemSettings()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.ClearUIElemSettings");

	UGameFrontendHUD_ClearUIElemSettings_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.CheckLocalizationLanguage
// ()

void UGameFrontendHUD::CheckLocalizationLanguage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.CheckLocalizationLanguage");

	UGameFrontendHUD_CheckLocalizationLanguage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.CallGlobalScriptFunction
// ()
// Parameters:
// struct FString                 InFunctionName                 (Parm, ZeroConstructor)

void UGameFrontendHUD::CallGlobalScriptFunction(const struct FString& InFunctionName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.CallGlobalScriptFunction");

	UGameFrontendHUD_CallGlobalScriptFunction_Params params;
	params.InFunctionName = InFunctionName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.BeginModifyUserSettings
// ()

void UGameFrontendHUD::BeginModifyUserSettings()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.BeginModifyUserSettings");

	UGameFrontendHUD_BeginModifyUserSettings_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.BattleUtilsGameEnd
// ()

void UGameFrontendHUD::BattleUtilsGameEnd()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.BattleUtilsGameEnd");

	UGameFrontendHUD_BattleUtilsGameEnd_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.AfterLoadedEditorLogin
// ()

void UGameFrontendHUD::AfterLoadedEditorLogin()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.AfterLoadedEditorLogin");

	UGameFrontendHUD_AfterLoadedEditorLogin_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.AddCustomSetting
// ()
// Parameters:
// struct FString                 InSlotName                     (Parm, ZeroConstructor)
// class USaveGame*               InSaveGame                     (Parm, ZeroConstructor, IsPlainOldData)

void UGameFrontendHUD::AddCustomSetting(const struct FString& InSlotName, class USaveGame* InSaveGame)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.AddCustomSetting");

	UGameFrontendHUD_AddCustomSetting_Params params;
	params.InSlotName = InSlotName;
	params.InSaveGame = InSaveGame;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.AddAdaptationWidgetDelegateEx
// ()
// Parameters:
// class UPanelSlot*              PanelSlot                      (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UGameFrontendHUD::AddAdaptationWidgetDelegateEx(class UPanelSlot* PanelSlot)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.AddAdaptationWidgetDelegateEx");

	UGameFrontendHUD_AddAdaptationWidgetDelegateEx_Params params;
	params.PanelSlot = PanelSlot;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameFrontendHUD.AddAdaptationWidgetDelegate
// ()
// Parameters:
// class UPanelSlot*              PanelSlot                      (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UGameFrontendHUD::AddAdaptationWidgetDelegate(class UPanelSlot* PanelSlot)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameFrontendHUD.AddAdaptationWidgetDelegate");

	UGameFrontendHUD_AddAdaptationWidgetDelegate_Params params;
	params.PanelSlot = PanelSlot;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.ShareVideo
// ()
// Parameters:
// int                            Channel                        (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::ShareVideo(int Channel)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.ShareVideo");

	UGameJoyInterface_ShareVideo_Params params;
	params.Channel = Channel;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.SetGameFrontendHUD
// ()
// Parameters:
// class UGameFrontendHUD*        InHUD                          (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::SetGameFrontendHUD(class UGameFrontendHUD* InHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.SetGameFrontendHUD");

	UGameJoyInterface_SetGameFrontendHUD_Params params;
	params.InHUD = InHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.OnVideoShare
// ()
// Parameters:
// struct FString                 Msg                            (Parm, ZeroConstructor)

void UGameJoyInterface::OnVideoShare(const struct FString& Msg)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.OnVideoShare");

	UGameJoyInterface_OnVideoShare_Params params;
	params.Msg = Msg;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.OnShowVideoPlayer
// ()
// Parameters:
// int                            IsShow                         (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::OnShowVideoPlayer(int IsShow)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.OnShowVideoPlayer");

	UGameJoyInterface_OnShowVideoPlayer_Params params;
	params.IsShow = IsShow;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.OnRecordingStart
// ()
// Parameters:
// int                            Status                         (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::OnRecordingStart(int Status)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.OnRecordingStart");

	UGameJoyInterface_OnRecordingStart_Params params;
	params.Status = Status;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.OnRecordingEnd
// ()
// Parameters:
// int64_t                        Duration                       (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::OnRecordingEnd(int64_t Duration)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.OnRecordingEnd");

	UGameJoyInterface_OnRecordingEnd_Params params;
	params.Duration = Duration;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.OnManualRecordingStart
// ()
// Parameters:
// int                            Status                         (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::OnManualRecordingStart(int Status)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.OnManualRecordingStart");

	UGameJoyInterface_OnManualRecordingStart_Params params;
	params.Status = Status;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.OnCheckSDKPermission
// ()
// Parameters:
// bool                           IsSuccess                      (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::OnCheckSDKPermission(bool IsSuccess)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.OnCheckSDKPermission");

	UGameJoyInterface_OnCheckSDKPermission_Params params;
	params.IsSuccess = IsSuccess;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.OnCheckSDKFeature
// ()
// Parameters:
// int                            sdkFeatureInt                  (Parm, ZeroConstructor, IsPlainOldData)

void UGameJoyInterface::OnCheckSDKFeature(int sdkFeatureInt)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.OnCheckSDKFeature");

	UGameJoyInterface_OnCheckSDKFeature_Params params;
	params.sdkFeatureInt = sdkFeatureInt;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GameJoyInterface.IsSDKFeatureSupport
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGameJoyInterface::IsSDKFeatureSupport()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.IsSDKFeatureSupport");

	UGameJoyInterface_IsSDKFeatureSupport_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GameJoyInterface.GetInstance
// ()
// Parameters:
// class UGameJoyInterface*       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UGameJoyInterface* UGameJoyInterface::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GameJoyInterface.GetInstance");

	UGameJoyInterface_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.StartAppUpdate
// ()

void UGDolphinUpdater::StartAppUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.StartAppUpdate");

	UGDolphinUpdater_StartAppUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.SetEnableCDNGetVersion
// ()
// Parameters:
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UGDolphinUpdater::SetEnableCDNGetVersion(bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.SetEnableCDNGetVersion");

	UGDolphinUpdater_SetEnableCDNGetVersion_Params params;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.OnUpdateError
// ()
// Parameters:
// int                            curVersionStage                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ErrorCode                      (Parm, ZeroConstructor, IsPlainOldData)

void UGDolphinUpdater::OnUpdateError(int curVersionStage, int ErrorCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.OnUpdateError");

	UGDolphinUpdater_OnUpdateError_Params params;
	params.curVersionStage = curVersionStage;
	params.ErrorCode = ErrorCode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.OnDolphinBGDownloadDone
// ()

void UGDolphinUpdater::OnDolphinBGDownloadDone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.OnDolphinBGDownloadDone");

	UGDolphinUpdater_OnDolphinBGDownloadDone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.IsUpdating
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGDolphinUpdater::IsUpdating()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.IsUpdating");

	UGDolphinUpdater_IsUpdating_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.IsGrayUpdate
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGDolphinUpdater::IsGrayUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.IsGrayUpdate");

	UGDolphinUpdater_IsGrayUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.IsExamine
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGDolphinUpdater::IsExamine()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.IsExamine");

	UGDolphinUpdater_IsExamine_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.Install
// ()

void UGDolphinUpdater::Install()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.Install");

	UGDolphinUpdater_Install_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.GetTotalValue
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGDolphinUpdater::GetTotalValue()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.GetTotalValue");

	UGDolphinUpdater_GetTotalValue_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.GetCurValue
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGDolphinUpdater::GetCurValue()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.GetCurValue");

	UGDolphinUpdater_GetCurValue_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.GetCurStage
// ()
// Parameters:
// float                          percent                        (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            GetCurVal                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            GetMaxVal                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGDolphinUpdater::GetCurStage(float* percent, int* GetCurVal, int* GetMaxVal)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.GetCurStage");

	UGDolphinUpdater_GetCurStage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (percent != nullptr)
		*percent = params.percent;
	if (GetCurVal != nullptr)
		*GetCurVal = params.GetCurVal;
	if (GetMaxVal != nullptr)
		*GetMaxVal = params.GetMaxVal;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.GetCurPercent
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UGDolphinUpdater::GetCurPercent()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.GetCurPercent");

	UGDolphinUpdater_GetCurPercent_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.GetChannelIDWithHUD
// ()
// Parameters:
// class UGameFrontendHUD*        InGameFrontendHUD              (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UGDolphinUpdater::GetChannelIDWithHUD(class UGameFrontendHUD* InGameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.GetChannelIDWithHUD");

	UGDolphinUpdater_GetChannelIDWithHUD_Params params;
	params.InGameFrontendHUD = InGameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.GetChannelID
// ()
// Parameters:
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UGDolphinUpdater::GetChannelID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.GetChannelID");

	UGDolphinUpdater_GetChannelID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.FinishUpdate
// ()

void UGDolphinUpdater::FinishUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.FinishUpdate");

	UGDolphinUpdater_FinishUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.FinishPufferUpdate
// ()

void UGDolphinUpdater::FinishPufferUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.FinishPufferUpdate");

	UGDolphinUpdater_FinishPufferUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.EnableIOSBGDownload4G
// ()
// Parameters:
// bool                           bEnableCellularAccess          (Parm, ZeroConstructor, IsPlainOldData)

void UGDolphinUpdater::EnableIOSBGDownload4G(bool bEnableCellularAccess)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.EnableIOSBGDownload4G");

	UGDolphinUpdater_EnableIOSBGDownload4G_Params params;
	params.bEnableCellularAccess = bEnableCellularAccess;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.EnableCDNGetVersion
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGDolphinUpdater::EnableCDNGetVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.EnableCDNGetVersion");

	UGDolphinUpdater_EnableCDNGetVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GDolphinUpdater.ContinueUpdate
// ()

void UGDolphinUpdater::ContinueUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.ContinueUpdate");

	UGDolphinUpdater_ContinueUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.CancelUpdate
// ()

void UGDolphinUpdater::CancelUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.CancelUpdate");

	UGDolphinUpdater_CancelUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GDolphinUpdater.CancelAppUpdate
// ()

void UGDolphinUpdater::CancelAppUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GDolphinUpdater.CancelAppUpdate");

	UGDolphinUpdater_CancelAppUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.IMSDKNotice.GetNotice
// ()
// Parameters:
// struct FString                 Scene                          (Parm, ZeroConstructor)
// TArray<struct FIMSDKNoticeInfo> ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FIMSDKNoticeInfo> UIMSDKNotice::GetNotice(const struct FString& Scene)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IMSDKNotice.GetNotice");

	UIMSDKNotice_GetNotice_Params params;
	params.Scene = Scene;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IMSDKNotice.GetInstance
// ()
// Parameters:
// class UIMSDKNotice*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UIMSDKNotice* UIMSDKNotice::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IMSDKNotice.GetInstance");

	UIMSDKNotice_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.IMSDKNotice.ClearNotice
// ()

void UIMSDKNotice::ClearNotice()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.IMSDKNotice.ClearNotice");

	UIMSDKNotice_ClearNotice_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AvatarItemDownloadPuffer.StartDownloadItem
// ()
// Parameters:
// uint32_t                       ItemId                         (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         OnItemDownloadDelegate         (Parm, ZeroConstructor)

void UAvatarItemDownloadPuffer::StartDownloadItem(uint32_t ItemId, uint32_t Priority, const struct FScriptDelegate& OnItemDownloadDelegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AvatarItemDownloadPuffer.StartDownloadItem");

	UAvatarItemDownloadPuffer_StartDownloadItem_Params params;
	params.ItemId = ItemId;
	params.Priority = Priority;
	params.OnItemDownloadDelegate = OnItemDownloadDelegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AvatarItemDownloadPuffer.StartBatchDownloadItem
// ()
// Parameters:
// TArray<uint32_t>               ItemIDs                        (Parm, ZeroConstructor)
// uint32_t                       Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         OnBatchItemDownloadDelegate    (Parm, ZeroConstructor)

void UAvatarItemDownloadPuffer::StartBatchDownloadItem(TArray<uint32_t> ItemIDs, uint32_t Priority, const struct FScriptDelegate& OnBatchItemDownloadDelegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AvatarItemDownloadPuffer.StartBatchDownloadItem");

	UAvatarItemDownloadPuffer_StartBatchDownloadItem_Params params;
	params.ItemIDs = ItemIDs;
	params.Priority = Priority;
	params.OnBatchItemDownloadDelegate = OnBatchItemDownloadDelegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.StopTask
// ()
// Parameters:
// uint64_t                       TaskId                         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::StopTask(uint64_t TaskId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StopTask");

	UGCPufferDownloader_StopTask_Params params;
	params.TaskId = TaskId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.StopMergeBinDiffPak
// ()
// Parameters:
// int                            outterTaskID                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::StopMergeBinDiffPak(int outterTaskID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StopMergeBinDiffPak");

	UGCPufferDownloader_StopMergeBinDiffPak_Params params;
	params.outterTaskID = outterTaskID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.StopCheckDownloadFileFraming
// ()
// Parameters:
// int                            outterTaskID                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::StopCheckDownloadFileFraming(int outterTaskID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StopCheckDownloadFileFraming");

	UGCPufferDownloader_StopCheckDownloadFileFraming_Params params;
	params.outterTaskID = outterTaskID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.StopBGDownloadNotification
// ()

void UGCPufferDownloader::StopBGDownloadNotification()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StopBGDownloadNotification");

	UGCPufferDownloader_StopBGDownloadNotification_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.StopAllTask
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::StopAllTask()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StopAllTask");

	UGCPufferDownloader_StopAllTask_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.StartDownloadItem
// ()
// Parameters:
// uint32_t                       ItemId                         (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         downloadDelegate               (Parm, ZeroConstructor)

void UGCPufferDownloader::StartDownloadItem(uint32_t ItemId, uint32_t Priority, const struct FScriptDelegate& downloadDelegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StartDownloadItem");

	UGCPufferDownloader_StartDownloadItem_Params params;
	params.ItemId = ItemId;
	params.Priority = Priority;
	params.downloadDelegate = downloadDelegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.StartBGDownloadNotification
// ()
// Parameters:
// uint64_t                       InDownloadedSize               (Parm, ZeroConstructor, IsPlainOldData)

void UGCPufferDownloader::StartBGDownloadNotification(uint64_t InDownloadedSize)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StartBGDownloadNotification");

	UGCPufferDownloader_StartBGDownloadNotification_Params params;
	params.InDownloadedSize = InDownloadedSize;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.StartBatchDownloadItem
// ()
// Parameters:
// TArray<uint32_t>               ItemIDs                        (Parm, ZeroConstructor)
// uint32_t                       Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         OnBatchItemDownloadDelegate    (Parm, ZeroConstructor)

void UGCPufferDownloader::StartBatchDownloadItem(TArray<uint32_t> ItemIDs, uint32_t Priority, const struct FScriptDelegate& OnBatchItemDownloadDelegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.StartBatchDownloadItem");

	UGCPufferDownloader_StartBatchDownloadItem_Params params;
	params.ItemIDs = ItemIDs;
	params.Priority = Priority;
	params.OnBatchItemDownloadDelegate = OnBatchItemDownloadDelegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.SetTempProductIdBase
// ()
// Parameters:
// int                            ProductIdRaw                   (Parm, ZeroConstructor, IsPlainOldData)

void UGCPufferDownloader::SetTempProductIdBase(int ProductIdRaw)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.SetTempProductIdBase");

	UGCPufferDownloader_SetTempProductIdBase_Params params;
	params.ProductIdRaw = ProductIdRaw;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.SetTempProductId
// ()
// Parameters:
// struct FString                 ProductIdRaw                   (Parm, ZeroConstructor)

void UGCPufferDownloader::SetTempProductId(const struct FString& ProductIdRaw)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.SetTempProductId");

	UGCPufferDownloader_SetTempProductId_Params params;
	params.ProductIdRaw = ProductIdRaw;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.SetPrefetchConfig
// ()
// Parameters:
// bool                           pakEnable                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           fileClearEnable                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           convertEnable                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            reserveredDiskSpace            (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FileList                       (Parm, ZeroConstructor)
// int                            InPreFetchODPaksMaxNum         (Parm, ZeroConstructor, IsPlainOldData)
// int                            InPreFetchODPaksBatchSize      (Parm, ZeroConstructor, IsPlainOldData)

void UGCPufferDownloader::SetPrefetchConfig(bool pakEnable, bool fileClearEnable, bool convertEnable, int reserveredDiskSpace, const struct FString& FileList, int InPreFetchODPaksMaxNum, int InPreFetchODPaksBatchSize)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.SetPrefetchConfig");

	UGCPufferDownloader_SetPrefetchConfig_Params params;
	params.pakEnable = pakEnable;
	params.fileClearEnable = fileClearEnable;
	params.convertEnable = convertEnable;
	params.reserveredDiskSpace = reserveredDiskSpace;
	params.FileList = FileList;
	params.InPreFetchODPaksMaxNum = InPreFetchODPaksMaxNum;
	params.InPreFetchODPaksBatchSize = InPreFetchODPaksBatchSize;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.SetIOSBGDownloadAttribute
// ()
// Parameters:
// bool                           bEnableCellularAccess          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnableResumeData              (Parm, ZeroConstructor, IsPlainOldData)
// int                            nMinFileSize                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            nMaxTasks                      (Parm, ZeroConstructor, IsPlainOldData)

void UGCPufferDownloader::SetIOSBGDownloadAttribute(bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.SetIOSBGDownloadAttribute");

	UGCPufferDownloader_SetIOSBGDownloadAttribute_Params params;
	params.bEnableCellularAccess = bEnableCellularAccess;
	params.bEnableResumeData = bEnableResumeData;
	params.nMinFileSize = nMinFileSize;
	params.nMaxTasks = nMaxTasks;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.SetImmDLMaxSpeed
// ()
// Parameters:
// uint64_t                       MaxSpeed                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::SetImmDLMaxSpeed(uint64_t MaxSpeed)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.SetImmDLMaxSpeed");

	UGCPufferDownloader_SetImmDLMaxSpeed_Params params;
	params.MaxSpeed = MaxSpeed;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ReturnSplitMiniPakFilelist_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::ReturnSplitMiniPakFilelist_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ReturnSplitMiniPakFilelist_LuaState");

	UGCPufferDownloader_ReturnSplitMiniPakFilelist_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ReturnLocalFiles_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::ReturnLocalFiles_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ReturnLocalFiles_LuaState");

	UGCPufferDownloader_ReturnLocalFiles_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.RequestFile
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// bool                           ForceUpdate                    (Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint64_t UGCPufferDownloader::RequestFile(const struct FString& FilePath, bool ForceUpdate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.RequestFile");

	UGCPufferDownloader_RequestFile_Params params;
	params.FilePath = FilePath;
	params.ForceUpdate = ForceUpdate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.RemountPakFiles
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::RemountPakFiles()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.RemountPakFiles");

	UGCPufferDownloader_RemountPakFiles_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ReadFile
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGCPufferDownloader::ReadFile(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ReadFile");

	UGCPufferDownloader_ReadFile_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.PreFetchPakFiles
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::PreFetchPakFiles()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.PreFetchPakFiles");

	UGCPufferDownloader_PreFetchPakFiles_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.PreFetchODPakFilesUpdate
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::PreFetchODPakFilesUpdate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.PreFetchODPakFilesUpdate");

	UGCPufferDownloader_PreFetchODPakFilesUpdate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.PreFetchODPakFilesPreProcess
// ()
// Parameters:
// bool                           Start                          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::PreFetchODPakFilesPreProcess(bool Start)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.PreFetchODPakFilesPreProcess");

	UGCPufferDownloader_PreFetchODPakFilesPreProcess_Params params;
	params.Start = Start;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.PreFetchODPakFilesPostProcess
// ()
// Parameters:
// int                            ErrorCode                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::PreFetchODPakFilesPostProcess(int ErrorCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.PreFetchODPakFilesPostProcess");

	UGCPufferDownloader_PreFetchODPakFilesPostProcess_Params params;
	params.ErrorCode = ErrorCode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.PreFetchODPakFiles
// ()
// Parameters:
// bool                           Start                          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::PreFetchODPakFiles(bool Start)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.PreFetchODPakFiles");

	UGCPufferDownloader_PreFetchODPakFiles_Params params;
	params.Start = Start;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.OnItemDownloadedInFighting
// ()
// Parameters:
// struct FString                 PackHash                       (Parm, ZeroConstructor)
// struct FString                 ErrorCode                      (Parm, ZeroConstructor)

void UGCPufferDownloader::OnItemDownloadedInFighting(const struct FString& PackHash, const struct FString& ErrorCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.OnItemDownloadedInFighting");

	UGCPufferDownloader_OnItemDownloadedInFighting_Params params;
	params.PackHash = PackHash;
	params.ErrorCode = ErrorCode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.OnHashGenerateFinished
// ()
// Parameters:
// int                            outterTaskID                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 hashCode                       (Parm, ZeroConstructor)

void UGCPufferDownloader::OnHashGenerateFinished(int outterTaskID, const struct FString& hashCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.OnHashGenerateFinished");

	UGCPufferDownloader_OnHashGenerateFinished_Params params;
	params.outterTaskID = outterTaskID;
	params.hashCode = hashCode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.MoveFileTo
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// struct FString                 from                           (Parm, ZeroConstructor)
// struct FString                 to                             (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::MoveFileTo(const struct FString& Filename, const struct FString& from, const struct FString& to)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.MoveFileTo");

	UGCPufferDownloader_MoveFileTo_Params params;
	params.Filename = Filename;
	params.from = from;
	params.to = to;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.MoveFile
// ()
// Parameters:
// struct FString                 from                           (Parm, ZeroConstructor)
// struct FString                 to                             (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::MoveFile(const struct FString& from, const struct FString& to)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.MoveFile");

	UGCPufferDownloader_MoveFile_Params params;
	params.from = from;
	params.to = to;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.MergeBinDiffPak
// ()
// Parameters:
// int                            outterTaskID                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 PakFilenameOld                 (Parm, ZeroConstructor)
// struct FString                 PakFilenameDiff                (Parm, ZeroConstructor)
// struct FString                 PakFilenameNew                 (Parm, ZeroConstructor)
// bool                           fast                           (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::MergeBinDiffPak(int outterTaskID, const struct FString& PakFilenameOld, const struct FString& PakFilenameDiff, const struct FString& PakFilenameNew, bool fast)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.MergeBinDiffPak");

	UGCPufferDownloader_MergeBinDiffPak_Params params;
	params.outterTaskID = outterTaskID;
	params.PakFilenameOld = PakFilenameOld;
	params.PakFilenameDiff = PakFilenameDiff;
	params.PakFilenameNew = PakFilenameNew;
	params.fast = fast;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.IsODPaks
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::IsODPaks(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.IsODPaks");

	UGCPufferDownloader_IsODPaks_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.IsODFileExists
// ()
// Parameters:
// struct FString                 Path                           (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::IsODFileExists(const struct FString& Path)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.IsODFileExists");

	UGCPufferDownloader_IsODFileExists_Params params;
	params.Path = Path;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.IsInitSuccess
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::IsInitSuccess()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.IsInitSuccess");

	UGCPufferDownloader_IsInitSuccess_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.IsFileReady
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::IsFileReady(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.IsFileReady");

	UGCPufferDownloader_IsFileReady_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.IsFileExist
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// struct FString                 extension                      (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::IsFileExist(const struct FString& Filename, const struct FString& extension)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.IsFileExist");

	UGCPufferDownloader_IsFileExist_Params params;
	params.Filename = Filename;
	params.extension = extension;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.InitializeODPaks
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::InitializeODPaks()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.InitializeODPaks");

	UGCPufferDownloader_InitializeODPaks_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetTempWorkPath
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGCPufferDownloader::GetTempWorkPath()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetTempWorkPath");

	UGCPufferDownloader_GetTempWorkPath_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetProductIDBase
// ()
// Parameters:
// TArray<int>                    ProductIDs                     (Parm, OutParm, ZeroConstructor)

void UGCPufferDownloader::GetProductIDBase(TArray<int>* ProductIDs)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetProductIDBase");

	UGCPufferDownloader_GetProductIDBase_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ProductIDs != nullptr)
		*ProductIDs = params.ProductIDs;
}


// Function Client.GCPufferDownloader.GetProductID
// ()
// Parameters:
// TArray<int>                    ProductIDs                     (Parm, OutParm, ZeroConstructor)

void UGCPufferDownloader::GetProductID(TArray<int>* ProductIDs)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetProductID");

	UGCPufferDownloader_GetProductID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ProductIDs != nullptr)
		*ProductIDs = params.ProductIDs;
}


// Function Client.GCPufferDownloader.GetODPakNum
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::GetODPakNum()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetODPakNum");

	UGCPufferDownloader_GetODPakNum_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetODPakName
// ()
// Parameters:
// struct FString                 Path                           (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGCPufferDownloader::GetODPakName(const struct FString& Path)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetODPakName");

	UGCPufferDownloader_GetODPakName_Params params;
	params.Path = Path;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetInitErrcode
// ()
// Parameters:
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UGCPufferDownloader::GetInitErrcode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetInitErrcode");

	UGCPufferDownloader_GetInitErrcode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetFileSizeCompressed
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// uint64_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint64_t UGCPufferDownloader::GetFileSizeCompressed(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetFileSizeCompressed");

	UGCPufferDownloader_GetFileSizeCompressed_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetFileSize
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UGCPufferDownloader::GetFileSize(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetFileSize");

	UGCPufferDownloader_GetFileSize_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetDownloadPath
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGCPufferDownloader::GetDownloadPath()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetDownloadPath");

	UGCPufferDownloader_GetDownloadPath_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetCurrentSpeed
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UGCPufferDownloader::GetCurrentSpeed()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetCurrentSpeed");

	UGCPufferDownloader_GetCurrentSpeed_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.GetBatchODPaksDownloadList_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGCPufferDownloader::GetBatchODPaksDownloadList_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.GetBatchODPaksDownloadList_LuaState");

	UGCPufferDownloader_GetBatchODPaksDownloadList_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.EnableUseOldInterface
// ()
// Parameters:
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UGCPufferDownloader::EnableUseOldInterface(bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.EnableUseOldInterface");

	UGCPufferDownloader_EnableUseOldInterface_Params params;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GCPufferDownloader.DeleteFileEvenIfUnfinished
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::DeleteFileEvenIfUnfinished(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.DeleteFileEvenIfUnfinished");

	UGCPufferDownloader_DeleteFileEvenIfUnfinished_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.DeleteFile
// ()
// Parameters:
// struct FString                 fullPath                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::DeleteFile(const struct FString& fullPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.DeleteFile");

	UGCPufferDownloader_DeleteFile_Params params;
	params.fullPath = fullPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ConvertPreFetchFiles
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::ConvertPreFetchFiles()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ConvertPreFetchFiles");

	UGCPufferDownloader_ConvertPreFetchFiles_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ConvertItemIdToPakName
// ()
// Parameters:
// uint32_t                       ItemId                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UGCPufferDownloader::ConvertItemIdToPakName(uint32_t ItemId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ConvertItemIdToPakName");

	UGCPufferDownloader_ConvertItemIdToPakName_Params params;
	params.ItemId = ItemId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ClearUselessODPaks
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::ClearUselessODPaks()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ClearUselessODPaks");

	UGCPufferDownloader_ClearUselessODPaks_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ClearPreFetchODPaksFiles
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::ClearPreFetchODPaksFiles()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ClearPreFetchODPaksFiles");

	UGCPufferDownloader_ClearPreFetchODPaksFiles_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.ClearPreFetchFiles
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::ClearPreFetchFiles()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.ClearPreFetchFiles");

	UGCPufferDownloader_ClearPreFetchFiles_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GCPufferDownloader.CheckDownloadFileFraming
// ()
// Parameters:
// int                            outterTaskID                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Filename                       (Parm, ZeroConstructor)
// int                            chunkSize                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGCPufferDownloader::CheckDownloadFileFraming(int outterTaskID, const struct FString& Filename, int chunkSize)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GCPufferDownloader.CheckDownloadFileFraming");

	UGCPufferDownloader_CheckDownloadFileFraming_Params params;
	params.outterTaskID = outterTaskID;
	params.Filename = Filename;
	params.chunkSize = chunkSize;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GMLogShare.ShareLogFile
// ()

void UGMLogShare::ShareLogFile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GMLogShare.ShareLogFile");

	UGMLogShare_ShareLogFile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GMLogShare.Init
// ()

void UGMLogShare::Init()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GMLogShare.Init");

	UGMLogShare_Init_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.UploadRecordFile
// ()

void UGVoiceInterface::UploadRecordFile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.UploadRecordFile");

	UGVoiceInterface_UploadRecordFile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.TestMic
// ()

void UGVoiceInterface::TestMic()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.TestMic");

	UGVoiceInterface_TestMic_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.TeamSpeakerEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::TeamSpeakerEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.TeamSpeakerEnable");

	UGVoiceInterface_TeamSpeakerEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.TeamMicphoneEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::TeamMicphoneEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.TeamMicphoneEnable");

	UGVoiceInterface_TeamMicphoneEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.SwitchMode
// ()
// Parameters:
// ECharacterMainType             CharMode                       (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SwitchMode(ECharacterMainType CharMode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SwitchMode");

	UGVoiceInterface_SwitchMode_Params params;
	params.CharMode = CharMode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SwitchMicphoneWhenCorpsMode
// ()

void UGVoiceInterface::SwitchMicphoneWhenCorpsMode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SwitchMicphoneWhenCorpsMode");

	UGVoiceInterface_SwitchMicphoneWhenCorpsMode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SwitchCampRoom
// ()
// Parameters:
// ECharacterMainType             campMode                       (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SwitchCampRoom(ECharacterMainType campMode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SwitchCampRoom");

	UGVoiceInterface_SwitchCampRoom_Params params;
	params.campMode = campMode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.StopRecord
// ()

void UGVoiceInterface::StopRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.StopRecord");

	UGVoiceInterface_StopRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.StopPlayRecordFile
// ()

void UGVoiceInterface::StopPlayRecordFile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.StopPlayRecordFile");

	UGVoiceInterface_StopPlayRecordFile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.StopInterphone
// ()

void UGVoiceInterface::StopInterphone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.StopInterphone");

	UGVoiceInterface_StopInterphone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.StopCampMode
// ()

void UGVoiceInterface::StopCampMode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.StopCampMode");

	UGVoiceInterface_StopCampMode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.StartRecord
// ()

void UGVoiceInterface::StartRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.StartRecord");

	UGVoiceInterface_StartRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.StartInterphone
// ()

void UGVoiceInterface::StartInterphone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.StartInterphone");

	UGVoiceInterface_StartInterphone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.StartCampMode
// ()
// Parameters:
// struct FString                 ZombieCampRoomName             (Parm, ZeroConstructor)
// struct FString                 ManCampRoomName                (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)

void UGVoiceInterface::StartCampMode(const struct FString& ZombieCampRoomName, const struct FString& ManCampRoomName, const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.StartCampMode");

	UGVoiceInterface_StartCampMode_Params params;
	params.ZombieCampRoomName = ZombieCampRoomName;
	params.ManCampRoomName = ManCampRoomName;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SpeechToText
// ()

void UGVoiceInterface::SpeechToText()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SpeechToText");

	UGVoiceInterface_SpeechToText_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ShowOpenSpeakerAtFirstMsg
// ()

void UGVoiceInterface::ShowOpenSpeakerAtFirstMsg()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ShowOpenSpeakerAtFirstMsg");

	UGVoiceInterface_ShowOpenSpeakerAtFirstMsg_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ShowCorpsModeCannotUseLBSVoice
// ()

void UGVoiceInterface::ShowCorpsModeCannotUseLBSVoice()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ShowCorpsModeCannotUseLBSVoice");

	UGVoiceInterface_ShowCorpsModeCannotUseLBSVoice_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetVoiceMode
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetVoiceMode(int Type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetVoiceMode");

	UGVoiceInterface_SetVoiceMode_Params params;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetSpeakerVolum
// ()
// Parameters:
// float                          Value                          (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetSpeakerVolum(float Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetSpeakerVolum");

	UGVoiceInterface_SetSpeakerVolum_Params params;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetSpeakerStatus
// ()
// Parameters:
// bool                           Flag                           (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetSpeakerStatus(bool Flag)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetSpeakerStatus");

	UGVoiceInterface_SetSpeakerStatus_Params params;
	params.Flag = Flag;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetPlayerVolume
// ()
// Parameters:
// struct FString                 InPlayerid                     (Parm, ZeroConstructor)
// int                            InVol                          (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetPlayerVolume(const struct FString& InPlayerid, int InVol)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetPlayerVolume");

	UGVoiceInterface_SetPlayerVolume_Params params;
	params.InPlayerid = InPlayerid;
	params.InVol = InVol;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetMicphoneVolum
// ()
// Parameters:
// float                          Value                          (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetMicphoneVolum(float Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetMicphoneVolum");

	UGVoiceInterface_SetMicphoneVolum_Params params;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetMicphoneStatus
// ()
// Parameters:
// bool                           Flag                           (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetMicphoneStatus(bool Flag)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetMicphoneStatus");

	UGVoiceInterface_SetMicphoneStatus_Params params;
	params.Flag = Flag;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetLbsVoiceRadius
// ()
// Parameters:
// float                          Radius                         (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetLbsVoiceRadius(float Radius)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetLbsVoiceRadius");

	UGVoiceInterface_SetLbsVoiceRadius_Params params;
	params.Radius = Radius;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetLbsRoomEnableStatus
// ()
// Parameters:
// bool                           Flag                           (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetLbsRoomEnableStatus(bool Flag)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetLbsRoomEnableStatus");

	UGVoiceInterface_SetLbsRoomEnableStatus_Params params;
	params.Flag = Flag;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetGameFrontendHUD
// ()
// Parameters:
// class UGameFrontendHUD*        InHUD                          (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetGameFrontendHUD(class UGameFrontendHUD* InHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetGameFrontendHUD");

	UGVoiceInterface_SetGameFrontendHUD_Params params;
	params.InHUD = InHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetCurrentDownloadFieldID
// ()
// Parameters:
// struct FString                 filedId                        (Parm, ZeroConstructor)

void UGVoiceInterface::SetCurrentDownloadFieldID(const struct FString& filedId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetCurrentDownloadFieldID");

	UGVoiceInterface_SetCurrentDownloadFieldID_Params params;
	params.filedId = filedId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.SetAllVoiceStatus
// ()
// Parameters:
// bool                           Flag                           (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::SetAllVoiceStatus(bool Flag)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.SetAllVoiceStatus");

	UGVoiceInterface_SetAllVoiceStatus_Params params;
	params.Flag = Flag;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ResetWhenLogOut
// ()

void UGVoiceInterface::ResetWhenLogOut()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ResetWhenLogOut");

	UGVoiceInterface_ResetWhenLogOut_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ReportPlayers
// ()
// Parameters:
// struct FString                 InExtraInfo                    (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::ReportPlayers(const struct FString& InExtraInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ReportPlayers");

	UGVoiceInterface_ReportPlayers_Params params;
	params.InExtraInfo = InExtraInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.ReactiveLbsStatus
// ()

void UGVoiceInterface::ReactiveLbsStatus()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ReactiveLbsStatus");

	UGVoiceInterface_ReactiveLbsStatus_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.QuitTempLbsRoom
// ()
// Parameters:
// struct FString                 roomStr                        (Parm, ZeroConstructor)

void UGVoiceInterface::QuitTempLbsRoom(const struct FString& roomStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.QuitTempLbsRoom");

	UGVoiceInterface_QuitTempLbsRoom_Params params;
	params.roomStr = roomStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.QuitRoom
// ()

void UGVoiceInterface::QuitRoom()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.QuitRoom");

	UGVoiceInterface_QuitRoom_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.PlayRecordFile
// ()

void UGVoiceInterface::PlayRecordFile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.PlayRecordFile");

	UGVoiceInterface_PlayRecordFile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OpenTeamSpeakerOnly
// ()
// Parameters:
// bool                           ShowTips                       (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::OpenTeamSpeakerOnly(bool ShowTips)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenTeamSpeakerOnly");

	UGVoiceInterface_OpenTeamSpeakerOnly_Params params;
	params.ShowTips = ShowTips;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OpenTeamMicphoneOnly
// ()
// Parameters:
// bool                           ShowTips                       (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::OpenTeamMicphoneOnly(bool ShowTips)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenTeamMicphoneOnly");

	UGVoiceInterface_OpenTeamMicphoneOnly_Params params;
	params.ShowTips = ShowTips;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.OpenTeamInterphone
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::OpenTeamInterphone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenTeamInterphone");

	UGVoiceInterface_OpenTeamInterphone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.OpenSpeakerByTempLbs
// ()
// Parameters:
// bool                           Open                           (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::OpenSpeakerByTempLbs(bool Open)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenSpeakerByTempLbs");

	UGVoiceInterface_OpenSpeakerByTempLbs_Params params;
	params.Open = Open;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OpenSpeaker
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::OpenSpeaker()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenSpeaker");

	UGVoiceInterface_OpenSpeaker_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.OpenMicByTempLbs
// ()
// Parameters:
// bool                           Open                           (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::OpenMicByTempLbs(bool Open)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenMicByTempLbs");

	UGVoiceInterface_OpenMicByTempLbs_Params params;
	params.Open = Open;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OpenMicAndSpeakerAfterJoinLbsRoom
// ()

void UGVoiceInterface::OpenMicAndSpeakerAfterJoinLbsRoom()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenMicAndSpeakerAfterJoinLbsRoom");

	UGVoiceInterface_OpenMicAndSpeakerAfterJoinLbsRoom_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OpenMic
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::OpenMic()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenMic");

	UGVoiceInterface_OpenMic_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.OpenIngameSpeaker
// ()

void UGVoiceInterface::OpenIngameSpeaker()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenIngameSpeaker");

	UGVoiceInterface_OpenIngameSpeaker_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OpenIngameMicphone
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::OpenIngameMicphone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenIngameMicphone");

	UGVoiceInterface_OpenIngameMicphone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.OpenAllSpeaker
// ()
// Parameters:
// bool                           ShowTips                       (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::OpenAllSpeaker(bool ShowTips)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenAllSpeaker");

	UGVoiceInterface_OpenAllSpeaker_Params params;
	params.ShowTips = ShowTips;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OpenAllMicphone
// ()
// Parameters:
// bool                           ShowTips                       (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::OpenAllMicphone(bool ShowTips)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenAllMicphone");

	UGVoiceInterface_OpenAllMicphone_Params params;
	params.ShowTips = ShowTips;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.OpenAllInterphone
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::OpenAllInterphone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OpenAllInterphone");

	UGVoiceInterface_OpenAllInterphone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.OnRoomTypeChanged
// ()
// Parameters:
// struct FString                 itemtext                       (Parm, ZeroConstructor)

void UGVoiceInterface::OnRoomTypeChanged(const struct FString& itemtext)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OnRoomTypeChanged");

	UGVoiceInterface_OnRoomTypeChanged_Params params;
	params.itemtext = itemtext;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OnResume
// ()

void UGVoiceInterface::OnResume()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OnResume");

	UGVoiceInterface_OnResume_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.OnPause
// ()

void UGVoiceInterface::OnPause()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.OnPause");

	UGVoiceInterface_OnPause_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.LbsSpeakerEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::LbsSpeakerEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.LbsSpeakerEnable");

	UGVoiceInterface_LbsSpeakerEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.LbsMicphoneEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::LbsMicphoneEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.LbsMicphoneEnable");

	UGVoiceInterface_LbsMicphoneEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.JoinTempLbsRoom
// ()
// Parameters:
// struct FString                 room                           (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)

void UGVoiceInterface::JoinTempLbsRoom(const struct FString& room, const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.JoinTempLbsRoom");

	UGVoiceInterface_JoinTempLbsRoom_Params params;
	params.room = room;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.JoinRoom
// ()
// Parameters:
// struct FString                 room                           (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)

void UGVoiceInterface::JoinRoom(const struct FString& room, const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.JoinRoom");

	UGVoiceInterface_JoinRoom_Params params;
	params.room = room;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.JoinLbsRoom
// ()
// Parameters:
// struct FString                 lbsRoom                        (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)

void UGVoiceInterface::JoinLbsRoom(const struct FString& lbsRoom, const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.JoinLbsRoom");

	UGVoiceInterface_JoinLbsRoom_Params params;
	params.lbsRoom = lbsRoom;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.IsTeamInterphoneOpenned
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::IsTeamInterphoneOpenned()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.IsTeamInterphoneOpenned");

	UGVoiceInterface_IsTeamInterphoneOpenned_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.IsLbsInterphoneOpenned
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::IsLbsInterphoneOpenned()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.IsLbsInterphoneOpenned");

	UGVoiceInterface_IsLbsInterphoneOpenned_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.IsInterphoneMode
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::IsInterphoneMode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.IsInterphoneMode");

	UGVoiceInterface_IsInterphoneMode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.InitGVoiceComponent
// ()
// Parameters:
// struct FString                 userId                         (Parm, ZeroConstructor)

void UGVoiceInterface::InitGVoiceComponent(const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.InitGVoiceComponent");

	UGVoiceInterface_InitGVoiceComponent_Params params;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.HaveTeamRoom
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::HaveTeamRoom()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.HaveTeamRoom");

	UGVoiceInterface_HaveTeamRoom_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.HaveLbsRoom
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::HaveLbsRoom()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.HaveLbsRoom");

	UGVoiceInterface_HaveLbsRoom_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.GetVoiceLength
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UGVoiceInterface::GetVoiceLength()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.GetVoiceLength");

	UGVoiceInterface_GetVoiceLength_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.GetPlayerVolume
// ()
// Parameters:
// struct FString                 InPlayerid                     (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UGVoiceInterface::GetPlayerVolume(const struct FString& InPlayerid)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.GetPlayerVolume");

	UGVoiceInterface_GetPlayerVolume_Params params;
	params.InPlayerid = InPlayerid;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.GetAuthKey
// ()

void UGVoiceInterface::GetAuthKey()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.GetAuthKey");

	UGVoiceInterface_GetAuthKey_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ForbidTeammateVoiceById
// ()
// Parameters:
// int                            memberID                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           IsEnable                       (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::ForbidTeammateVoiceById(int memberID, bool IsEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ForbidTeammateVoiceById");

	UGVoiceInterface_ForbidTeammateVoiceById_Params params;
	params.memberID = memberID;
	params.IsEnable = IsEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.EnbleMicAndSpeakerByRoomName
// ()
// Parameters:
// struct FString                 roomName                       (Parm, ZeroConstructor)
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::EnbleMicAndSpeakerByRoomName(const struct FString& roomName, bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.EnbleMicAndSpeakerByRoomName");

	UGVoiceInterface_EnbleMicAndSpeakerByRoomName_Params params;
	params.roomName = roomName;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.EnableReportALLAbroad
// ()
// Parameters:
// bool                           InEnable                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InWithEncryption               (Parm, ZeroConstructor, IsPlainOldData)
// int                            InTimeout                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UGVoiceInterface::EnableReportALLAbroad(bool InEnable, bool InWithEncryption, int InTimeout)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.EnableReportALLAbroad");

	UGVoiceInterface_EnableReportALLAbroad_Params params;
	params.InEnable = InEnable;
	params.InWithEncryption = InWithEncryption;
	params.InTimeout = InTimeout;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.GVoiceInterface.DownloadRecordFile
// ()

void UGVoiceInterface::DownloadRecordFile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.DownloadRecordFile");

	UGVoiceInterface_DownloadRecordFile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CommonTestMic
// ()

void UGVoiceInterface::CommonTestMic()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CommonTestMic");

	UGVoiceInterface_CommonTestMic_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CloseSpeaker
// ()

void UGVoiceInterface::CloseSpeaker()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CloseSpeaker");

	UGVoiceInterface_CloseSpeaker_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CloseMic
// ()

void UGVoiceInterface::CloseMic()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CloseMic");

	UGVoiceInterface_CloseMic_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CloseIngameSpeaker
// ()

void UGVoiceInterface::CloseIngameSpeaker()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CloseIngameSpeaker");

	UGVoiceInterface_CloseIngameSpeaker_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CloseIngameMicphone
// ()

void UGVoiceInterface::CloseIngameMicphone()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CloseIngameMicphone");

	UGVoiceInterface_CloseIngameMicphone_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CloseAllSpeaker
// ()
// Parameters:
// bool                           ShowTips                       (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::CloseAllSpeaker(bool ShowTips)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CloseAllSpeaker");

	UGVoiceInterface_CloseAllSpeaker_Params params;
	params.ShowTips = ShowTips;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CloseAllMicphone
// ()
// Parameters:
// bool                           ShowTips                       (Parm, ZeroConstructor, IsPlainOldData)

void UGVoiceInterface::CloseAllMicphone(bool ShowTips)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CloseAllMicphone");

	UGVoiceInterface_CloseAllMicphone_Params params;
	params.ShowTips = ShowTips;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.CheckAndEnableRoomSpeaker
// ()

void UGVoiceInterface::CheckAndEnableRoomSpeaker()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.CheckAndEnableRoomSpeaker");

	UGVoiceInterface_CheckAndEnableRoomSpeaker_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInLobby
// ()

void UGVoiceInterface::ChatShowAgeRestrictionMsgInLobby()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInLobby");

	UGVoiceInterface_ChatShowAgeRestrictionMsgInLobby_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInFighting
// ()

void UGVoiceInterface::ChatShowAgeRestrictionMsgInFighting()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInFighting");

	UGVoiceInterface_ChatShowAgeRestrictionMsgInFighting_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInChat
// ()

void UGVoiceInterface::ChatShowAgeRestrictionMsgInChat()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInChat");

	UGVoiceInterface_ChatShowAgeRestrictionMsgInChat_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ChatRequestPrivacyInSetting
// ()

void UGVoiceInterface::ChatRequestPrivacyInSetting()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ChatRequestPrivacyInSetting");

	UGVoiceInterface_ChatRequestPrivacyInSetting_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.GVoiceInterface.ChatRequestPrivacyInGame
// ()

void UGVoiceInterface::ChatRequestPrivacyInGame()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.GVoiceInterface.ChatRequestPrivacyInGame");

	UGVoiceInterface_ChatRequestPrivacyInGame_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.HttpWrapper.SimplePostForLua
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)
// int                            Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// int                            QueueType                      (Parm, ZeroConstructor, IsPlainOldData)

void UHttpWrapper::SimplePostForLua(const struct FString& URL, const struct FString& Content, int Priority, int QueueType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.SimplePostForLua");

	UHttpWrapper_SimplePostForLua_Params params;
	params.URL = URL;
	params.Content = Content;
	params.Priority = Priority;
	params.QueueType = QueueType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.HttpWrapper.SetQueueSize
// ()
// Parameters:
// int                            QueueType                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            InSize                         (Parm, ZeroConstructor, IsPlainOldData)

void UHttpWrapper::SetQueueSize(int QueueType, int InSize)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.SetQueueSize");

	UHttpWrapper_SetQueueSize_Params params;
	params.QueueType = QueueType;
	params.InSize = InSize;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.HttpWrapper.SetQueueEnable
// ()
// Parameters:
// bool                           InEnableQueue                  (Parm, ZeroConstructor, IsPlainOldData)

void UHttpWrapper::SetQueueEnable(bool InEnableQueue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.SetQueueEnable");

	UHttpWrapper_SetQueueEnable_Params params;
	params.InEnableQueue = InEnableQueue;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.HttpWrapper.SetPoolEnable
// ()
// Parameters:
// bool                           InEnablePool                   (Parm, ZeroConstructor, IsPlainOldData)

void UHttpWrapper::SetPoolEnable(bool InEnablePool)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.SetPoolEnable");

	UHttpWrapper_SetPoolEnable_Params params;
	params.InEnablePool = InEnablePool;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.HttpWrapper.RequestForLua
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// struct FString                 Verb                           (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> Headers                        (Parm, OutParm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)
// int                            Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// int                            QueueType                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UHttpWrapper::RequestForLua(const struct FString& URL, const struct FString& Verb, const struct FString& Content, int Priority, int QueueType, TMap<struct FString, struct FString>* Headers)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.RequestForLua");

	UHttpWrapper_RequestForLua_Params params;
	params.URL = URL;
	params.Verb = Verb;
	params.Content = Content;
	params.Priority = Priority;
	params.QueueType = QueueType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Headers != nullptr)
		*Headers = params.Headers;

	return params.ReturnValue;
}


// Function Client.HttpWrapper.GetQueueEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UHttpWrapper::GetQueueEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.GetQueueEnable");

	UHttpWrapper_GetQueueEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.HttpWrapper.GetPoolEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UHttpWrapper::GetPoolEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.GetPoolEnable");

	UHttpWrapper_GetPoolEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.HttpWrapper.GetInternalIndex
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UHttpWrapper::GetInternalIndex()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.GetInternalIndex");

	UHttpWrapper_GetInternalIndex_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.HttpWrapper.CancelRequestAll
// ()
// Parameters:
// int                            QueueType                      (Parm, ZeroConstructor, IsPlainOldData)

void UHttpWrapper::CancelRequestAll(int QueueType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.CancelRequestAll");

	UHttpWrapper_CancelRequestAll_Params params;
	params.QueueType = QueueType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.HttpWrapper.CancelRequest
// ()
// Parameters:
// int                            QueueType                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReqIndex                       (Parm, ZeroConstructor, IsPlainOldData)

void UHttpWrapper::CancelRequest(int QueueType, int ReqIndex)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.HttpWrapper.CancelRequest");

	UHttpWrapper_CancelRequest_Params params;
	params.QueueType = QueueType;
	params.ReqIndex = ReqIndex;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ImageDownloader.Start
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)

void UImageDownloader::Start(const struct FString& URL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ImageDownloader.Start");

	UImageDownloader_Start_Params params;
	params.URL = URL;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ImageDownloader.MakeDownloaderInGame
// ()
// Parameters:
// class UImageDownloader*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UImageDownloader* UImageDownloader::MakeDownloaderInGame()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ImageDownloader.MakeDownloaderInGame");

	UImageDownloader_MakeDownloaderInGame_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ImageDownloader.MakeDownloader
// ()
// Parameters:
// class UImageDownloader*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UImageDownloader* UImageDownloader::MakeDownloader()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ImageDownloader.MakeDownloader");

	UImageDownloader_MakeDownloader_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ImageDownloader.GetTextureFromUrlWithoutDownload
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// class UTexture2D*              ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UTexture2D* UImageDownloader::GetTextureFromUrlWithoutDownload(const struct FString& URL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ImageDownloader.GetTextureFromUrlWithoutDownload");

	UImageDownloader_GetTextureFromUrlWithoutDownload_Params params;
	params.URL = URL;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.InGameUIManager.SubUIWidgetListWithMountData
// ()
// Parameters:
// TArray<struct FInGameWidgetData> InGameWidgetDataList           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FString>         GameStatusStrList              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           InPersistentUI                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InUsedByControler              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InOberverOnly                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            inUIControlState               (Parm, ZeroConstructor, IsPlainOldData)

void UInGameUIManager::SubUIWidgetListWithMountData(TArray<struct FInGameWidgetData> InGameWidgetDataList, TArray<struct FString> GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly, int inUIControlState)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.SubUIWidgetListWithMountData");

	UInGameUIManager_SubUIWidgetListWithMountData_Params params;
	params.InGameWidgetDataList = InGameWidgetDataList;
	params.GameStatusStrList = GameStatusStrList;
	params.InPersistentUI = InPersistentUI;
	params.InUsedByControler = InUsedByControler;
	params.InOberverOnly = InOberverOnly;
	params.inUIControlState = inUIControlState;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.SubUIWidgetList
// ()
// Parameters:
// TArray<struct FGameWidgetConfig> InWidgetConfigList             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FString>         GameStatusStrList              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           InPersistentUI                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InUsedByControler              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InOberverOnly                  (Parm, ZeroConstructor, IsPlainOldData)

void UInGameUIManager::SubUIWidgetList(TArray<struct FGameWidgetConfig> InWidgetConfigList, TArray<struct FString> GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.SubUIWidgetList");

	UInGameUIManager_SubUIWidgetList_Params params;
	params.InWidgetConfigList = InWidgetConfigList;
	params.GameStatusStrList = GameStatusStrList;
	params.InPersistentUI = InPersistentUI;
	params.InUsedByControler = InUsedByControler;
	params.InOberverOnly = InOberverOnly;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.SubDynamicUIWidgetList
// ()
// Parameters:
// TArray<struct FDynamicWidgetData> DynamicWidgetMap               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UInGameUIManager::SubDynamicUIWidgetList(TArray<struct FDynamicWidgetData> DynamicWidgetMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.SubDynamicUIWidgetList");

	UInGameUIManager_SubDynamicUIWidgetList_Params params;
	params.DynamicWidgetMap = DynamicWidgetMap;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.OnAsyncLoadWidgetClassObj
// ()
// Parameters:
// class UObject*                 InClassObj                     (Parm, ZeroConstructor, IsPlainOldData)
// int                            RequestID                      (Parm, ZeroConstructor, IsPlainOldData)

void UInGameUIManager::OnAsyncLoadWidgetClassObj(class UObject* InClassObj, int RequestID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.OnAsyncLoadWidgetClassObj");

	UInGameUIManager_OnAsyncLoadWidgetClassObj_Params params;
	params.InClassObj = InClassObj;
	params.RequestID = RequestID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.HandleUIMessage
// ()
// Parameters:
// struct FString                 UIMessage                      (Parm, ZeroConstructor)

void UInGameUIManager::HandleUIMessage(const struct FString& UIMessage)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.HandleUIMessage");

	UInGameUIManager_HandleUIMessage_Params params;
	params.UIMessage = UIMessage;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.HandleMountWidget
// ()
// Parameters:
// class UInGameUIManager*        IngameManager                  (Parm, ZeroConstructor, IsPlainOldData)

void UInGameUIManager::HandleMountWidget(class UInGameUIManager* IngameManager)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.HandleMountWidget");

	UInGameUIManager_HandleMountWidget_Params params;
	params.IngameManager = IngameManager;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.HandleDynamicDestroy
// ()

void UInGameUIManager::HandleDynamicDestroy()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.HandleDynamicDestroy");

	UInGameUIManager_HandleDynamicDestroy_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.HandleDynamicCreation
// ()
// Parameters:
// bool                           isAsyncLoad                    (Parm, ZeroConstructor, IsPlainOldData)

void UInGameUIManager::HandleDynamicCreation(bool isAsyncLoad)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.HandleDynamicCreation");

	UInGameUIManager_HandleDynamicCreation_Params params;
	params.isAsyncLoad = isAsyncLoad;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.GetWidgetHandleAsyncWithCallBack
// ()
// Parameters:
// struct FString                 WidgetKey                      (Parm, ZeroConstructor)
// struct FScriptDelegate         InCallback                     (Parm, ZeroConstructor)

void UInGameUIManager::GetWidgetHandleAsyncWithCallBack(const struct FString& WidgetKey, const struct FScriptDelegate& InCallback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.GetWidgetHandleAsyncWithCallBack");

	UInGameUIManager_GetWidgetHandleAsyncWithCallBack_Params params;
	params.WidgetKey = WidgetKey;
	params.InCallback = InCallback;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.InGameUIManager.GetWidgetHandle
// ()
// Parameters:
// struct FString                 WidgetKey                      (Parm, ZeroConstructor)
// class UUAEUserWidget*          ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UUAEUserWidget* UInGameUIManager::GetWidgetHandle(const struct FString& WidgetKey)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.GetWidgetHandle");

	UInGameUIManager_GetWidgetHandle_Params params;
	params.WidgetKey = WidgetKey;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.InGameUIManager.ChangeSubUIWidgetList
// ()
// Parameters:
// TArray<struct FGameWidgetConfig> InWidgetConfigList             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UInGameUIManager::ChangeSubUIWidgetList(TArray<struct FGameWidgetConfig> InWidgetConfigList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.InGameUIManager.ChangeSubUIWidgetList");

	UInGameUIManager_ChangeSubUIWidgetList_Params params;
	params.InWidgetConfigList = InWidgetConfigList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LiveBroadcast.SetFullScreen
// ()
// Parameters:
// bool                           FullScreen                     (Parm, ZeroConstructor, IsPlainOldData)

void ULiveBroadcast::SetFullScreen(bool FullScreen)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LiveBroadcast.SetFullScreen");

	ULiveBroadcast_SetFullScreen_Params params;
	params.FullScreen = FullScreen;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LiveBroadcast.OpenLiveBroadcast
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// float                          Margin                         (Parm, ZeroConstructor, IsPlainOldData)

void ULiveBroadcast::OpenLiveBroadcast(const struct FString& URL, float Margin)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LiveBroadcast.OpenLiveBroadcast");

	ULiveBroadcast_OpenLiveBroadcast_Params params;
	params.URL = URL;
	params.Margin = Margin;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LiveBroadcast.GetInstance
// ()
// Parameters:
// class ULiveBroadcast*          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ULiveBroadcast* ULiveBroadcast::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LiveBroadcast.GetInstance");

	ULiveBroadcast_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LiveBroadcast.CloseWebView
// ()

void ULiveBroadcast::CloseWebView()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LiveBroadcast.CloseWebView");

	ULiveBroadcast_CloseWebView_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LiveBroadcast.C2JSetString
// ()
// Parameters:
// struct FString                 str                            (Parm, ZeroConstructor)

void ULiveBroadcast::C2JSetString(const struct FString& str)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LiveBroadcast.C2JSetString");

	ULiveBroadcast_C2JSetString_Params params;
	params.str = str;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LiveBroadcast.C2JSetIndex
// ()
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)

void ULiveBroadcast::C2JSetIndex(int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LiveBroadcast.C2JSetIndex");

	ULiveBroadcast_C2JSetIndex_Params params;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LoadTexture.LoadTexture2D
// ()
// Parameters:
// struct FString                 ImagePath                      (Parm, ZeroConstructor)
// bool                           IsValid                        (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            OutWidth                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            OutHeight                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// class UTexture2D*              ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UTexture2D* ULoadTexture::LoadTexture2D(const struct FString& ImagePath, bool* IsValid, int* OutWidth, int* OutHeight)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LoadTexture.LoadTexture2D");

	ULoadTexture_LoadTexture2D_Params params;
	params.ImagePath = ImagePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (IsValid != nullptr)
		*IsValid = params.IsValid;
	if (OutWidth != nullptr)
		*OutWidth = params.OutWidth;
	if (OutHeight != nullptr)
		*OutHeight = params.OutHeight;

	return params.ReturnValue;
}


// Function Client.LoadTexture.GetTexture2DFromDiskFile
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// class UTexture2D*              ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UTexture2D* ULoadTexture::GetTexture2DFromDiskFile(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LoadTexture.GetTexture2DFromDiskFile");

	ULoadTexture_GetTexture2DFromDiskFile_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.StringToLVar
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Value                          (Parm, ZeroConstructor)
// struct FLuaBPVar               ReturnValue                    (Parm, OutParm, ReturnParm)

struct FLuaBPVar ULuaBlueprintLibrary::StringToLVar(class UObject* WorldContextObject, const struct FString& Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.StringToLVar");

	ULuaBlueprintLibrary_StringToLVar_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.ObjectToLVar
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class UObject*                 O                              (Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               ReturnValue                    (Parm, OutParm, ReturnParm)

struct FLuaBPVar ULuaBlueprintLibrary::ObjectToLVar(class UObject* WorldContextObject, class UObject* O)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.ObjectToLVar");

	ULuaBlueprintLibrary_ObjectToLVar_Params params;
	params.WorldContextObject = WorldContextObject;
	params.O = O;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.LVarToString
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               Value                          (ConstParm, Parm, OutParm, ReferenceParm)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ULuaBlueprintLibrary::LVarToString(class UObject* WorldContextObject, const struct FLuaBPVar& Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.LVarToString");

	ULuaBlueprintLibrary_LVarToString_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.LVarToObject
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               Value                          (ConstParm, Parm, OutParm, ReferenceParm)
// class UObject*                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UObject* ULuaBlueprintLibrary::LVarToObject(class UObject* WorldContextObject, const struct FLuaBPVar& Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.LVarToObject");

	ULuaBlueprintLibrary_LVarToObject_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.LVarToInt
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               Value                          (ConstParm, Parm, OutParm, ReferenceParm)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int ULuaBlueprintLibrary::LVarToInt(class UObject* WorldContextObject, const struct FLuaBPVar& Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.LVarToInt");

	ULuaBlueprintLibrary_LVarToInt_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.LVarToFloat
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               Value                          (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ULuaBlueprintLibrary::LVarToFloat(class UObject* WorldContextObject, const struct FLuaBPVar& Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.LVarToFloat");

	ULuaBlueprintLibrary_LVarToFloat_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.LVarToBool
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               Value                          (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ULuaBlueprintLibrary::LVarToBool(class UObject* WorldContextObject, const struct FLuaBPVar& Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.LVarToBool");

	ULuaBlueprintLibrary_LVarToBool_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.IntToLVar
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            Value                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               ReturnValue                    (Parm, OutParm, ReturnParm)

struct FLuaBPVar ULuaBlueprintLibrary::IntToLVar(class UObject* WorldContextObject, int Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.IntToLVar");

	ULuaBlueprintLibrary_IntToLVar_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.FloatToLVar
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Value                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               ReturnValue                    (Parm, OutParm, ReturnParm)

struct FLuaBPVar ULuaBlueprintLibrary::FloatToLVar(class UObject* WorldContextObject, float Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.FloatToLVar");

	ULuaBlueprintLibrary_FloatToLVar_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintLibrary.CallLuaWithMultiArgs
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Function                       (Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FLuaBPVar               InA                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InB                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InC                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InD                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InE                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InF                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               OutA                           (Parm, OutParm)
// struct FLuaBPVar               OutB                           (Parm, OutParm)
// struct FLuaBPVar               OutC                           (Parm, OutParm)
// struct FLuaBPVar               OutD                           (Parm, OutParm)

void ULuaBlueprintLibrary::CallLuaWithMultiArgs(class UObject* WorldContextObject, const struct FLuaBPVar& InF, const struct FLuaBPVar& InA, const struct FLuaBPVar& InB, const struct FLuaBPVar& InC, const struct FLuaBPVar& InD, const struct FLuaBPVar& InE, struct FString* Function, struct FLuaBPVar* OutA, struct FLuaBPVar* OutB, struct FLuaBPVar* OutC, struct FLuaBPVar* OutD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.CallLuaWithMultiArgs");

	ULuaBlueprintLibrary_CallLuaWithMultiArgs_Params params;
	params.WorldContextObject = WorldContextObject;
	params.InA = InA;
	params.InB = InB;
	params.InC = InC;
	params.InD = InD;
	params.InE = InE;
	params.InF = InF;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Function != nullptr)
		*Function = params.Function;
	if (OutA != nullptr)
		*OutA = params.OutA;
	if (OutB != nullptr)
		*OutB = params.OutB;
	if (OutC != nullptr)
		*OutC = params.OutC;
	if (OutD != nullptr)
		*OutD = params.OutD;
}


// Function Client.LuaBlueprintLibrary.CallLuaWithHUD
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Function                       (Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FLuaBPVar               InA                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InB                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InC                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InD                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               OutA                           (Parm, OutParm)
// struct FLuaBPVar               OutB                           (Parm, OutParm)
// struct FLuaBPVar               OutC                           (Parm, OutParm)
// struct FLuaBPVar               OutD                           (Parm, OutParm)

void ULuaBlueprintLibrary::CallLuaWithHUD(class UObject* WorldContextObject, class UGameFrontendHUD* GameFrontendHUD, const struct FLuaBPVar& InD, const struct FLuaBPVar& InA, const struct FLuaBPVar& InB, const struct FLuaBPVar& InC, struct FString* Function, struct FLuaBPVar* OutA, struct FLuaBPVar* OutB, struct FLuaBPVar* OutC, struct FLuaBPVar* OutD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.CallLuaWithHUD");

	ULuaBlueprintLibrary_CallLuaWithHUD_Params params;
	params.WorldContextObject = WorldContextObject;
	params.GameFrontendHUD = GameFrontendHUD;
	params.InA = InA;
	params.InB = InB;
	params.InC = InC;
	params.InD = InD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Function != nullptr)
		*Function = params.Function;
	if (OutA != nullptr)
		*OutA = params.OutA;
	if (OutB != nullptr)
		*OutB = params.OutB;
	if (OutC != nullptr)
		*OutC = params.OutC;
	if (OutD != nullptr)
		*OutD = params.OutD;
}


// Function Client.LuaBlueprintLibrary.CallLuaWithArgs
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Function                       (Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FLuaBPVar               InA                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InB                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InC                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               InD                            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLuaBPVar               OutA                           (Parm, OutParm)
// struct FLuaBPVar               OutB                           (Parm, OutParm)
// struct FLuaBPVar               OutC                           (Parm, OutParm)
// struct FLuaBPVar               OutD                           (Parm, OutParm)

void ULuaBlueprintLibrary::CallLuaWithArgs(class UObject* WorldContextObject, const struct FLuaBPVar& InD, const struct FLuaBPVar& InA, const struct FLuaBPVar& InB, const struct FLuaBPVar& InC, struct FString* Function, struct FLuaBPVar* OutA, struct FLuaBPVar* OutB, struct FLuaBPVar* OutC, struct FLuaBPVar* OutD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.CallLuaWithArgs");

	ULuaBlueprintLibrary_CallLuaWithArgs_Params params;
	params.WorldContextObject = WorldContextObject;
	params.InA = InA;
	params.InB = InB;
	params.InC = InC;
	params.InD = InD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Function != nullptr)
		*Function = params.Function;
	if (OutA != nullptr)
		*OutA = params.OutA;
	if (OutB != nullptr)
		*OutB = params.OutB;
	if (OutC != nullptr)
		*OutC = params.OutC;
	if (OutD != nullptr)
		*OutD = params.OutD;
}


// Function Client.LuaBlueprintLibrary.CallLua
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Function                       (Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FLuaBPVar               OutA                           (Parm, OutParm)
// struct FLuaBPVar               OutB                           (Parm, OutParm)
// struct FLuaBPVar               OutC                           (Parm, OutParm)
// struct FLuaBPVar               OutD                           (Parm, OutParm)

void ULuaBlueprintLibrary::CallLua(class UObject* WorldContextObject, struct FString* Function, struct FLuaBPVar* OutA, struct FLuaBPVar* OutB, struct FLuaBPVar* OutC, struct FLuaBPVar* OutD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.CallLua");

	ULuaBlueprintLibrary_CallLua_Params params;
	params.WorldContextObject = WorldContextObject;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Function != nullptr)
		*Function = params.Function;
	if (OutA != nullptr)
		*OutA = params.OutA;
	if (OutB != nullptr)
		*OutB = params.OutB;
	if (OutC != nullptr)
		*OutC = params.OutC;
	if (OutD != nullptr)
		*OutD = params.OutD;
}


// Function Client.LuaBlueprintLibrary.BoolToLVar
// ()
// Parameters:
// class UObject*                 WorldContextObject             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           Value                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FLuaBPVar               ReturnValue                    (Parm, OutParm, ReturnParm)

struct FLuaBPVar ULuaBlueprintLibrary::BoolToLVar(class UObject* WorldContextObject, bool Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintLibrary.BoolToLVar");

	ULuaBlueprintLibrary_BoolToLVar_Params params;
	params.WorldContextObject = WorldContextObject;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintMgr.GetSystemByName
// ()
// Parameters:
// struct FString                 SystemName                     (ConstParm, Parm, ZeroConstructor)
// class ULuaBluepirntSys*        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ULuaBluepirntSys* ULuaBlueprintMgr::GetSystemByName(const struct FString& SystemName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintMgr.GetSystemByName");

	ULuaBlueprintMgr_GetSystemByName_Params params;
	params.SystemName = SystemName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaBlueprintMgr.AddSystem
// ()
// Parameters:
// struct FString                 SystemName                     (ConstParm, Parm, ZeroConstructor)
// struct FString                 BPPath                         (ConstParm, Parm, ZeroConstructor)

void ULuaBlueprintMgr::AddSystem(const struct FString& SystemName, const struct FString& BPPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBlueprintMgr.AddSystem");

	ULuaBlueprintMgr_AddSystem_Params params;
	params.SystemName = SystemName;
	params.BPPath = BPPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaBluepirntSys.Init
// ()

void ULuaBluepirntSys::Init()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaBluepirntSys.Init");

	ULuaBluepirntSys_Init_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.SubUIWidgetList
// ()
// Parameters:
// TArray<struct FGameWidgetConfig> InWidgetConfigList             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FString>         GameStatusStrList              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           bPersistentUI                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InStatusConcern                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bDynamicWidget                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bKeepDynamicWidget             (Parm, ZeroConstructor, IsPlainOldData)

void ALuaClassObj::SubUIWidgetList(TArray<struct FGameWidgetConfig> InWidgetConfigList, TArray<struct FString> GameStatusStrList, bool bPersistentUI, bool InStatusConcern, bool bDynamicWidget, bool bKeepDynamicWidget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.SubUIWidgetList");

	ALuaClassObj_SubUIWidgetList_Params params;
	params.InWidgetConfigList = InWidgetConfigList;
	params.GameStatusStrList = GameStatusStrList;
	params.bPersistentUI = bPersistentUI;
	params.InStatusConcern = InStatusConcern;
	params.bDynamicWidget = bDynamicWidget;
	params.bKeepDynamicWidget = bKeepDynamicWidget;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.SubShowHideEvent
// ()
// Parameters:
// TArray<struct FString>         WidgetPathList                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void ALuaClassObj::SubShowHideEvent(TArray<struct FString> WidgetPathList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.SubShowHideEvent");

	ALuaClassObj_SubShowHideEvent_Params params;
	params.WidgetPathList = WidgetPathList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.SubDefaultSceneCamera
// ()
// Parameters:
// int                            sceneCameraIndex               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void ALuaClassObj::SubDefaultSceneCamera(int sceneCameraIndex)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.SubDefaultSceneCamera");

	ALuaClassObj_SubDefaultSceneCamera_Params params;
	params.sceneCameraIndex = sceneCameraIndex;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.SubDefaultChildUI
// ()
// Parameters:
// TArray<struct FString>         childList                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void ALuaClassObj::SubDefaultChildUI(TArray<struct FString> childList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.SubDefaultChildUI");

	ALuaClassObj_SubDefaultChildUI_Params params;
	params.childList = childList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.SubDefaultBaseUI
// ()
// Parameters:
// struct FString                 baseUI                         (Parm, ZeroConstructor)

void ALuaClassObj::SubDefaultBaseUI(const struct FString& baseUI)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.SubDefaultBaseUI");

	ALuaClassObj_SubDefaultBaseUI_Params params;
	params.baseUI = baseUI;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.SubCollapseWidgetList
// ()
// Parameters:
// struct FString                 RootWidgetName                 (Parm, ZeroConstructor)
// TArray<struct FString>         ChildWidgetNames               (Parm, OutParm, ZeroConstructor)

void ALuaClassObj::SubCollapseWidgetList(const struct FString& RootWidgetName, TArray<struct FString>* ChildWidgetNames)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.SubCollapseWidgetList");

	ALuaClassObj_SubCollapseWidgetList_Params params;
	params.RootWidgetName = RootWidgetName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ChildWidgetNames != nullptr)
		*ChildWidgetNames = params.ChildWidgetNames;
}


// Function Client.LuaClassObj.SetWidgetZorder
// ()
// Parameters:
// int                            Index                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            ZOrder                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void ALuaClassObj::SetWidgetZorder(int Index, int ZOrder)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.SetWidgetZorder");

	ALuaClassObj_SetWidgetZorder_Params params;
	params.Index = Index;
	params.ZOrder = ZOrder;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.RestoreWidgetZorder
// ()
// Parameters:
// int                            Index                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void ALuaClassObj::RestoreWidgetZorder(int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.RestoreWidgetZorder");

	ALuaClassObj_RestoreWidgetZorder_Params params;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.RestoreAllWidgetZorder
// ()

void ALuaClassObj::RestoreAllWidgetZorder()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.RestoreAllWidgetZorder");

	ALuaClassObj_RestoreAllWidgetZorder_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.IsTopStackPanel
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ALuaClassObj::IsTopStackPanel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.IsTopStackPanel");

	ALuaClassObj_IsTopStackPanel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaClassObj.IsPushedPanel
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ALuaClassObj::IsPushedPanel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.IsPushedPanel");

	ALuaClassObj_IsPushedPanel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaClassObj.InCombatState
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ALuaClassObj::InCombatState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.InCombatState");

	ALuaClassObj_InCombatState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaClassObj.HandleUIMessageNoFetch
// ()
// Parameters:
// struct FString                 UIMessage                      (Parm, ZeroConstructor)

void ALuaClassObj::HandleUIMessageNoFetch(const struct FString& UIMessage)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.HandleUIMessageNoFetch");

	ALuaClassObj_HandleUIMessageNoFetch_Params params;
	params.UIMessage = UIMessage;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.HandleUIMessage
// ()
// Parameters:
// struct FString                 UIMessage                      (Parm, ZeroConstructor)

void ALuaClassObj::HandleUIMessage(const struct FString& UIMessage)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.HandleUIMessage");

	ALuaClassObj_HandleUIMessage_Params params;
	params.UIMessage = UIMessage;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.HandleStopAsyncLoad
// ()

void ALuaClassObj::HandleStopAsyncLoad()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.HandleStopAsyncLoad");

	ALuaClassObj_HandleStopAsyncLoad_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.HandleDynamicDestroy
// ()

void ALuaClassObj::HandleDynamicDestroy()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.HandleDynamicDestroy");

	ALuaClassObj_HandleDynamicDestroy_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.HandleDynamicCreationInternal
// ()
// Parameters:
// bool                           isAsyncLoad                    (Parm, ZeroConstructor, IsPlainOldData)

void ALuaClassObj::HandleDynamicCreationInternal(bool isAsyncLoad)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.HandleDynamicCreationInternal");

	ALuaClassObj_HandleDynamicCreationInternal_Params params;
	params.isAsyncLoad = isAsyncLoad;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.HandleDynamicCreation
// ()
// Parameters:
// bool                           isAsyncLoad                    (Parm, ZeroConstructor, IsPlainOldData)

void ALuaClassObj::HandleDynamicCreation(bool isAsyncLoad)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.HandleDynamicCreation");

	ALuaClassObj_HandleDynamicCreation_Params params;
	params.isAsyncLoad = isAsyncLoad;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.HandleCollapseWidgetList
// ()
// Parameters:
// struct FString                 RootWidgetName                 (Parm, ZeroConstructor)

void ALuaClassObj::HandleCollapseWidgetList(const struct FString& RootWidgetName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.HandleCollapseWidgetList");

	ALuaClassObj_HandleCollapseWidgetList_Params params;
	params.RootWidgetName = RootWidgetName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.GetTopStackPanelSrcTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ALuaClassObj::GetTopStackPanelSrcTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.GetTopStackPanelSrcTag");

	ALuaClassObj_GetTopStackPanelSrcTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaClassObj.GetTopStackPanelDstTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ALuaClassObj::GetTopStackPanelDstTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.GetTopStackPanelDstTag");

	ALuaClassObj_GetTopStackPanelDstTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaClassObj.GetGameStatus
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ALuaClassObj::GetGameStatus()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.GetGameStatus");

	ALuaClassObj_GetGameStatus_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.LuaClassObj.ChangeSubUIWidgetList
// ()
// Parameters:
// TArray<struct FGameWidgetConfig> InWidgetConfigList             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void ALuaClassObj::ChangeSubUIWidgetList(TArray<struct FGameWidgetConfig> InWidgetConfigList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.ChangeSubUIWidgetList");

	ALuaClassObj_ChangeSubUIWidgetList_Params params;
	params.InWidgetConfigList = InWidgetConfigList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.LuaClassObj.AddToTopStackPanel
// ()

void ALuaClassObj::AddToTopStackPanel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.LuaClassObj.AddToTopStackPanel");

	ALuaClassObj_AddToTopStackPanel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MaskBox.SetMaskTransformScale
// ()
// Parameters:
// struct FVector2D               Scale                          (Parm, IsPlainOldData)

void UMaskBox::SetMaskTransformScale(const struct FVector2D& Scale)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MaskBox.SetMaskTransformScale");

	UMaskBox_SetMaskTransformScale_Params params;
	params.Scale = Scale;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MaskBox.SetMaskTransformPivot
// ()
// Parameters:
// struct FVector2D               Pivot                          (Parm, IsPlainOldData)

void UMaskBox::SetMaskTransformPivot(const struct FVector2D& Pivot)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MaskBox.SetMaskTransformPivot");

	UMaskBox_SetMaskTransformPivot_Params params;
	params.Pivot = Pivot;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MaskBox.SetMaskTransformAngle
// ()
// Parameters:
// float                          Angle                          (Parm, ZeroConstructor, IsPlainOldData)

void UMaskBox::SetMaskTransformAngle(float Angle)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MaskBox.SetMaskTransformAngle");

	UMaskBox_SetMaskTransformAngle_Params params;
	params.Angle = Angle;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MaskBox.SetMaskMaterial
// ()
// Parameters:
// class UMaterialInterface*      EffectMaterial                 (Parm, ZeroConstructor, IsPlainOldData)

void UMaskBox::SetMaskMaterial(class UMaterialInterface* EffectMaterial)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MaskBox.SetMaskMaterial");

	UMaskBox_SetMaskMaterial_Params params;
	params.EffectMaterial = EffectMaterial;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MaskBox.SetBrushFromTexture
// ()
// Parameters:
// class UTexture2D*              Texture                        (Parm, ZeroConstructor, IsPlainOldData)

void UMaskBox::SetBrushFromTexture(class UTexture2D* Texture)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MaskBox.SetBrushFromTexture");

	UMaskBox_SetBrushFromTexture_Params params;
	params.Texture = Texture;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.MaskBox.GetVector2D__DelegateSignature
// ()
// Parameters:
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D UMaskBox::GetVector2D__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.MaskBox.GetVector2D__DelegateSignature");

	UMaskBox_GetVector2D__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MaskBox.GetMaskMaterial
// ()
// Parameters:
// class UMaterialInstanceDynamic* ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UMaterialInstanceDynamic* UMaskBox::GetMaskMaterial()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MaskBox.GetMaskMaterial");

	UMaskBox_GetMaskMaterial_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.TickMidasPackage
// ()

void UMidasManager::TickMidasPackage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.TickMidasPackage");

	UMidasManager_TickMidasPackage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.Tick
// ()
// Parameters:
// float                          DeltaTime                      (Parm, ZeroConstructor, IsPlainOldData)

void UMidasManager::Tick(float DeltaTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.Tick");

	UMidasManager_Tick_Params params;
	params.DeltaTime = DeltaTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.SwitchPayChannel
// ()
// Parameters:
// EMidasMultiPayChannelSwitch    switchChannel                  (Parm, ZeroConstructor, IsPlainOldData)

void UMidasManager::SwitchPayChannel(EMidasMultiPayChannelSwitch switchChannel)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.SwitchPayChannel");

	UMidasManager_SwitchPayChannel_Params params;
	params.switchChannel = switchChannel;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.Subscribe
// ()
// Parameters:
// struct FString                 productid                      (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)
// struct FString                 serviceCode                    (Parm, ZeroConstructor)
// struct FString                 serviceName                    (Parm, ZeroConstructor)
// bool                           autoPay                        (Parm, ZeroConstructor, IsPlainOldData)

void UMidasManager::Subscribe(const struct FString& productid, int payItem, const struct FString& country, const struct FString& currency, const struct FString& serviceCode, const struct FString& serviceName, bool autoPay)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.Subscribe");

	UMidasManager_Subscribe_Params params;
	params.productid = productid;
	params.payItem = payItem;
	params.country = country;
	params.currency = currency;
	params.serviceCode = serviceCode;
	params.serviceName = serviceName;
	params.autoPay = autoPay;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.SetZoneID
// ()
// Parameters:
// struct FString                 inZoneID                       (Parm, ZeroConstructor)
// struct FString                 inGoodsZoneID                  (Parm, ZeroConstructor)

void UMidasManager::SetZoneID(const struct FString& inZoneID, const struct FString& inGoodsZoneID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.SetZoneID");

	UMidasManager_SetZoneID_Params params;
	params.inZoneID = inZoneID;
	params.inGoodsZoneID = inGoodsZoneID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.SetRoleInfo
// ()
// Parameters:
// int                            InChannel                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 OpenID                         (Parm, ZeroConstructor)

void UMidasManager::SetRoleInfo(int InChannel, const struct FString& OpenID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.SetRoleInfo");

	UMidasManager_SetRoleInfo_Params params;
	params.InChannel = InChannel;
	params.OpenID = OpenID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.SetMidasIDC
// ()
// Parameters:
// struct FString                 idc                            (Parm, ZeroConstructor)

void UMidasManager::SetMidasIDC(const struct FString& idc)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.SetMidasIDC");

	UMidasManager_SetMidasIDC_Params params;
	params.idc = idc;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.SetJPAge
// ()
// Parameters:
// int                            Age                            (Parm, ZeroConstructor, IsPlainOldData)

void UMidasManager::SetJPAge(int Age)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.SetJPAge");

	UMidasManager_SetJPAge_Params params;
	params.Age = Age;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.SetFrontendHUD
// ()
// Parameters:
// class UGameFrontendHUD*        InFrontendHUD                  (Parm, ZeroConstructor, IsPlainOldData)

void UMidasManager::SetFrontendHUD(class UGameFrontendHUD* InFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.SetFrontendHUD");

	UMidasManager_SetFrontendHUD_Params params;
	params.InFrontendHUD = InFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.Reprovide
// ()

void UMidasManager::Reprovide()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.Reprovide");

	UMidasManager_Reprovide_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.Pay
// ()
// Parameters:
// struct FString                 productid                      (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)

void UMidasManager::Pay(const struct FString& productid, int payItem, const struct FString& country, const struct FString& currency)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.Pay");

	UMidasManager_Pay_Params params;
	params.productid = productid;
	params.payItem = payItem;
	params.country = country;
	params.currency = currency;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.ModifySubscribe
// ()
// Parameters:
// struct FString                 oldProductId                   (Parm, ZeroConstructor)
// struct FString                 newProductid                   (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)
// struct FString                 serviceCode                    (Parm, ZeroConstructor)
// struct FString                 serviceName                    (Parm, ZeroConstructor)
// bool                           autoPay                        (Parm, ZeroConstructor, IsPlainOldData)

void UMidasManager::ModifySubscribe(const struct FString& oldProductId, const struct FString& newProductid, int payItem, const struct FString& country, const struct FString& currency, const struct FString& serviceCode, const struct FString& serviceName, bool autoPay)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.ModifySubscribe");

	UMidasManager_ModifySubscribe_Params params;
	params.oldProductId = oldProductId;
	params.newProductid = newProductid;
	params.payItem = payItem;
	params.country = country;
	params.currency = currency;
	params.serviceCode = serviceCode;
	params.serviceName = serviceName;
	params.autoPay = autoPay;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.IsH5PayEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UMidasManager::IsH5PayEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.IsH5PayEnable");

	UMidasManager_IsH5PayEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.Initialize
// ()
// Parameters:
// EMidasMultiPayChannelSwitch    envior                         (Parm, ZeroConstructor, IsPlainOldData)

void UMidasManager::Initialize(EMidasMultiPayChannelSwitch envior)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.Initialize");

	UMidasManager_Initialize_Params params;
	params.envior = envior;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.H5Pay
// ()
// Parameters:
// struct FString                 country                        (Parm, ZeroConstructor)

void UMidasManager::H5Pay(const struct FString& country)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.H5Pay");

	UMidasManager_H5Pay_Params params;
	params.country = country;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.GoodsPresent
// ()
// Parameters:
// struct FString                 productid                      (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 price                          (Parm, ZeroConstructor)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)
// struct FString                 MetaData                       (Parm, ZeroConstructor)

void UMidasManager::GoodsPresent(const struct FString& productid, int payItem, const struct FString& price, const struct FString& country, const struct FString& currency, const struct FString& MetaData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GoodsPresent");

	UMidasManager_GoodsPresent_Params params;
	params.productid = productid;
	params.payItem = payItem;
	params.price = price;
	params.country = country;
	params.currency = currency;
	params.MetaData = MetaData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.Goods
// ()
// Parameters:
// struct FString                 productid                      (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 price                          (Parm, ZeroConstructor)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)

void UMidasManager::Goods(const struct FString& productid, int payItem, const struct FString& price, const struct FString& country, const struct FString& currency)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.Goods");

	UMidasManager_Goods_Params params;
	params.productid = productid;
	params.payItem = payItem;
	params.price = price;
	params.country = country;
	params.currency = currency;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.GetProductInfo
// ()
// Parameters:
// TArray<struct FString>         listProductID                  (Parm, ZeroConstructor)

void UMidasManager::GetProductInfo(TArray<struct FString> listProductID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetProductInfo");

	UMidasManager_GetProductInfo_Params params;
	params.listProductID = listProductID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.getPF
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMidasManager::getPF()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.getPF");

	UMidasManager_getPF_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetPayEnvironment
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMidasManager::GetPayEnvironment()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetPayEnvironment");

	UMidasManager_GetPayEnvironment_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetPayChannel
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMidasManager::GetPayChannel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetPayChannel");

	UMidasManager_GetPayChannel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetPackChannel
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMidasManager::GetPackChannel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetPackChannel");

	UMidasManager_GetPackChannel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetOfferID
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMidasManager::GetOfferID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetOfferID");

	UMidasManager_GetOfferID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetNativePackageTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMidasManager::GetNativePackageTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetNativePackageTag");

	UMidasManager_GetNativePackageTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetMPInfo
// ()
// Parameters:
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)

void UMidasManager::GetMPInfo(const struct FString& country, const struct FString& currency)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetMPInfo");

	UMidasManager_GetMPInfo_Params params;
	params.country = country;
	params.currency = currency;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.GetIntroPrice
// ()
// Parameters:
// TArray<struct FString>         listProductID                  (Parm, ZeroConstructor)

void UMidasManager::GetIntroPrice(TArray<struct FString> listProductID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetIntroPrice");

	UMidasManager_GetIntroPrice_Params params;
	params.listProductID = listProductID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.MidasManager.GetInstance
// ()
// Parameters:
// class UMidasManager*           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UMidasManager* UMidasManager::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetInstance");

	UMidasManager_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetInIDC
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMidasManager::GetInIDC()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetInIDC");

	UMidasManager_GetInIDC_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.MidasManager.GetAOSSHOP
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UMidasManager::GetAOSSHOP()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.MidasManager.GetAOSSHOP");

	UMidasManager_GetAOSSHOP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.NewButton.SetClickSound
// ()
// Parameters:
// EButtonClickSoundTypes         inSoundType                    (Parm, ZeroConstructor, IsPlainOldData)

void UNewButton::SetClickSound(EButtonClickSoundTypes inSoundType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.NewButton.SetClickSound");

	UNewButton_SetClickSound_Params params;
	params.inSoundType = inSoundType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScreenInput.Shutdown
// ()

void UScreenInput::Shutdown()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenInput.Shutdown");

	UScreenInput_Shutdown_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ScreenInput.OnScreenTouch__DelegateSignature
// ()

void UScreenInput::OnScreenTouch__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ScreenInput.OnScreenTouch__DelegateSignature");

	UScreenInput_OnScreenTouch__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ScreenInput.OnMouseButtonDown__DelegateSignature
// ()
// Parameters:
// struct FVector2D               ContainerPos                   (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UScreenInput::OnMouseButtonDown__DelegateSignature(const struct FVector2D& ContainerPos)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ScreenInput.OnMouseButtonDown__DelegateSignature");

	UScreenInput_OnMouseButtonDown__DelegateSignature_Params params;
	params.ContainerPos = ContainerPos;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScreenInput.Init
// ()

void UScreenInput::Init()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenInput.Init");

	UScreenInput_Init_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScreenshotMaker.SaveToPhotosAlbumEx
// ()
// Parameters:
// struct FString                 pathStr                        (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScreenshotMaker::SaveToPhotosAlbumEx(const struct FString& pathStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.SaveToPhotosAlbumEx");

	UScreenshotMaker_SaveToPhotosAlbumEx_Params params;
	params.pathStr = pathStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.SaveToPhotosAlbum
// ()
// Parameters:
// struct FString                 pathStr                        (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScreenshotMaker::SaveToPhotosAlbum(const struct FString& pathStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.SaveToPhotosAlbum");

	UScreenshotMaker_SaveToPhotosAlbum_Params params;
	params.pathStr = pathStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.ResizePicture
// ()
// Parameters:
// struct FString                 pathStr                        (Parm, ZeroConstructor)
// float                          Scale                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 savePathStr                    (Parm, ZeroConstructor)

void UScreenshotMaker::ResizePicture(const struct FString& pathStr, float Scale, const struct FString& savePathStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.ResizePicture");

	UScreenshotMaker_ResizePicture_Params params;
	params.pathStr = pathStr;
	params.Scale = Scale;
	params.savePathStr = savePathStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScreenshotMaker.ReMakePicture
// ()
// Parameters:
// struct FString                 pathStr                        (Parm, ZeroConstructor)
// struct FVector4                Vector4                        (Parm, IsPlainOldData)

void UScreenshotMaker::ReMakePicture(const struct FString& pathStr, const struct FVector4& Vector4)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.ReMakePicture");

	UScreenshotMaker_ReMakePicture_Params params;
	params.pathStr = pathStr;
	params.Vector4 = Vector4;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScreenshotMaker.ReMakeMomentPicture
// ()
// Parameters:
// struct FString                 srcPath                        (Parm, ZeroConstructor)
// struct FVector4                Vector4                        (Parm, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScreenshotMaker::ReMakeMomentPicture(const struct FString& srcPath, const struct FVector4& Vector4)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.ReMakeMomentPicture");

	UScreenshotMaker_ReMakeMomentPicture_Params params;
	params.srcPath = srcPath;
	params.Vector4 = Vector4;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.MakePictureWithName
// ()
// Parameters:
// struct FString                 PicName                        (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScreenshotMaker::MakePictureWithName(const struct FString& PicName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.MakePictureWithName");

	UScreenshotMaker_MakePictureWithName_Params params;
	params.PicName = PicName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.MakePictureToLua
// ()
// Parameters:
// class UGameFrontendHUD*        InFrontendHUD                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 tableName                      (Parm, ZeroConstructor)
// struct FString                 FunctionName                   (Parm, ZeroConstructor)
// bool                           isShowUI                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScreenshotMaker::MakePictureToLua(class UGameFrontendHUD* InFrontendHUD, const struct FString& tableName, const struct FString& FunctionName, bool isShowUI)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.MakePictureToLua");

	UScreenshotMaker_MakePictureToLua_Params params;
	params.InFrontendHUD = InFrontendHUD;
	params.tableName = tableName;
	params.FunctionName = FunctionName;
	params.isShowUI = isShowUI;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.MakePicture
// ()
// Parameters:
// bool                           isShowUI                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScreenshotMaker::MakePicture(bool isShowUI)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.MakePicture");

	UScreenshotMaker_MakePicture_Params params;
	params.isShowUI = isShowUI;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.MakeBugReprotPic
// ()
// Parameters:
// bool                           isShowUI                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScreenshotMaker::MakeBugReprotPic(bool isShowUI)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.MakeBugReprotPic");

	UScreenshotMaker_MakeBugReprotPic_Params params;
	params.isShowUI = isShowUI;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.HasCaptured
// ()
// Parameters:
// struct FString                 pathStr                        (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScreenshotMaker::HasCaptured(const struct FString& pathStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.HasCaptured");

	UScreenshotMaker_HasCaptured_Params params;
	params.pathStr = pathStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.GetSaveStatus
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScreenshotMaker::GetSaveStatus()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.GetSaveStatus");

	UScreenshotMaker_GetSaveStatus_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.GetPhotoHash
// ()
// Parameters:
// struct FString                 pathStr                        (Parm, ZeroConstructor)
// int                            algorithmVersion               (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScreenshotMaker::GetPhotoHash(const struct FString& pathStr, int algorithmVersion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.GetPhotoHash");

	UScreenshotMaker_GetPhotoHash_Params params;
	params.pathStr = pathStr;
	params.algorithmVersion = algorithmVersion;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.GetMomentThumbPictureFullPathFiles
// ()
// Parameters:
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScreenshotMaker::GetMomentThumbPictureFullPathFiles()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.GetMomentThumbPictureFullPathFiles");

	UScreenshotMaker_GetMomentThumbPictureFullPathFiles_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScreenshotMaker.GetMomentPictureFullPathFiles
// ()
// Parameters:
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScreenshotMaker::GetMomentPictureFullPathFiles()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScreenshotMaker.GetMomentPictureFullPathFiles");

	UScreenshotMaker_GetMomentPictureFullPathFiles_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ZLIBDecompress
// ()
// Parameters:
// struct FString                 CompressedData                 (Parm, ZeroConstructor)
// int                            CompressedSize                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            UnCompressedSize               (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ZLIBDecompress(const struct FString& CompressedData, int CompressedSize, int UnCompressedSize)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ZLIBDecompress");

	UScriptHelperClient_ZLIBDecompress_Params params;
	params.CompressedData = CompressedData;
	params.CompressedSize = CompressedSize;
	params.UnCompressedSize = UnCompressedSize;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ZLIBCompress_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::ZLIBCompress_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ZLIBCompress_LuaState");

	UScriptHelperClient_ZLIBCompress_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.WechatShareWithUrlInfo
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 _descShare                     (Parm, ZeroConstructor)
// struct FString                 _titleShare                    (Parm, ZeroConstructor)
// struct FString                 _imgPath                       (Parm, ZeroConstructor)
// struct FString                 _url                           (Parm, ZeroConstructor)
// int                            _shareScene                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::WechatShareWithUrlInfo(const struct FString& _descShare, const struct FString& _titleShare, const struct FString& _imgPath, const struct FString& _url, int _shareScene, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WechatShareWithUrlInfo");

	UScriptHelperClient_WechatShareWithUrlInfo_Params params;
	params._descShare = _descShare;
	params._titleShare = _titleShare;
	params._imgPath = _imgPath;
	params._url = _url;
	params._shareScene = _shareScene;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.WeChatShareWithMiniApp
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 _descShare                     (Parm, ZeroConstructor)
// struct FString                 _titleShare                    (Parm, ZeroConstructor)
// struct FString                 _imgPath                       (Parm, ZeroConstructor)
// struct FString                 _webpageUrl                    (Parm, ZeroConstructor)
// struct FString                 _userName                      (Parm, ZeroConstructor)
// struct FString                 _path                          (Parm, ZeroConstructor)
// struct FString                 _messageExt                    (Parm, ZeroConstructor)
// struct FString                 _messageAction                 (Parm, ZeroConstructor)
// int                            _shareScene                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::WeChatShareWithMiniApp(const struct FString& _userName, const struct FString& _descShare, const struct FString& _titleShare, const struct FString& _imgPath, const struct FString& _webpageUrl, int _shareScene, const struct FString& _path, const struct FString& _messageExt, const struct FString& _messageAction, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WeChatShareWithMiniApp");

	UScriptHelperClient_WeChatShareWithMiniApp_Params params;
	params._descShare = _descShare;
	params._titleShare = _titleShare;
	params._imgPath = _imgPath;
	params._webpageUrl = _webpageUrl;
	params._userName = _userName;
	params._path = _path;
	params._messageExt = _messageExt;
	params._messageAction = _messageAction;
	params._shareScene = _shareScene;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.WechatShareToFriend
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 OpenID                         (Parm, ZeroConstructor)
// struct FString                 Title                          (Parm, ZeroConstructor)
// struct FString                 Desc                           (Parm, ZeroConstructor)
// struct FString                 mediaId                        (Parm, ZeroConstructor)
// struct FString                 messageExt                     (Parm, ZeroConstructor)
// struct FString                 mediaTagName                   (Parm, ZeroConstructor)
// struct FString                 msdkExtInfo                    (Parm, ZeroConstructor)

void UScriptHelperClient::WechatShareToFriend(const struct FString& mediaId, const struct FString& OpenID, const struct FString& Title, const struct FString& Desc, const struct FString& msdkExtInfo, const struct FString& messageExt, const struct FString& mediaTagName, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WechatShareToFriend");

	UScriptHelperClient_WechatShareToFriend_Params params;
	params.OpenID = OpenID;
	params.Title = Title;
	params.Desc = Desc;
	params.mediaId = mediaId;
	params.messageExt = messageExt;
	params.mediaTagName = mediaTagName;
	params.msdkExtInfo = msdkExtInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.WechatShare
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 _descShare                     (Parm, ZeroConstructor)
// struct FString                 _titleShare                    (Parm, ZeroConstructor)
// struct FString                 _imgPath                       (Parm, ZeroConstructor)
// struct FString                 _mediaTagName                  (Parm, ZeroConstructor)
// struct FString                 _messageExt                    (Parm, ZeroConstructor)

void UScriptHelperClient::WechatShare(const struct FString& _descShare, const struct FString& _titleShare, const struct FString& _imgPath, const struct FString& _mediaTagName, const struct FString& _messageExt, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WechatShare");

	UScriptHelperClient_WechatShare_Params params;
	params._descShare = _descShare;
	params._titleShare = _titleShare;
	params._imgPath = _imgPath;
	params._mediaTagName = _mediaTagName;
	params._messageExt = _messageExt;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.WechatQueryGroup
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 unionId                        (Parm, ZeroConstructor)
// struct FString                 OpenIdList                     (Parm, ZeroConstructor)

void UScriptHelperClient::WechatQueryGroup(const struct FString& unionId, const struct FString& OpenIdList, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WechatQueryGroup");

	UScriptHelperClient_WechatQueryGroup_Params params;
	params.unionId = unionId;
	params.OpenIdList = OpenIdList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.WechatJoinGroup
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 unionId                        (Parm, ZeroConstructor)
// struct FString                 chatRoomNickName               (Parm, ZeroConstructor)

void UScriptHelperClient::WechatJoinGroup(const struct FString& unionId, const struct FString& chatRoomNickName, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WechatJoinGroup");

	UScriptHelperClient_WechatJoinGroup_Params params;
	params.unionId = unionId;
	params.chatRoomNickName = chatRoomNickName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.WechatCreateGroup
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 unionId                        (Parm, ZeroConstructor)
// struct FString                 chatRoomName                   (Parm, ZeroConstructor)
// struct FString                 chatRoomNickName               (Parm, ZeroConstructor)

void UScriptHelperClient::WechatCreateGroup(const struct FString& unionId, const struct FString& chatRoomName, const struct FString& chatRoomNickName, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WechatCreateGroup");

	UScriptHelperClient_WechatCreateGroup_Params params;
	params.unionId = unionId;
	params.chatRoomName = chatRoomName;
	params.chatRoomNickName = chatRoomNickName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.WakeupFromSuspendSound
// ()

void UScriptHelperClient::WakeupFromSuspendSound()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.WakeupFromSuspendSound");

	UScriptHelperClient_WakeupFromSuspendSound_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.VPNTearDown
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::VPNTearDown()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNTearDown");

	UScriptHelperClient_VPNTearDown_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.VPNSetUserInfo
// ()
// Parameters:
// struct FString                 InUserId                       (Parm, ZeroConstructor)
// struct FString                 InUserToken                    (Parm, ZeroConstructor)
// struct FString                 InAppId                        (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::VPNSetUserInfo(const struct FString& InUserId, const struct FString& InUserToken, const struct FString& InAppId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNSetUserInfo");

	UScriptHelperClient_VPNSetUserInfo_Params params;
	params.InUserId = InUserId;
	params.InUserToken = InUserToken;
	params.InAppId = InAppId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.VPNSetPortRange
// ()
// Parameters:
// int                            Min                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            Max                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::VPNSetPortRange(int Min, int Max)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNSetPortRange");

	UScriptHelperClient_VPNSetPortRange_Params params;
	params.Min = Min;
	params.Max = Max;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.VPNSetNodelist
// ()
// Parameters:
// struct FString                 InNodelist                     (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::VPNSetNodelist(const struct FString& InNodelist)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNSetNodelist");

	UScriptHelperClient_VPNSetNodelist_Params params;
	params.InNodelist = InNodelist;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.VPNPrepare
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::VPNPrepare()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNPrepare");

	UScriptHelperClient_VPNPrepare_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.VPNHandUp
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::VPNHandUp()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNHandUp");

	UScriptHelperClient_VPNHandUp_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.VPNGetNodeRegionList
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::VPNGetNodeRegionList()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNGetNodeRegionList");

	UScriptHelperClient_VPNGetNodeRegionList_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.VPNDialUp
// ()
// Parameters:
// struct FString                 InRegion                       (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::VPNDialUp(const struct FString& InRegion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.VPNDialUp");

	UScriptHelperClient_VPNDialUp_Params params;
	params.InRegion = InRegion;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.Vibrate
// ()
// Parameters:
// int                            Param                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::Vibrate(int Param)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Vibrate");

	UScriptHelperClient_Vibrate_Params params;
	params.Param = Param;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.UserName
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::UserName()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UserName");

	UScriptHelperClient_UserName_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.UrlEncode
// ()
// Parameters:
// struct FString                 UnencodedString                (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::UrlEncode(const struct FString& UnencodedString)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UrlEncode");

	UScriptHelperClient_UrlEncode_Params params;
	params.UnencodedString = UnencodedString;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.UpdatePublishRegionForBattle
// ()

void UScriptHelperClient::UpdatePublishRegionForBattle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UpdatePublishRegionForBattle");

	UScriptHelperClient_UpdatePublishRegionForBattle_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.UpdateMemResource
// ()
// Parameters:
// struct FString                 ResType                        (Parm, ZeroConstructor)
// struct FString                 KeyWord                        (Parm, ZeroConstructor)

void UScriptHelperClient::UpdateMemResource(const struct FString& ResType, const struct FString& KeyWord)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UpdateMemResource");

	UScriptHelperClient_UpdateMemResource_Params params;
	params.ResType = ResType;
	params.KeyWord = KeyWord;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.UpdateAkAudioDeviceBluetoothDelay
// ()
// Parameters:
// int                            InDelayTime                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::UpdateAkAudioDeviceBluetoothDelay(int InDelayTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UpdateAkAudioDeviceBluetoothDelay");

	UScriptHelperClient_UpdateAkAudioDeviceBluetoothDelay_Params params;
	params.InDelayTime = InDelayTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.UnsubscribeFromTopic
// ()
// Parameters:
// struct FString                 Topic                          (Parm, ZeroConstructor)

void UScriptHelperClient::UnsubscribeFromTopic(const struct FString& Topic)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UnsubscribeFromTopic");

	UScriptHelperClient_UnsubscribeFromTopic_Params params;
	params.Topic = Topic;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.UnmountPakFile
// ()
// Parameters:
// struct FString                 InPakFilename                  (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::UnmountPakFile(const struct FString& InPakFilename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UnmountPakFile");

	UScriptHelperClient_UnmountPakFile_Params params;
	params.InPakFilename = InPakFilename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.UnitTestODPaksOpen
// ()
// Parameters:
// int                            fileCount                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            Times                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            threadNum                      (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::UnitTestODPaksOpen(int fileCount, int Times, int threadNum)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.UnitTestODPaksOpen");

	UScriptHelperClient_UnitTestODPaksOpen_Params params;
	params.fileCount = fileCount;
	params.Times = Times;
	params.threadNum = threadNum;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TVMacroTesting
// ()

void UScriptHelperClient::TVMacroTesting()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TVMacroTesting");

	UScriptHelperClient_TVMacroTesting_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TriggerTouchEvent
// ()
// Parameters:
// float                          X                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            event_type                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::TriggerTouchEvent(float X, float Y, int event_type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TriggerTouchEvent");

	UScriptHelperClient_TriggerTouchEvent_Params params;
	params.X = X;
	params.Y = Y;
	params.event_type = event_type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TriggerLoginCrashTest
// ()

void UScriptHelperClient::TriggerLoginCrashTest()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TriggerLoginCrashTest");

	UScriptHelperClient_TriggerLoginCrashTest_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TriggerLobbyCrashTest
// ()

void UScriptHelperClient::TriggerLobbyCrashTest()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TriggerLobbyCrashTest");

	UScriptHelperClient_TriggerLobbyCrashTest_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TriggerBlockAndroidANR
// ()

void UScriptHelperClient::TriggerBlockAndroidANR()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TriggerBlockAndroidANR");

	UScriptHelperClient_TriggerBlockAndroidANR_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.Tex_UpdateMemResource
// ()
// Parameters:
// struct FString                 KeyWord                        (Parm, ZeroConstructor)

void UScriptHelperClient::Tex_UpdateMemResource(const struct FString& KeyWord)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Tex_UpdateMemResource");

	UScriptHelperClient_Tex_UpdateMemResource_Params params;
	params.KeyWord = KeyWord;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.Tex_DumpMemObjectInfo
// ()
// Parameters:
// struct FString                 KeyWord                        (Parm, ZeroConstructor)

void UScriptHelperClient::Tex_DumpMemObjectInfo(const struct FString& KeyWord)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Tex_DumpMemObjectInfo");

	UScriptHelperClient_Tex_DumpMemObjectInfo_Params params;
	params.KeyWord = KeyWord;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.Tea2Encrypt_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::Tea2Encrypt_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Tea2Encrypt_LuaState");

	UScriptHelperClient_Tea2Encrypt_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.Tea2Decrypt_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::Tea2Decrypt_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Tea2Decrypt_LuaState");

	UScriptHelperClient_Tea2Decrypt_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.TapmReport
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ExtraInfo                      (Parm, ZeroConstructor)
// bool                           send                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::TapmReport(int Type, const struct FString& ExtraInfo, bool send)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TapmReport");

	UScriptHelperClient_TapmReport_Params params;
	params.Type = Type;
	params.ExtraInfo = ExtraInfo;
	params.send = send;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TapmPostLargeValueS
// ()
// Parameters:
// struct FString                 catgory                        (Parm, ZeroConstructor)
// struct FString                 Key                            (Parm, ZeroConstructor)
// struct FString                 Value                          (Parm, ZeroConstructor)

void UScriptHelperClient::TapmPostLargeValueS(const struct FString& catgory, const struct FString& Key, const struct FString& Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TapmPostLargeValueS");

	UScriptHelperClient_TapmPostLargeValueS_Params params;
	params.catgory = catgory;
	params.Key = Key;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TapmMarkTime
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::TapmMarkTime(int Type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TapmMarkTime");

	UScriptHelperClient_TapmMarkTime_Params params;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TapmMarkLevelFin
// ()

void UScriptHelperClient::TapmMarkLevelFin()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TapmMarkLevelFin");

	UScriptHelperClient_TapmMarkLevelFin_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TApmDisconnectReport
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            EventId                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::TApmDisconnectReport(class UGameFrontendHUD* GameFrontendHUD, int EventId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TApmDisconnectReport");

	UScriptHelperClient_TApmDisconnectReport_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.EventId = EventId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.TApmDataReport
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            EventId                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 EventInfo                      (Parm, ZeroConstructor)

void UScriptHelperClient::TApmDataReport(class UGameFrontendHUD* GameFrontendHUD, int EventId, const struct FString& EventInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.TApmDataReport");

	UScriptHelperClient_TApmDataReport_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.EventId = EventId;
	params.EventInfo = EventInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SwitchUser
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           useExternalAccount             (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SwitchUser(bool useExternalAccount, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SwitchUser");

	UScriptHelperClient_SwitchUser_Params params;
	params.useExternalAccount = useExternalAccount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.SwitchSceneCamera
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 SceneCameraName                (Parm, ZeroConstructor)
// float                          blendTime                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bForce                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SwitchSceneCamera(class UGameFrontendHUD* GameFrontendHUD, const struct FString& SceneCameraName, float blendTime, bool bForce)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SwitchSceneCamera");

	UScriptHelperClient_SwitchSceneCamera_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.SceneCameraName = SceneCameraName;
	params.blendTime = blendTime;
	params.bForce = bForce;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SwitchCampRoom
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            campMode                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SwitchCampRoom(class UGameFrontendHUD* GameFrontendHUD, int campMode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SwitchCampRoom");

	UScriptHelperClient_SwitchCampRoom_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.campMode = campMode;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SuspendSound
// ()

void UScriptHelperClient::SuspendSound()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SuspendSound");

	UScriptHelperClient_SuspendSound_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SubscribeToTopic
// ()
// Parameters:
// struct FString                 Topic                          (Parm, ZeroConstructor)

void UScriptHelperClient::SubscribeToTopic(const struct FString& Topic)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SubscribeToTopic");

	UScriptHelperClient_SubscribeToTopic_Params params;
	params.Topic = Topic;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StringToFMargin
// ()
// Parameters:
// struct FString                 MarginStr                      (Parm, ZeroConstructor)
// struct FMargin                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FMargin UScriptHelperClient::StringToFMargin(const struct FString& MarginStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StringToFMargin");

	UScriptHelperClient_StringToFMargin_Params params;
	params.MarginStr = MarginStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.StopUIStat
// ()
// Parameters:
// struct FString                 UIName                         (Parm, ZeroConstructor)
// bool                           bReport                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::StopUIStat(const struct FString& UIName, bool bReport)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StopUIStat");

	UScriptHelperClient_StopUIStat_Params params;
	params.UIName = UIName;
	params.bReport = bReport;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StopTouchRecord
// ()
// Parameters:
// struct FTouchInputRecord       ReturnValue                    (Parm, OutParm, ReturnParm)

struct FTouchInputRecord UScriptHelperClient::StopTouchRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StopTouchRecord");

	UScriptHelperClient_StopTouchRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.StopTask
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       TaskId                         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::StopTask(class UGameFrontendHUD* GameFrontendHUD, uint64_t TaskId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StopTask");

	UScriptHelperClient_StopTask_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.TaskId = TaskId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.StopShaderPrecompile
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::StopShaderPrecompile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StopShaderPrecompile");

	UScriptHelperClient_StopShaderPrecompile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.StopHapticsEngine
// ()

void UScriptHelperClient::StopHapticsEngine()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StopHapticsEngine");

	UScriptHelperClient_StopHapticsEngine_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StopH5Downloading
// ()

void UScriptHelperClient::StopH5Downloading()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StopH5Downloading");

	UScriptHelperClient_StopH5Downloading_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StopCampMode
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::StopCampMode(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StopCampMode");

	UScriptHelperClient_StopCampMode_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartUIStat
// ()
// Parameters:
// struct FString                 UIName                         (Parm, ZeroConstructor)

void UScriptHelperClient::StartUIStat(const struct FString& UIName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartUIStat");

	UScriptHelperClient_StartUIStat_Params params;
	params.UIName = UIName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartTrace
// ()
// Parameters:
// struct FString                 InHost                         (Parm, ZeroConstructor)
// int                            InStartTTL                     (Parm, ZeroConstructor, IsPlainOldData)
// int                            InMaxTTL                       (Parm, ZeroConstructor, IsPlainOldData)
// int                            InCount                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::StartTrace(const struct FString& InHost, int InStartTTL, int InMaxTTL, int InCount)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartTrace");

	UScriptHelperClient_StartTrace_Params params;
	params.InHost = InHost;
	params.InStartTTL = InStartTTL;
	params.InMaxTTL = InMaxTTL;
	params.InCount = InCount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartTouchRecord
// ()

void UScriptHelperClient::StartTouchRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartTouchRecord");

	UScriptHelperClient_StartTouchRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartShaderPrecompile
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::StartShaderPrecompile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartShaderPrecompile");

	UScriptHelperClient_StartShaderPrecompile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.StartOpenReadCollect
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bStart                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::StartOpenReadCollect(class UGameFrontendHUD* GameFrontendHUD, bool bStart)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartOpenReadCollect");

	UScriptHelperClient_StartOpenReadCollect_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bStart = bStart;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartHapticsEngine
// ()
// Parameters:
// struct FScriptDelegate         Callback                       (Parm, ZeroConstructor)

void UScriptHelperClient::StartHapticsEngine(const struct FScriptDelegate& Callback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartHapticsEngine");

	UScriptHelperClient_StartHapticsEngine_Params params;
	params.Callback = Callback;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartGrayUpdate
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::StartGrayUpdate(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartGrayUpdate");

	UScriptHelperClient_StartGrayUpdate_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.StartDownloadItem
// ()
// Parameters:
// uint32_t                       ItemId                         (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         OnItemDownloadDelegate         (Parm, ZeroConstructor)

void UScriptHelperClient::StartDownloadItem(uint32_t ItemId, uint32_t Priority, const struct FScriptDelegate& OnItemDownloadDelegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartDownloadItem");

	UScriptHelperClient_StartDownloadItem_Params params;
	params.ItemId = ItemId;
	params.Priority = Priority;
	params.OnItemDownloadDelegate = OnItemDownloadDelegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartDolphinResourceUpdate
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::StartDolphinResourceUpdate(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartDolphinResourceUpdate");

	UScriptHelperClient_StartDolphinResourceUpdate_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartCDNUpdateAfterDolphinUpdateFailed
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::StartCDNUpdateAfterDolphinUpdateFailed(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartCDNUpdateAfterDolphinUpdateFailed");

	UScriptHelperClient_StartCDNUpdateAfterDolphinUpdateFailed_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartCampMode
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ZombieCampRoomName             (Parm, ZeroConstructor)
// struct FString                 ManCampRoomName                (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)

void UScriptHelperClient::StartCampMode(class UGameFrontendHUD* GameFrontendHUD, const struct FString& ZombieCampRoomName, const struct FString& ManCampRoomName, const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartCampMode");

	UScriptHelperClient_StartCampMode_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ZombieCampRoomName = ZombieCampRoomName;
	params.ManCampRoomName = ManCampRoomName;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.StartBatchDownloadItem
// ()
// Parameters:
// TArray<uint32_t>               ItemIDs                        (Parm, ZeroConstructor)
// uint32_t                       Priority                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         OnBatchItemDownloadDelegate    (Parm, ZeroConstructor)

void UScriptHelperClient::StartBatchDownloadItem(TArray<uint32_t> ItemIDs, uint32_t Priority, const struct FScriptDelegate& OnBatchItemDownloadDelegate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.StartBatchDownloadItem");

	UScriptHelperClient_StartBatchDownloadItem_Params params;
	params.ItemIDs = ItemIDs;
	params.Priority = Priority;
	params.OnBatchItemDownloadDelegate = OnBatchItemDownloadDelegate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShutdownUnrealNetwork
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ShutdownUnrealNetwork(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShutdownUnrealNetwork");

	UScriptHelperClient_ShutdownUnrealNetwork_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShutdownPuffer
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ShutdownPuffer(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShutdownPuffer");

	UScriptHelperClient_ShutdownPuffer_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShowWebView
// ()
// Parameters:
// bool                           Show                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ShowWebView(bool Show)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShowWebView");

	UScriptHelperClient_ShowWebView_Params params;
	params.Show = Show;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShowVLink
// ()
// Parameters:
// struct FString                 jsonString                     (Parm, ZeroConstructor)
// struct FString                 signString                     (Parm, ZeroConstructor)

void UScriptHelperClient::ShowVLink(const struct FString& jsonString, const struct FString& signString)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShowVLink");

	UScriptHelperClient_ShowVLink_Params params;
	params.jsonString = jsonString;
	params.signString = signString;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShowVideoListDialog
// ()

void UScriptHelperClient::ShowVideoListDialog()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShowVideoListDialog");

	UScriptHelperClient_ShowVideoListDialog_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShowScreenDebugMessage
// ()
// Parameters:
// struct FString                 Message                        (Parm, ZeroConstructor)

void UScriptHelperClient::ShowScreenDebugMessage(const struct FString& Message)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShowScreenDebugMessage");

	UScriptHelperClient_ShowScreenDebugMessage_Params params;
	params.Message = Message;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShowH5WebView
// ()

void UScriptHelperClient::ShowH5WebView()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShowH5WebView");

	UScriptHelperClient_ShowH5WebView_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShorterStreamingDistanceWhenGameEnd
// ()
// Parameters:
// uint32_t                       Distance                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ShorterStreamingDistanceWhenGameEnd(uint32_t Distance)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShorterStreamingDistanceWhenGameEnd");

	UScriptHelperClient_ShorterStreamingDistanceWhenGameEnd_Params params;
	params.Distance = Distance;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ShareWithUploadPhotoByChannel
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 _imgPath                       (Parm, ZeroConstructor)
// int                            _channel                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 _url                           (Parm, ZeroConstructor)

void UScriptHelperClient::ShareWithUploadPhotoByChannel(const struct FString& _imgPath, int _channel, const struct FString& _url, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShareWithUploadPhotoByChannel");

	UScriptHelperClient_ShareWithUploadPhotoByChannel_Params params;
	params._imgPath = _imgPath;
	params._channel = _channel;
	params._url = _url;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.ShareWithPhotoByChannel
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 _imgPath                       (Parm, ZeroConstructor)
// struct FString                 _mediaTagName                  (Parm, ZeroConstructor)
// struct FString                 _messageExt                    (Parm, ZeroConstructor)
// struct FString                 _messageAction                 (Parm, ZeroConstructor)
// int                            _channel                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 _url                           (Parm, ZeroConstructor)

void UScriptHelperClient::ShareWithPhotoByChannel(const struct FString& _messageExt, const struct FString& _imgPath, const struct FString& _mediaTagName, const struct FString& _url, const struct FString& _messageAction, int _channel, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShareWithPhotoByChannel");

	UScriptHelperClient_ShareWithPhotoByChannel_Params params;
	params._imgPath = _imgPath;
	params._mediaTagName = _mediaTagName;
	params._messageExt = _messageExt;
	params._messageAction = _messageAction;
	params._channel = _channel;
	params._url = _url;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.ShareLogFile
// ()

void UScriptHelperClient::ShareLogFile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ShareLogFile");

	UScriptHelperClient_ShareLogFile_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetWeatherInfo
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            WeatherID                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 WeatherName                    (Parm, ZeroConstructor)

void UScriptHelperClient::SetWeatherInfo(class UGameFrontendHUD* GameFrontendHUD, int WeatherID, const struct FString& WeatherName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetWeatherInfo");

	UScriptHelperClient_SetWeatherInfo_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.WeatherID = WeatherID;
	params.WeatherName = WeatherName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetVoiceSwitch
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           FirstVoicePopupSwitch          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GDPRForbidVoiceSwitch          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GDPRSettingSwitch              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetVoiceSwitch(class UGameFrontendHUD* GameFrontendHUD, bool FirstVoicePopupSwitch, bool GDPRForbidVoiceSwitch, bool GDPRSettingSwitch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetVoiceSwitch");

	UScriptHelperClient_SetVoiceSwitch_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.FirstVoicePopupSwitch = FirstVoicePopupSwitch;
	params.GDPRForbidVoiceSwitch = GDPRForbidVoiceSwitch;
	params.GDPRSettingSwitch = GDPRSettingSwitch;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetVoiceReEneterInfo
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// float                          Duration                       (Parm, ZeroConstructor, IsPlainOldData)
// int                            MaxCount                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetVoiceReEneterInfo(class UGameFrontendHUD* GameFrontendHUD, float Duration, int MaxCount)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetVoiceReEneterInfo");

	UScriptHelperClient_SetVoiceReEneterInfo_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Duration = Duration;
	params.MaxCount = MaxCount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetUserVulkanSetting
// ()
// Parameters:
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetUserVulkanSetting(bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetUserVulkanSetting");

	UScriptHelperClient_SetUserVulkanSetting_Params params;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetUserProperty
// ()
// Parameters:
// struct FString                 propertyKey                    (Parm, ZeroConstructor)
// struct FString                 propertyValue                  (Parm, ZeroConstructor)

void UScriptHelperClient::SetUserProperty(const struct FString& propertyKey, const struct FString& propertyValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetUserProperty");

	UScriptHelperClient_SetUserProperty_Params params;
	params.propertyKey = propertyKey;
	params.propertyValue = propertyValue;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetUpdatedSoPatchFile
// ()
// Parameters:
// struct FString                 InSourceFile                   (Parm, ZeroConstructor)
// int                            InABI                          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::SetUpdatedSoPatchFile(const struct FString& InSourceFile, int InABI)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetUpdatedSoPatchFile");

	UScriptHelperClient_SetUpdatedSoPatchFile_Params params;
	params.InSourceFile = InSourceFile;
	params.InABI = InABI;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetupAkAudioDeviceListener
// ()

void UScriptHelperClient::SetupAkAudioDeviceListener()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetupAkAudioDeviceListener");

	UScriptHelperClient_SetupAkAudioDeviceListener_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetUIStatMaxClickTimes
// ()
// Parameters:
// int                            Times                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetUIStatMaxClickTimes(int Times)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetUIStatMaxClickTimes");

	UScriptHelperClient_SetUIStatMaxClickTimes_Params params;
	params.Times = Times;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetUIRectOffset
// ()
// Parameters:
// struct FString                 uirect                         (Parm, ZeroConstructor)

void UScriptHelperClient::SetUIRectOffset(const struct FString& uirect)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetUIRectOffset");

	UScriptHelperClient_SetUIRectOffset_Params params;
	params.uirect = uirect;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetUIElemLayoutJsonConfigSwitch
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           UIElemLayoutJsonConfigSwitch   (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetUIElemLayoutJsonConfigSwitch(class UGameFrontendHUD* GameFrontendHUD, bool UIElemLayoutJsonConfigSwitch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetUIElemLayoutJsonConfigSwitch");

	UScriptHelperClient_SetUIElemLayoutJsonConfigSwitch_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.UIElemLayoutJsonConfigSwitch = UIElemLayoutJsonConfigSwitch;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetTssNetworkStatus
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            Status                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetTssNetworkStatus(class UGameFrontendHUD* GameFrontendHUD, int Status)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetTssNetworkStatus");

	UScriptHelperClient_SetTssNetworkStatus_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Status = Status;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetTickMemoryInterval
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// float                          interval                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetTickMemoryInterval(class UGameFrontendHUD* GameFrontendHUD, float interval)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetTickMemoryInterval");

	UScriptHelperClient_SetTickMemoryInterval_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.interval = interval;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetTestEditorNum
// ()
// Parameters:
// int                            playerCount                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Num                            (Parm, ZeroConstructor)
// struct FString                 SceneName                      (Parm, ZeroConstructor)
// int                            Platform                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetTestEditorNum(int playerCount, const struct FString& Num, const struct FString& SceneName, int Platform)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetTestEditorNum");

	UScriptHelperClient_SetTestEditorNum_Params params;
	params.playerCount = playerCount;
	params.Num = Num;
	params.SceneName = SceneName;
	params.Platform = Platform;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetTableFilterInfo_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::SetTableFilterInfo_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetTableFilterInfo_LuaState");

	UScriptHelperClient_SetTableFilterInfo_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetSoundEffectQuality
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::SetSoundEffectQuality(int Type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetSoundEffectQuality");

	UScriptHelperClient_SetSoundEffectQuality_Params params;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetShowFriendObservers
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bShow                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetShowFriendObservers(class UGameFrontendHUD* GameFrontendHUD, bool bShow)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetShowFriendObservers");

	UScriptHelperClient_SetShowFriendObservers_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bShow = bShow;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetSelfieSwitch
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           SelfieSwitch                   (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetSelfieSwitch(class UGameFrontendHUD* GameFrontendHUD, bool SelfieSwitch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetSelfieSwitch");

	UScriptHelperClient_SetSelfieSwitch_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.SelfieSwitch = SelfieSwitch;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetSdkIoctl
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            request                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Token                          (Parm, OutParm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::SetSdkIoctl(class UGameFrontendHUD* GameFrontendHUD, int request, struct FString* Token)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetSdkIoctl");

	UScriptHelperClient_SetSdkIoctl_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.request = request;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Token != nullptr)
		*Token = params.Token;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetScreenHole
// ()
// Parameters:
// struct FString                 sceenHole                      (Parm, ZeroConstructor)

void UScriptHelperClient::SetScreenHole(const struct FString& sceenHole)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetScreenHole");

	UScriptHelperClient_SetScreenHole_Params params;
	params.sceenHole = sceenHole;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetReportBugSwitch
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReportBugSwitch                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetReportBugSwitch(class UGameFrontendHUD* GameFrontendHUD, bool ReportBugSwitch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetReportBugSwitch");

	UScriptHelperClient_SetReportBugSwitch_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ReportBugSwitch = ReportBugSwitch;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetRemoteResource
// ()
// Parameters:
// struct FString                 AssetId                        (Parm, ZeroConstructor)
// class UObject*                 DescObj                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetRemoteResource(const struct FString& AssetId, class UObject* DescObj)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetRemoteResource");

	UScriptHelperClient_SetRemoteResource_Params params;
	params.AssetId = AssetId;
	params.DescObj = DescObj;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetRegionNoByLua
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            regionNo                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetRegionNoByLua(int regionNo, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetRegionNoByLua");

	UScriptHelperClient_SetRegionNoByLua_Params params;
	params.regionNo = regionNo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.SetRedBloodSwitch
// ()
// Parameters:
// bool                           redBloodSwitch                 (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetRedBloodSwitch(bool redBloodSwitch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetRedBloodSwitch");

	UScriptHelperClient_SetRedBloodSwitch_Params params;
	params.redBloodSwitch = redBloodSwitch;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetPufferBuildInfo
// ()
// Parameters:
// struct FString                 PipeLineID                     (Parm, ZeroConstructor)
// struct FString                 BuildNo                        (Parm, ZeroConstructor)

void UScriptHelperClient::SetPufferBuildInfo(const struct FString& PipeLineID, const struct FString& BuildNo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetPufferBuildInfo");

	UScriptHelperClient_SetPufferBuildInfo_Params params;
	params.PipeLineID = PipeLineID;
	params.BuildNo = BuildNo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetPublishRegion
// ()
// Parameters:
// struct FString                 Region                         (Parm, ZeroConstructor)

void UScriptHelperClient::SetPublishRegion(const struct FString& Region)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetPublishRegion");

	UScriptHelperClient_SetPublishRegion_Params params;
	params.Region = Region;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetPlayerBaseInfo
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 OpenID                         (Parm, ZeroConstructor)
// uint64_t                       RoleID                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 PlayerName                     (Parm, ZeroConstructor)
// struct FString                 HeadIconUrl                    (Parm, ZeroConstructor)

void UScriptHelperClient::SetPlayerBaseInfo(class UGameFrontendHUD* GameFrontendHUD, const struct FString& OpenID, uint64_t RoleID, const struct FString& PlayerName, const struct FString& HeadIconUrl)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetPlayerBaseInfo");

	UScriptHelperClient_SetPlayerBaseInfo_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.OpenID = OpenID;
	params.RoleID = RoleID;
	params.PlayerName = PlayerName;
	params.HeadIconUrl = HeadIconUrl;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetOnGetItemBigIcon
// ()
// Parameters:
// struct FScriptDelegate         onShow                         (Parm, ZeroConstructor)

void UScriptHelperClient::SetOnGetItemBigIcon(const struct FScriptDelegate& onShow)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetOnGetItemBigIcon");

	UScriptHelperClient_SetOnGetItemBigIcon_Params params;
	params.onShow = onShow;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetNationSwitch
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           NationAllSwitch                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           NationBattleSwitch             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           NationRankSwitch               (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetNationSwitch(class UGameFrontendHUD* GameFrontendHUD, bool NationAllSwitch, bool NationBattleSwitch, bool NationRankSwitch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetNationSwitch");

	UScriptHelperClient_SetNationSwitch_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.NationAllSwitch = NationAllSwitch;
	params.NationBattleSwitch = NationBattleSwitch;
	params.NationRankSwitch = NationRankSwitch;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetMyFriendObserversDetail
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FFriendObserver> FriendObserversDetails         (Parm, ZeroConstructor)

void UScriptHelperClient::SetMyFriendObserversDetail(class UGameFrontendHUD* GameFrontendHUD, TArray<struct FFriendObserver> FriendObserversDetails)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetMyFriendObserversDetail");

	UScriptHelperClient_SetMyFriendObserversDetail_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.FriendObserversDetails = FriendObserversDetails;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetModName_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::SetModName_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetModName_LuaState");

	UScriptHelperClient_SetModName_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetMiniGameFinalAwardResId
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            AwardResId                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetMiniGameFinalAwardResId(class UGameFrontendHUD* GameFrontendHUD, int AwardResId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetMiniGameFinalAwardResId");

	UScriptHelperClient_SetMiniGameFinalAwardResId_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.AwardResId = AwardResId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetMidasZoneID_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::SetMidasZoneID_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetMidasZoneID_LuaState");

	UScriptHelperClient_SetMidasZoneID_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetMidasIDC
// ()
// Parameters:
// struct FString                 midasIdc                       (Parm, ZeroConstructor)

void UScriptHelperClient::SetMidasIDC(const struct FString& midasIdc)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetMidasIDC");

	UScriptHelperClient_SetMidasIDC_Params params;
	params.midasIdc = midasIdc;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetLinkStyle
// ()
// Parameters:
// struct FString                 StyleName                      (Parm, ZeroConstructor)
// int                            FontSize                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FontPath                       (Parm, ZeroConstructor)
// struct FString                 FontColor                      (Parm, ZeroConstructor)
// bool                           ShowUnderline                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 PathHyperLinkNormalBrush       (Parm, ZeroConstructor)
// struct FString                 PathHyperLinkHoveredrBrush     (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::SetLinkStyle(const struct FString& StyleName, int FontSize, const struct FString& FontPath, const struct FString& FontColor, bool ShowUnderline, const struct FString& PathHyperLinkNormalBrush, const struct FString& PathHyperLinkHoveredrBrush)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetLinkStyle");

	UScriptHelperClient_SetLinkStyle_Params params;
	params.StyleName = StyleName;
	params.FontSize = FontSize;
	params.FontPath = FontPath;
	params.FontColor = FontColor;
	params.ShowUnderline = ShowUnderline;
	params.PathHyperLinkNormalBrush = PathHyperLinkNormalBrush;
	params.PathHyperLinkHoveredrBrush = PathHyperLinkHoveredrBrush;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetLevelStreamingUnloadTimeslice
// ()
// Parameters:
// bool                           Enabled                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetLevelStreamingUnloadTimeslice(bool Enabled)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetLevelStreamingUnloadTimeslice");

	UScriptHelperClient_SetLevelStreamingUnloadTimeslice_Params params;
	params.Enabled = Enabled;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetiTOPLbsDelay
// ()
// Parameters:
// int                            Delay                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetiTOPLbsDelay(int Delay)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetiTOPLbsDelay");

	UScriptHelperClient_SetiTOPLbsDelay_Params params;
	params.Delay = Delay;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetIPRegion
// ()
// Parameters:
// int                            region_no                      (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetIPRegion(int region_no)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetIPRegion");

	UScriptHelperClient_SetIPRegion_Params params;
	params.region_no = region_no;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetIosStuckEnableByServerConfig
// ()
// Parameters:
// int                            bEnable                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetIosStuckEnableByServerConfig(int bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetIosStuckEnableByServerConfig");

	UScriptHelperClient_SetIosStuckEnableByServerConfig_Params params;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetIOSBGDownloadAttribute
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnableCellularAccess          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnableResumeData              (Parm, ZeroConstructor, IsPlainOldData)
// int                            nMinFileSize                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            nMaxTasks                      (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetIOSBGDownloadAttribute(class UGameFrontendHUD* GameFrontendHUD, bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetIOSBGDownloadAttribute");

	UScriptHelperClient_SetIOSBGDownloadAttribute_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bEnableCellularAccess = bEnableCellularAccess;
	params.bEnableResumeData = bEnableResumeData;
	params.nMinFileSize = nMinFileSize;
	params.nMaxTasks = nMaxTasks;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetIntDefaultConfig
// ()
// Parameters:
// int                            Value                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetIntDefaultConfig(int Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetIntDefaultConfig");

	UScriptHelperClient_SetIntDefaultConfig_Params params;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetImageVersionString
// ()
// Parameters:
// struct FString                 oldVersion                     (Parm, ZeroConstructor)
// struct FString                 newVersion                     (Parm, ZeroConstructor)

void UScriptHelperClient::SetImageVersionString(const struct FString& oldVersion, const struct FString& newVersion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetImageVersionString");

	UScriptHelperClient_SetImageVersionString_Params params;
	params.oldVersion = oldVersion;
	params.newVersion = newVersion;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetImageStyle
// ()
// Parameters:
// struct FString                 StyleName                      (Parm, ZeroConstructor)
// int                            ImageSize                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ImagePath                      (Parm, ZeroConstructor)
// struct FString                 ImageColor                     (Parm, ZeroConstructor)
// bool                           bPreLoad                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::SetImageStyle(const struct FString& StyleName, int ImageSize, const struct FString& ImagePath, const struct FString& ImageColor, bool bPreLoad)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetImageStyle");

	UScriptHelperClient_SetImageStyle_Params params;
	params.StyleName = StyleName;
	params.ImageSize = ImageSize;
	params.ImagePath = ImagePath;
	params.ImageColor = ImageColor;
	params.bPreLoad = bPreLoad;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetHapticsEngineEnable
// ()
// Parameters:
// bool                           bEnable                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetHapticsEngineEnable(bool bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetHapticsEngineEnable");

	UScriptHelperClient_SetHapticsEngineEnable_Params params;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetGlobalRedBloodSwitch
// ()
// Parameters:
// bool                           redBloodSwitch                 (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetGlobalRedBloodSwitch(bool redBloodSwitch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetGlobalRedBloodSwitch");

	UScriptHelperClient_SetGlobalRedBloodSwitch_Params params;
	params.redBloodSwitch = redBloodSwitch;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetGDPRUserType
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            GDPRUserType                   (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetGDPRUserType(class UGameFrontendHUD* GameFrontendHUD, int GDPRUserType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetGDPRUserType");

	UScriptHelperClient_SetGDPRUserType_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.GDPRUserType = GDPRUserType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetGameStatusMap
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// TMap<struct FName, struct FString> GameStatusMap                  (Parm, ZeroConstructor)

void UScriptHelperClient::SetGameStatusMap(class UGameFrontendHUD* GameFrontendHUD, TMap<struct FName, struct FString> GameStatusMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetGameStatusMap");

	UScriptHelperClient_SetGameStatusMap_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.GameStatusMap = GameStatusMap;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetGameSrvID
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            GameSrvID                      (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetGameSrvID(class UGameFrontendHUD* GameFrontendHUD, int GameSrvID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetGameSrvID");

	UScriptHelperClient_SetGameSrvID_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.GameSrvID = GameSrvID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetFontStyle
// ()
// Parameters:
// struct FString                 StyleName                      (Parm, ZeroConstructor)
// int                            FontSize                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FontPath                       (Parm, ZeroConstructor)
// struct FString                 FontColor                      (Parm, ZeroConstructor)
// bool                           UseShadow                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           IsBold                         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::SetFontStyle(const struct FString& StyleName, int FontSize, const struct FString& FontPath, const struct FString& FontColor, bool UseShadow, bool IsBold)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetFontStyle");

	UScriptHelperClient_SetFontStyle_Params params;
	params.StyleName = StyleName;
	params.FontSize = FontSize;
	params.FontPath = FontPath;
	params.FontColor = FontColor;
	params.UseShadow = UseShadow;
	params.IsBold = IsBold;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SetExtraLocalizationMap
// ()
// Parameters:
// TMap<struct FString, struct FString> translationMap                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UScriptHelperClient::SetExtraLocalizationMap(TMap<struct FString, struct FString> translationMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetExtraLocalizationMap");

	UScriptHelperClient_SetExtraLocalizationMap_Params params;
	params.translationMap = translationMap;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetExtraItemTableMappingByFix
// ()
// Parameters:
// TMap<int, struct FItemFixTableItem> ItemFixMap                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UScriptHelperClient::SetExtraItemTableMappingByFix(TMap<int, struct FItemFixTableItem> ItemFixMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetExtraItemTableMappingByFix");

	UScriptHelperClient_SetExtraItemTableMappingByFix_Params params;
	params.ItemFixMap = ItemFixMap;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetDynamicLevels
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FString>         DynamicLevels                  (Parm, ZeroConstructor)

void UScriptHelperClient::SetDynamicLevels(class UGameFrontendHUD* GameFrontendHUD, TArray<struct FString> DynamicLevels)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetDynamicLevels");

	UScriptHelperClient_SetDynamicLevels_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.DynamicLevels = DynamicLevels;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetDumpShaderCompile
// ()
// Parameters:
// int                            iDumpVal                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetDumpShaderCompile(int iDumpVal)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetDumpShaderCompile");

	UScriptHelperClient_SetDumpShaderCompile_Params params;
	params.iDumpVal = iDumpVal;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetCrashContextReportLevel
// ()
// Parameters:
// int                            Level                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetCrashContextReportLevel(int Level)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetCrashContextReportLevel");

	UScriptHelperClient_SetCrashContextReportLevel_Params params;
	params.Level = Level;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetCanWatchEnemy
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bCan                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SetCanWatchEnemy(class UGameFrontendHUD* GameFrontendHUD, bool bCan)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetCanWatchEnemy");

	UScriptHelperClient_SetCanWatchEnemy_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bCan = bCan;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetBtnClickInCdFunc
// ()

void UScriptHelperClient::SetBtnClickInCdFunc()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetBtnClickInCdFunc");

	UScriptHelperClient_SetBtnClickInCdFunc_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SetAccountRegion
// ()
// Parameters:
// struct FString                 Region                         (Parm, ZeroConstructor)

void UScriptHelperClient::SetAccountRegion(const struct FString& Region)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SetAccountRegion");

	UScriptHelperClient_SetAccountRegion_Params params;
	params.Region = Region;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SendRetriveBeginnerFinisheGuideReq
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SendRetriveBeginnerFinisheGuideReq(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SendRetriveBeginnerFinisheGuideReq");

	UScriptHelperClient_SendRetriveBeginnerFinisheGuideReq_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SendRecordFinishedGuideReq
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 TipsID                         (Parm, ZeroConstructor)

void UScriptHelperClient::SendRecordFinishedGuideReq(class UGameFrontendHUD* GameFrontendHUD, const struct FString& TipsID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SendRecordFinishedGuideReq");

	UScriptHelperClient_SendRecordFinishedGuideReq_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.TipsID = TipsID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SendPlayEmote
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            EmoteIndex                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SendPlayEmote(class UGameFrontendHUD* GameFrontendHUD, int EmoteIndex)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SendPlayEmote");

	UScriptHelperClient_SendPlayEmote_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.EmoteIndex = EmoteIndex;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SendLobbyChat
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 gid                            (Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UScriptHelperClient::SendLobbyChat(class UGameFrontendHUD* GameFrontendHUD, const struct FString& gid, const struct FString& Content)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SendLobbyChat");

	UScriptHelperClient_SendLobbyChat_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.gid = gid;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SendDirtyToFilter
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 dirtyString                    (Parm, ZeroConstructor)
// struct FString                 prefixString                   (Parm, ZeroConstructor)
// int                            UId                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SendDirtyToFilter(class UGameFrontendHUD* GameFrontendHUD, const struct FString& dirtyString, const struct FString& prefixString, int UId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SendDirtyToFilter");

	UScriptHelperClient_SendDirtyToFilter_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.dirtyString = dirtyString;
	params.prefixString = prefixString;
	params.UId = UId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SendClientLog
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 errorReason                    (Parm, ZeroConstructor)
// struct FString                 errorDescription               (Parm, ZeroConstructor)
// bool                           pullAll                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SendClientLog(class UGameFrontendHUD* GameFrontendHUD, const struct FString& errorReason, const struct FString& errorDescription, bool pullAll)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SendClientLog");

	UScriptHelperClient_SendClientLog_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.errorReason = errorReason;
	params.errorDescription = errorDescription;
	params.pullAll = pullAll;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ScheduleLocalNotificationAtTime
// ()
// Parameters:
// int                            Year                           (Parm, ZeroConstructor, IsPlainOldData)
// int                            Month                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            Day                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            Hour                           (Parm, ZeroConstructor, IsPlainOldData)
// int                            Minute                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            Second                         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           LocalTime                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Title                          (Parm, ZeroConstructor)
// struct FString                 Body                           (Parm, ZeroConstructor)
// struct FString                 Action                         (Parm, ZeroConstructor)
// int                            NotificationID                 (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ScheduleLocalNotificationAtTime(int Year, int Month, int Day, int Hour, int Minute, int Second, bool LocalTime, const struct FString& Title, const struct FString& Body, const struct FString& Action, int NotificationID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ScheduleLocalNotificationAtTime");

	UScriptHelperClient_ScheduleLocalNotificationAtTime_Params params;
	params.Year = Year;
	params.Month = Month;
	params.Day = Day;
	params.Hour = Hour;
	params.Minute = Minute;
	params.Second = Second;
	params.LocalTime = LocalTime;
	params.Title = Title;
	params.Body = Body;
	params.Action = Action;
	params.NotificationID = NotificationID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SaveStringToIntermediateFile
// ()
// Parameters:
// struct FString                 String                         (Parm, ZeroConstructor)
// struct FString                 Filename                       (Parm, ZeroConstructor)

void UScriptHelperClient::SaveStringToIntermediateFile(const struct FString& String, const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SaveStringToIntermediateFile");

	UScriptHelperClient_SaveStringToIntermediateFile_Params params;
	params.String = String;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SaveStringToFile
// ()
// Parameters:
// struct FString                 String                         (Parm, ZeroConstructor)
// struct FString                 Filename                       (Parm, ZeroConstructor)

void UScriptHelperClient::SaveStringToFile(const struct FString& String, const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SaveStringToFile");

	UScriptHelperClient_SaveStringToFile_Params params;
	params.String = String;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SaveSavFile
// ()
// Parameters:
// struct FString                 CompressedData                 (Parm, ZeroConstructor)
// struct FString                 Filename                       (Parm, ZeroConstructor)
// int                            CompressedSize                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            UnCompressedSize               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::SaveSavFile(const struct FString& CompressedData, const struct FString& Filename, int CompressedSize, int UnCompressedSize)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SaveSavFile");

	UScriptHelperClient_SaveSavFile_Params params;
	params.CompressedData = CompressedData;
	params.Filename = Filename;
	params.CompressedSize = CompressedSize;
	params.UnCompressedSize = UnCompressedSize;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.SaveLuaMemoryFile
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// struct FString                 InputContent                   (Parm, ZeroConstructor)
// bool                           RmExistFile                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::SaveLuaMemoryFile(const struct FString& Filename, const struct FString& InputContent, bool RmExistFile)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SaveLuaMemoryFile");

	UScriptHelperClient_SaveLuaMemoryFile_Params params;
	params.Filename = Filename;
	params.InputContent = InputContent;
	params.RmExistFile = RmExistFile;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.SaveArrayToFile
// ()
// Parameters:
// TArray<unsigned char>          Content                        (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::SaveArrayToFile(TArray<unsigned char> Content, const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.SaveArrayToFile");

	UScriptHelperClient_SaveArrayToFile_Params params;
	params.Content = Content;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.RunConsoleCommondAndGetString
// ()
// Parameters:
// struct FString                 commond                        (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::RunConsoleCommondAndGetString(const struct FString& commond)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.RunConsoleCommondAndGetString");

	UScriptHelperClient_RunConsoleCommondAndGetString_Params params;
	params.commond = commond;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.RunConsoleCommond
// ()
// Parameters:
// struct FString                 commond                        (Parm, ZeroConstructor)

void UScriptHelperClient::RunConsoleCommond(const struct FString& commond)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.RunConsoleCommond");

	UScriptHelperClient_RunConsoleCommond_Params params;
	params.commond = commond;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.RoomOwnerInterruptGame
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::RoomOwnerInterruptGame(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.RoomOwnerInterruptGame");

	UScriptHelperClient_RoomOwnerInterruptGame_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReturnToLobby
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ReturnToLobby(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReturnToLobby");

	UScriptHelperClient_ReturnToLobby_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.RequestFile
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// bool                           ForceUpdate                    (Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint64_t UScriptHelperClient::RequestFile(class UGameFrontendHUD* GameFrontendHUD, const struct FString& FilePath, bool ForceUpdate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.RequestFile");

	UScriptHelperClient_RequestFile_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.FilePath = FilePath;
	params.ForceUpdate = ForceUpdate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ReportFirebaseEventWithString
// ()
// Parameters:
// struct FString                 eventTypeString                (Parm, ZeroConstructor)
// struct FString                 bundleExtraKey                 (Parm, ZeroConstructor)
// struct FString                 bundleExtraValue               (Parm, ZeroConstructor)
// bool                           isUnique                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ReportFirebaseEventWithString(const struct FString& eventTypeString, const struct FString& bundleExtraKey, const struct FString& bundleExtraValue, bool isUnique)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportFirebaseEventWithString");

	UScriptHelperClient_ReportFirebaseEventWithString_Params params;
	params.eventTypeString = eventTypeString;
	params.bundleExtraKey = bundleExtraKey;
	params.bundleExtraValue = bundleExtraValue;
	params.isUnique = isUnique;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReportFirebaseEventWithParam
// ()
// Parameters:
// struct FString                 eventTypeString                (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> _params                        (Parm, ZeroConstructor)
// bool                           isUnique                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ReportFirebaseEventWithParam(const struct FString& eventTypeString, TMap<struct FString, struct FString> _params, bool isUnique)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportFirebaseEventWithParam");

	UScriptHelperClient_ReportFirebaseEventWithParam_Params params;
	params.eventTypeString = eventTypeString;
	params._params = _params;
	params.isUnique = isUnique;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReportEventRegisterCompleted
// ()

void UScriptHelperClient::ReportEventRegisterCompleted()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportEventRegisterCompleted");

	UScriptHelperClient_ReportEventRegisterCompleted_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReportEventPurchaseConsider
// ()

void UScriptHelperClient::ReportEventPurchaseConsider()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportEventPurchaseConsider");

	UScriptHelperClient_ReportEventPurchaseConsider_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReportEventLoadingCompleted
// ()

void UScriptHelperClient::ReportEventLoadingCompleted()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportEventLoadingCompleted");

	UScriptHelperClient_ReportEventLoadingCompleted_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReportContextValuesOnCrash
// ()
// Parameters:
// struct FString                 Json                           (Parm, OutParm, ZeroConstructor)

void UScriptHelperClient::ReportContextValuesOnCrash(struct FString* Json)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportContextValuesOnCrash");

	UScriptHelperClient_ReportContextValuesOnCrash_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Json != nullptr)
		*Json = params.Json;
}


// Function Client.ScriptHelperClient.ReportBuglyLogWithFDNum
// ()
// Parameters:
// struct FString                 baseLogInfo                    (Parm, ZeroConstructor)

void UScriptHelperClient::ReportBuglyLogWithFDNum(const struct FString& baseLogInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportBuglyLogWithFDNum");

	UScriptHelperClient_ReportBuglyLogWithFDNum_Params params;
	params.baseLogInfo = baseLogInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReportBattleChat
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Msg                            (Parm, ZeroConstructor)
// int                            msgExtraParam                  (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ReportBattleChat(class UGameFrontendHUD* GameFrontendHUD, const struct FString& Msg, int msgExtraParam)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReportBattleChat");

	UScriptHelperClient_ReportBattleChat_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Msg = Msg;
	params.msgExtraParam = msgExtraParam;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ReplyInvite
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 gid                            (Parm, ZeroConstructor)
// bool                           bReply                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ReplyInvite(class UGameFrontendHUD* GameFrontendHUD, const struct FString& gid, bool bReply)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReplyInvite");

	UScriptHelperClient_ReplyInvite_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.gid = gid;
	params.bReply = bReply;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.RemoveKnownMissingPackage
// ()
// Parameters:
// struct FString                 PackageName                    (Parm, ZeroConstructor)

void UScriptHelperClient::RemoveKnownMissingPackage(const struct FString& PackageName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.RemoveKnownMissingPackage");

	UScriptHelperClient_RemoveKnownMissingPackage_Params params;
	params.PackageName = PackageName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.RemountPakFiles
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::RemountPakFiles(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.RemountPakFiles");

	UScriptHelperClient_RemountPakFiles_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ReInitializePuffer
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           needCheck                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            maxDownloadsPerTask            (Parm, ZeroConstructor, IsPlainOldData)
// int                            maxDownTask                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            maxDownloadSpeed               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           useOldInterface                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           removeOldWhenUpdate            (Parm, ZeroConstructor, IsPlainOldData)
// int                            versionType                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ReInitializePuffer(class UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ReInitializePuffer");

	UScriptHelperClient_ReInitializePuffer_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.needCheck = needCheck;
	params.maxDownloadsPerTask = maxDownloadsPerTask;
	params.maxDownTask = maxDownTask;
	params.maxDownloadSpeed = maxDownloadSpeed;
	params.useOldInterface = useOldInterface;
	params.removeOldWhenUpdate = removeOldWhenUpdate;
	params.versionType = versionType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.RecordLuaExceptionInfo
// ()
// Parameters:
// struct FString                 exception                      (Parm, ZeroConstructor)

void UScriptHelperClient::RecordLuaExceptionInfo(const struct FString& exception)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.RecordLuaExceptionInfo");

	UScriptHelperClient_RecordLuaExceptionInfo_Params params;
	params.exception = exception;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.QuitVoiceRoom
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::QuitVoiceRoom(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QuitVoiceRoom");

	UScriptHelperClient_QuitVoiceRoom_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.QuitLbsVoiceRoom
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::QuitLbsVoiceRoom(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QuitLbsVoiceRoom");

	UScriptHelperClient_QuitLbsVoiceRoom_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.QuitFightChat
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::QuitFightChat(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QuitFightChat");

	UScriptHelperClient_QuitFightChat_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.QuickLogin
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            refreshTokenBeforeExpDays      (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::QuickLogin(int refreshTokenBeforeExpDays, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QuickLogin");

	UScriptHelperClient_QuickLogin_Params params;
	params.refreshTokenBeforeExpDays = refreshTokenBeforeExpDays;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.QQShareToFriend
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            act                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 OpenID                         (Parm, ZeroConstructor)
// struct FString                 Title                          (Parm, ZeroConstructor)
// struct FString                 Desc                           (Parm, ZeroConstructor)
// struct FString                 targetUrl                      (Parm, ZeroConstructor)
// struct FString                 imgUrl                         (Parm, ZeroConstructor)
// struct FString                 previewText                    (Parm, ZeroConstructor)
// struct FString                 gameTag                        (Parm, ZeroConstructor)
// struct FString                 msdkExtInfo                    (Parm, ZeroConstructor)

void UScriptHelperClient::QQShareToFriend(const struct FString& targetUrl, int act, const struct FString& OpenID, const struct FString& Title, const struct FString& Desc, const struct FString& msdkExtInfo, const struct FString& imgUrl, const struct FString& previewText, const struct FString& gameTag, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QQShareToFriend");

	UScriptHelperClient_QQShareToFriend_Params params;
	params.act = act;
	params.OpenID = OpenID;
	params.Title = Title;
	params.Desc = Desc;
	params.targetUrl = targetUrl;
	params.imgUrl = imgUrl;
	params.previewText = previewText;
	params.gameTag = gameTag;
	params.msdkExtInfo = msdkExtInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.QQShareH5WithPhoto
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 _title                         (Parm, ZeroConstructor)
// struct FString                 _fullURL                       (Parm, ZeroConstructor)
// int                            Channel                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::QQShareH5WithPhoto(const struct FString& _title, const struct FString& _fullURL, int Channel, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QQShareH5WithPhoto");

	UScriptHelperClient_QQShareH5WithPhoto_Params params;
	params._title = _title;
	params._fullURL = _fullURL;
	params.Channel = Channel;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.QQShare
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 _descShare                     (Parm, ZeroConstructor)
// struct FString                 _titleShare                    (Parm, ZeroConstructor)
// struct FString                 _imgPath                       (Parm, ZeroConstructor)
// struct FString                 _imgUrl                        (Parm, ZeroConstructor)
// struct FString                 _url                           (Parm, ZeroConstructor)
// int                            _shareScene                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::QQShare(const struct FString& _imgPath, const struct FString& _descShare, const struct FString& _titleShare, int _shareScene, const struct FString& _imgUrl, const struct FString& _url, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QQShare");

	UScriptHelperClient_QQShare_Params params;
	params._descShare = _descShare;
	params._titleShare = _titleShare;
	params._imgPath = _imgPath;
	params._imgUrl = _imgUrl;
	params._url = _url;
	params._shareScene = _shareScene;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.QQAddFriend
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 OpenID                         (Parm, ZeroConstructor)
// struct FString                 Desc                           (Parm, ZeroConstructor)
// struct FString                 Message                        (Parm, ZeroConstructor)

void UScriptHelperClient::QQAddFriend(const struct FString& OpenID, const struct FString& Desc, const struct FString& Message, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.QQAddFriend");

	UScriptHelperClient_QQAddFriend_Params params;
	params.OpenID = OpenID;
	params.Desc = Desc;
	params.Message = Message;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.PVEAutoTestGetEnermyLocation
// ()
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector UScriptHelperClient::PVEAutoTestGetEnermyLocation()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PVEAutoTestGetEnermyLocation");

	UScriptHelperClient_PVEAutoTestGetEnermyLocation_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.PubgmSimulateActionClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            SimulateType                   (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::PubgmSimulateActionClientEx(class UGameFrontendHUD* GameFrontendHUD, int SimulateType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PubgmSimulateActionClientEx");

	UScriptHelperClient_PubgmSimulateActionClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.SimulateType = SimulateType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ProjectSavedDir
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ProjectSavedDir()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ProjectSavedDir");

	UScriptHelperClient_ProjectSavedDir_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ProjectContentDir
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ProjectContentDir()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ProjectContentDir");

	UScriptHelperClient_ProjectContentDir_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ProcessSoPatch
// ()
// Parameters:
// struct FString                 InAppVerStr                    (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::ProcessSoPatch(const struct FString& InAppVerStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ProcessSoPatch");

	UScriptHelperClient_ProcessSoPatch_Params params;
	params.InAppVerStr = InAppVerStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ProcessServerRelationChainError
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 ErrorMsg                       (Parm, ZeroConstructor)
// int                            iForceLoginInterval            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ProcessServerRelationChainError(const struct FString& ErrorMsg, int iForceLoginInterval, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ProcessServerRelationChainError");

	UScriptHelperClient_ProcessServerRelationChainError_Params params;
	params.ErrorMsg = ErrorMsg;
	params.iForceLoginInterval = iForceLoginInterval;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.PostGameStatusToTGPASMap
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Key                            (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> mapData                        (Parm, ZeroConstructor)

void UScriptHelperClient::PostGameStatusToTGPASMap(class UGameFrontendHUD* GameFrontendHUD, const struct FString& Key, TMap<struct FString, struct FString> mapData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PostGameStatusToTGPASMap");

	UScriptHelperClient_PostGameStatusToTGPASMap_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Key = Key;
	params.mapData = mapData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.PlayHapticsFile
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// int                            Duration                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         Callback                       (Parm, ZeroConstructor)

void UScriptHelperClient::PlayHapticsFile(const struct FString& FilePath, int Duration, const struct FScriptDelegate& Callback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PlayHapticsFile");

	UScriptHelperClient_PlayHapticsFile_Params params;
	params.FilePath = FilePath;
	params.Duration = Duration;
	params.Callback = Callback;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.PandoraSendCmd
// ()
// Parameters:
// struct FString                 jsonStr                        (Parm, ZeroConstructor)

void UScriptHelperClient::PandoraSendCmd(const struct FString& jsonStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PandoraSendCmd");

	UScriptHelperClient_PandoraSendCmd_Params params;
	params.jsonStr = jsonStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.PandoraInit
// ()
// Parameters:
// struct FString                 InOpenId                       (Parm, ZeroConstructor)
// struct FString                 InRoleId                       (Parm, ZeroConstructor)
// struct FString                 InAppId                        (Parm, ZeroConstructor)
// struct FString                 InPlatId                       (Parm, ZeroConstructor)
// struct FString                 InAccType                      (Parm, ZeroConstructor)
// struct FString                 InArea                         (Parm, ZeroConstructor)
// struct FString                 InPartion                      (Parm, ZeroConstructor)
// struct FString                 InCloudTest                    (Parm, ZeroConstructor)
// struct FString                 InAccessToken                  (Parm, ZeroConstructor)
// struct FString                 InSdkVersion                   (Parm, ZeroConstructor)
// struct FString                 InGameVersion                  (Parm, ZeroConstructor)
// struct FString                 InRoleName                     (Parm, ZeroConstructor)
// struct FString                 InPayToken                     (Parm, ZeroConstructor)
// struct FString                 InHeadUrl                      (Parm, ZeroConstructor)
// struct FString                 InChanelId                     (Parm, ZeroConstructor)
// struct FString                 InBelongingId                  (Parm, ZeroConstructor)
// struct FString                 InLanguage                     (Parm, ZeroConstructor)
// struct FString                 InTicket                       (Parm, ZeroConstructor)
// struct FString                 InIp                           (Parm, ZeroConstructor)
// struct FString                 InNation                       (Parm, ZeroConstructor)
// struct FString                 InNetType                      (Parm, ZeroConstructor)

void UScriptHelperClient::PandoraInit(const struct FString& InOpenId, const struct FString& InRoleId, const struct FString& InAppId, const struct FString& InPlatId, const struct FString& InAccType, const struct FString& InArea, const struct FString& InPartion, const struct FString& InCloudTest, const struct FString& InAccessToken, const struct FString& InSdkVersion, const struct FString& InGameVersion, const struct FString& InRoleName, const struct FString& InPayToken, const struct FString& InHeadUrl, const struct FString& InChanelId, const struct FString& InBelongingId, const struct FString& InLanguage, const struct FString& InTicket, const struct FString& InIp, const struct FString& InNation, const struct FString& InNetType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PandoraInit");

	UScriptHelperClient_PandoraInit_Params params;
	params.InOpenId = InOpenId;
	params.InRoleId = InRoleId;
	params.InAppId = InAppId;
	params.InPlatId = InPlatId;
	params.InAccType = InAccType;
	params.InArea = InArea;
	params.InPartion = InPartion;
	params.InCloudTest = InCloudTest;
	params.InAccessToken = InAccessToken;
	params.InSdkVersion = InSdkVersion;
	params.InGameVersion = InGameVersion;
	params.InRoleName = InRoleName;
	params.InPayToken = InPayToken;
	params.InHeadUrl = InHeadUrl;
	params.InChanelId = InChanelId;
	params.InBelongingId = InBelongingId;
	params.InLanguage = InLanguage;
	params.InTicket = InTicket;
	params.InIp = InIp;
	params.InNation = InNation;
	params.InNetType = InNetType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.PandoraErrorReport
// ()
// Parameters:
// int                            iType                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            iActId                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            errCode                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 errMsg                         (Parm, ZeroConstructor)
// struct FString                 extraMsg                       (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> extendDict                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UScriptHelperClient::PandoraErrorReport(int iType, int iActId, int errCode, const struct FString& errMsg, const struct FString& extraMsg, TMap<struct FString, struct FString> extendDict)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PandoraErrorReport");

	UScriptHelperClient_PandoraErrorReport_Params params;
	params.iType = iType;
	params.iActId = iActId;
	params.errCode = errCode;
	params.errMsg = errMsg;
	params.extraMsg = extraMsg;
	params.extendDict = extendDict;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.PandoraEnable
// ()
// Parameters:
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::PandoraEnable(bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PandoraEnable");

	UScriptHelperClient_PandoraEnable_Params params;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.PandoraClose
// ()

void UScriptHelperClient::PandoraClose()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.PandoraClose");

	UScriptHelperClient_PandoraClose_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OpenWebviewInGameProcess
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// int                            Left                           (Parm, ZeroConstructor, IsPlainOldData)
// int                            Top                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            Right                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            Bottom                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OpenWebviewInGameProcess(const struct FString& URL, int Left, int Top, int Right, int Bottom)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OpenWebviewInGameProcess");

	UScriptHelperClient_OpenWebviewInGameProcess_Params params;
	params.URL = URL;
	params.Left = Left;
	params.Top = Top;
	params.Right = Right;
	params.Bottom = Bottom;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OpenURLWithExtra
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> ExtraMap                       (Parm, ZeroConstructor)

void UScriptHelperClient::OpenURLWithExtra(const struct FString& URL, TMap<struct FString, struct FString> ExtraMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OpenURLWithExtra");

	UScriptHelperClient_OpenURLWithExtra_Params params;
	params.URL = URL;
	params.ExtraMap = ExtraMap;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OpenURL
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// bool                           isGetTicket                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           withNeverAdjust                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bKeepCache                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OpenURL(const struct FString& URL, bool isGetTicket, bool withNeverAdjust, bool bKeepCache)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OpenURL");

	UScriptHelperClient_OpenURL_Params params;
	params.URL = URL;
	params.isGetTicket = isGetTicket;
	params.withNeverAdjust = withNeverAdjust;
	params.bKeepCache = bKeepCache;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OpenShaderCodeLibrary
// ()
// Parameters:
// struct FString                 Path                           (Parm, ZeroConstructor)
// struct FString                 VersionNum                     (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::OpenShaderCodeLibrary(const struct FString& Path, const struct FString& VersionNum)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OpenShaderCodeLibrary");

	UScriptHelperClient_OpenShaderCodeLibrary_Params params;
	params.Path = Path;
	params.VersionNum = VersionNum;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.OpenH5FromCache
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ModuleName                     (Parm, ZeroConstructor)
// struct FString                 Language                       (Parm, ZeroConstructor)
// int                            netType                        (Parm, ZeroConstructor, IsPlainOldData)
// int                            Top                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            Left                           (Parm, ZeroConstructor, IsPlainOldData)
// int                            Right                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ViewParam                      (Parm, ZeroConstructor)

void UScriptHelperClient::OpenH5FromCache(class UGameFrontendHUD* GameFrontendHUD, const struct FString& ModuleName, const struct FString& Language, int netType, int Top, int Left, int Right, const struct FString& ViewParam)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OpenH5FromCache");

	UScriptHelperClient_OpenH5FromCache_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ModuleName = ModuleName;
	params.Language = Language;
	params.netType = netType;
	params.Top = Top;
	params.Left = Left;
	params.Right = Right;
	params.ViewParam = ViewParam;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnNotifyFightFriendChat
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FFightFriendChat        Data                           (ConstParm, Parm, OutParm, ReferenceParm)

void UScriptHelperClient::OnNotifyFightFriendChat(class UGameFrontendHUD* GameFrontendHUD, const struct FFightFriendChat& Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnNotifyFightFriendChat");

	UScriptHelperClient_OnNotifyFightFriendChat_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnMiniGameEnded
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            Score                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            Duration                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bGameClosed                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OnMiniGameEnded(class UGameFrontendHUD* GameFrontendHUD, int Score, int Duration, bool bGameClosed)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnMiniGameEnded");

	UScriptHelperClient_OnMiniGameEnded_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Score = Score;
	params.Duration = Duration;
	params.bGameClosed = bGameClosed;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnIslandPlayerInfoNotify
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            LandId                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OnIslandPlayerInfoNotify(class UGameFrontendHUD* GameFrontendHUD, int LandId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnIslandPlayerInfoNotify");

	UScriptHelperClient_OnIslandPlayerInfoNotify_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.LandId = LandId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnInviteNextBattle
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 gid                            (Parm, ZeroConstructor)
// struct FString                 Name                           (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::OnInviteNextBattle(class UGameFrontendHUD* GameFrontendHUD, const struct FString& gid, const struct FString& Name)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnInviteNextBattle");

	UScriptHelperClient_OnInviteNextBattle_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.gid = gid;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.OnGetUpdateStateCDNConfigUrl
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 URL                            (Parm, ZeroConstructor)

void UScriptHelperClient::OnGetUpdateStateCDNConfigUrl(class UGameFrontendHUD* GameFrontendHUD, const struct FString& URL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnGetUpdateStateCDNConfigUrl");

	UScriptHelperClient_OnGetUpdateStateCDNConfigUrl_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.URL = URL;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ScriptHelperClient.OnGetItemBigIcon__DelegateSignature
// ()
// Parameters:
// struct FString                 strPath                        (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::OnGetItemBigIcon__DelegateSignature(const struct FString& strPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ScriptHelperClient.OnGetItemBigIcon__DelegateSignature");

	UScriptHelperClient_OnGetItemBigIcon__DelegateSignature_Params params;
	params.strPath = strPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.OnFilterFinish
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 filterText                     (Parm, ZeroConstructor)

void UScriptHelperClient::OnFilterFinish(class UGameFrontendHUD* GameFrontendHUD, const struct FString& filterText)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnFilterFinish");

	UScriptHelperClient_OnFilterFinish_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.filterText = filterText;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnEnterLobbyReloadLocalizationResource
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OnEnterLobbyReloadLocalizationResource(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnEnterLobbyReloadLocalizationResource");

	UScriptHelperClient_OnEnterLobbyReloadLocalizationResource_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnEnterGameReleaseLocalizationResource
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OnEnterGameReleaseLocalizationResource(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnEnterGameReleaseLocalizationResource");

	UScriptHelperClient_OnEnterGameReleaseLocalizationResource_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnDolphinAppUpdateFinished
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OnDolphinAppUpdateFinished(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnDolphinAppUpdateFinished");

	UScriptHelperClient_OnDolphinAppUpdateFinished_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnCombatHitFeedback
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bCombatHitFeedbackEnable       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::OnCombatHitFeedback(class UGameFrontendHUD* GameFrontendHUD, bool bCombatHitFeedbackEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnCombatHitFeedback");

	UScriptHelperClient_OnCombatHitFeedback_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bCombatHitFeedbackEnable = bCombatHitFeedbackEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnBattleResultCallBack
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FBattleResultData       BattleResultData               (Parm)

void UScriptHelperClient::OnBattleResultCallBack(class UGameFrontendHUD* GameFrontendHUD, const struct FBattleResultData& BattleResultData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnBattleResultCallBack");

	UScriptHelperClient_OnBattleResultCallBack_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.BattleResultData = BattleResultData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.OnBattleResult
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FBattleResultData       BattleResultData               (Parm)

void UScriptHelperClient::OnBattleResult(class UGameFrontendHUD* GameFrontendHUD, const struct FBattleResultData& BattleResultData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.OnBattleResult");

	UScriptHelperClient_OnBattleResult_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.BattleResultData = BattleResultData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ObjectPoolServerSwitch
// ()
// Parameters:
// bool                           bSwitchOn                      (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ObjectPoolServerSwitch(bool bSwitchOn)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ObjectPoolServerSwitch");

	UScriptHelperClient_ObjectPoolServerSwitch_Params params;
	params.bSwitchOn = bSwitchOn;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.NotifyBeginnerFinishedGuideUpdated
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GuideSwitch                    (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FPlayerFinishedGuide> finished_guide                 (ConstParm, Parm, ZeroConstructor)
// int                            player_level                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            player_exp_type                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::NotifyBeginnerFinishedGuideUpdated(class UGameFrontendHUD* GameFrontendHUD, bool GuideSwitch, TArray<struct FPlayerFinishedGuide> finished_guide, int player_level, int player_exp_type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.NotifyBeginnerFinishedGuideUpdated");

	UScriptHelperClient_NotifyBeginnerFinishedGuideUpdated_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.GuideSwitch = GuideSwitch;
	params.finished_guide = finished_guide;
	params.player_level = player_level;
	params.player_exp_type = player_exp_type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MSDKWebViewCallJS
// ()
// Parameters:
// struct FString                 strJS                          (Parm, ZeroConstructor)

void UScriptHelperClient::MSDKWebViewCallJS(const struct FString& strJS)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MSDKWebViewCallJS");

	UScriptHelperClient_MSDKWebViewCallJS_Params params;
	params.strJS = strJS;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MoveFollowTarget
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            FollowType                     (Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       UId                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::MoveFollowTarget(class UGameFrontendHUD* GameFrontendHUD, int FollowType, uint64_t UId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MoveFollowTarget");

	UScriptHelperClient_MoveFollowTarget_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.FollowType = FollowType;
	params.UId = UId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MoveFile
// ()
// Parameters:
// struct FString                 SrcFullPath                    (Parm, ZeroConstructor)
// struct FString                 DesFullPath                    (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::MoveFile(const struct FString& SrcFullPath, const struct FString& DesFullPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MoveFile");

	UScriptHelperClient_MoveFile_Params params;
	params.SrcFullPath = SrcFullPath;
	params.DesFullPath = DesFullPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.MountPakFile
// ()
// Parameters:
// struct FString                 InPakFilename                  (Parm, ZeroConstructor)
// struct FString                 Key                            (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::MountPakFile(const struct FString& InPakFilename, const struct FString& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MountPakFile");

	UScriptHelperClient_MountPakFile_Params params;
	params.InPakFilename = InPakFilename;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.MidasSDKInit_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::MidasSDKInit_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MidasSDKInit_LuaState");

	UScriptHelperClient_MidasSDKInit_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.MidasReprovide_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::MidasReprovide_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MidasReprovide_LuaState");

	UScriptHelperClient_MidasReprovide_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.MidasPay
// ()
// Parameters:
// struct FString                 productid                      (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)

void UScriptHelperClient::MidasPay(const struct FString& productid, int payItem, const struct FString& country, const struct FString& currency)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MidasPay");

	UScriptHelperClient_MidasPay_Params params;
	params.productid = productid;
	params.payItem = payItem;
	params.country = country;
	params.currency = currency;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MidasH5Pay
// ()
// Parameters:
// struct FString                 country                        (Parm, ZeroConstructor)

void UScriptHelperClient::MidasH5Pay(const struct FString& country)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MidasH5Pay");

	UScriptHelperClient_MidasH5Pay_Params params;
	params.country = country;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MidasGoodsPresent
// ()
// Parameters:
// struct FString                 productid                      (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 price                          (Parm, ZeroConstructor)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)
// struct FString                 MetaData                       (Parm, ZeroConstructor)

void UScriptHelperClient::MidasGoodsPresent(const struct FString& productid, int payItem, const struct FString& price, const struct FString& country, const struct FString& currency, const struct FString& MetaData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MidasGoodsPresent");

	UScriptHelperClient_MidasGoodsPresent_Params params;
	params.productid = productid;
	params.payItem = payItem;
	params.price = price;
	params.country = country;
	params.currency = currency;
	params.MetaData = MetaData;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MidasGoods
// ()
// Parameters:
// struct FString                 productid                      (Parm, ZeroConstructor)
// int                            payItem                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 price                          (Parm, ZeroConstructor)
// struct FString                 country                        (Parm, ZeroConstructor)
// struct FString                 currency                       (Parm, ZeroConstructor)

void UScriptHelperClient::MidasGoods(const struct FString& productid, int payItem, const struct FString& price, const struct FString& country, const struct FString& currency)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MidasGoods");

	UScriptHelperClient_MidasGoods_Params params;
	params.productid = productid;
	params.payItem = payItem;
	params.price = price;
	params.country = country;
	params.currency = currency;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MessageBoxExt
// ()
// Parameters:
// struct FString                 Caption                        (Parm, ZeroConstructor)
// struct FString                 Text                           (Parm, ZeroConstructor)

void UScriptHelperClient::MessageBoxExt(const struct FString& Caption, const struct FString& Text)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MessageBoxExt");

	UScriptHelperClient_MessageBoxExt_Params params;
	params.Caption = Caption;
	params.Text = Text;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.MediaCopyFromPakToLocal
// ()
// Parameters:
// struct FString                 from                           (Parm, ZeroConstructor)
// bool                           bForce                         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::MediaCopyFromPakToLocal(const struct FString& from, bool bForce)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MediaCopyFromPakToLocal");

	UScriptHelperClient_MediaCopyFromPakToLocal_Params params;
	params.from = from;
	params.bForce = bForce;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.MD5LuaString_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::MD5LuaString_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MD5LuaString_LuaState");

	UScriptHelperClient_MD5LuaString_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.MD5HashAnsiString
// ()
// Parameters:
// struct FString                 str                            (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::MD5HashAnsiString(const struct FString& str)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.MD5HashAnsiString");

	UScriptHelperClient_MD5HashAnsiString_Params params;
	params.str = str;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ManualSleep
// ()
// Parameters:
// float                          Seconds                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ManualSleep(float Seconds)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ManualSleep");

	UScriptHelperClient_ManualSleep_Params params;
	params.Seconds = Seconds;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LogoutAllDevices
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::LogoutAllDevices(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LogoutAllDevices");

	UScriptHelperClient_LogoutAllDevices_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.Logout
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::Logout(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Logout");

	UScriptHelperClient_Logout_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.LoginWithExtraInfo
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Channel                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 InExtraJson                    (Parm, ZeroConstructor)

void UScriptHelperClient::LoginWithExtraInfo(uint32_t Channel, const struct FString& InExtraJson, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoginWithExtraInfo");

	UScriptHelperClient_LoginWithExtraInfo_Params params;
	params.Channel = Channel;
	params.InExtraJson = InExtraJson;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.Login
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Channel                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::Login(uint32_t Channel, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Login");

	UScriptHelperClient_Login_Params params;
	params.Channel = Channel;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.LobbySetUserRegion
// ()
// Parameters:
// int                            InRegion                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::LobbySetUserRegion(int InRegion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LobbySetUserRegion");

	UScriptHelperClient_LobbySetUserRegion_Params params;
	params.InRegion = InRegion;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LobbySetProxyPortlist
// ()
// Parameters:
// struct FString                 InNodePortList                 (Parm, ZeroConstructor)

void UScriptHelperClient::LobbySetProxyPortlist(const struct FString& InNodePortList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LobbySetProxyPortlist");

	UScriptHelperClient_LobbySetProxyPortlist_Params params;
	params.InNodePortList = InNodePortList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LobbySetProxyNodelist
// ()
// Parameters:
// struct FString                 InNodeIpList                   (Parm, ZeroConstructor)

void UScriptHelperClient::LobbySetProxyNodelist(const struct FString& InNodeIpList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LobbySetProxyNodelist");

	UScriptHelperClient_LobbySetProxyNodelist_Params params;
	params.InNodeIpList = InNodeIpList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LobbySetEchoPortlist
// ()
// Parameters:
// struct FString                 InEchoPortList                 (Parm, ZeroConstructor)

void UScriptHelperClient::LobbySetEchoPortlist(const struct FString& InEchoPortList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LobbySetEchoPortlist");

	UScriptHelperClient_LobbySetEchoPortlist_Params params;
	params.InEchoPortList = InEchoPortList;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LobbyIsLinkProxy
// ()
// Parameters:
// struct FString                 InIp                           (Parm, ZeroConstructor)
// int                            InPort                         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::LobbyIsLinkProxy(const struct FString& InIp, int InPort)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LobbyIsLinkProxy");

	UScriptHelperClient_LobbyIsLinkProxy_Params params;
	params.InIp = InIp;
	params.InPort = InPort;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LobbyAddAddress
// ()
// Parameters:
// struct FString                 InProtocol                     (Parm, ZeroConstructor)
// struct FString                 InIp                           (Parm, ZeroConstructor)
// int                            InPort                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::LobbyAddAddress(const struct FString& InProtocol, const struct FString& InIp, int InPort)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LobbyAddAddress");

	UScriptHelperClient_LobbyAddAddress_Params params;
	params.InProtocol = InProtocol;
	params.InIp = InIp;
	params.InPort = InPort;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LoadSavFile_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::LoadSavFile_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadSavFile_LuaState");

	UScriptHelperClient_LoadSavFile_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadMidasProductInfo_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::LoadMidasProductInfo_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadMidasProductInfo_LuaState");

	UScriptHelperClient_LoadMidasProductInfo_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadMidasMP_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::LoadMidasMP_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadMidasMP_LuaState");

	UScriptHelperClient_LoadMidasMP_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadMidasIntroPrice_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::LoadMidasIntroPrice_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadMidasIntroPrice_LuaState");

	UScriptHelperClient_LoadMidasIntroPrice_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadIntermediateFileToString
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::LoadIntermediateFileToString(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadIntermediateFileToString");

	UScriptHelperClient_LoadIntermediateFileToString_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadH5FromCache
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ModuleName                     (Parm, ZeroConstructor)
// struct FString                 Language                       (Parm, ZeroConstructor)
// int                            netType                        (Parm, ZeroConstructor, IsPlainOldData)
// int                            Top                            (Parm, ZeroConstructor, IsPlainOldData)
// int                            Left                           (Parm, ZeroConstructor, IsPlainOldData)
// int                            Right                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ViewParam                      (Parm, ZeroConstructor)

void UScriptHelperClient::LoadH5FromCache(class UGameFrontendHUD* GameFrontendHUD, const struct FString& ModuleName, const struct FString& Language, int netType, int Top, int Left, int Right, const struct FString& ViewParam)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadH5FromCache");

	UScriptHelperClient_LoadH5FromCache_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ModuleName = ModuleName;
	params.Language = Language;
	params.netType = netType;
	params.Top = Top;
	params.Left = Left;
	params.Right = Right;
	params.ViewParam = ViewParam;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LoadFileToStringByFullPath
// ()
// Parameters:
// struct FString                 FullPathName                   (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::LoadFileToStringByFullPath(const struct FString& FullPathName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadFileToStringByFullPath");

	UScriptHelperClient_LoadFileToStringByFullPath_Params params;
	params.FullPathName = FullPathName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadFileToString
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::LoadFileToString(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadFileToString");

	UScriptHelperClient_LoadFileToString_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadFileToArray
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// TArray<unsigned char>          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<unsigned char> UScriptHelperClient::LoadFileToArray(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadFileToArray");

	UScriptHelperClient_LoadFileToArray_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadAmendODs
// ()
// Parameters:
// TMap<uint32_t, struct FString> Keys                           (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::LoadAmendODs(TMap<uint32_t, struct FString> Keys)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadAmendODs");

	UScriptHelperClient_LoadAmendODs_Params params;
	params.Keys = Keys;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.LoadAFDTranslation
// ()

void UScriptHelperClient::LoadAFDTranslation()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LoadAFDTranslation");

	UScriptHelperClient_LoadAFDTranslation_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.LaunchUrl
// ()
// Parameters:
// struct FString                 URL                            (Parm, OutParm, ZeroConstructor)

void UScriptHelperClient::LaunchUrl(struct FString* URL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.LaunchUrl");

	UScriptHelperClient_LaunchUrl_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (URL != nullptr)
		*URL = params.URL;
}


// Function Client.ScriptHelperClient.JoinVoiceRoom
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 roomName                       (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)

void UScriptHelperClient::JoinVoiceRoom(class UGameFrontendHUD* GameFrontendHUD, const struct FString& roomName, const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.JoinVoiceRoom");

	UScriptHelperClient_JoinVoiceRoom_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.roomName = roomName;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.JoinLbsVoiceRoom
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 lbsRoomName                    (Parm, ZeroConstructor)
// struct FString                 userId                         (Parm, ZeroConstructor)

void UScriptHelperClient::JoinLbsVoiceRoom(class UGameFrontendHUD* GameFrontendHUD, const struct FString& lbsRoomName, const struct FString& userId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.JoinLbsVoiceRoom");

	UScriptHelperClient_JoinLbsVoiceRoom_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.lbsRoomName = lbsRoomName;
	params.userId = userId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.IsWindowsClientReplay
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsWindowsClientReplay(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsWindowsClientReplay");

	UScriptHelperClient_IsWindowsClientReplay_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsWindowOB
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsWindowOB(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsWindowOB");

	UScriptHelperClient_IsWindowOB_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsUsingBluetooth
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsUsingBluetooth()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsUsingBluetooth");

	UScriptHelperClient_IsUsingBluetooth_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsUseTypicalResultFlowMode
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsUseTypicalResultFlowMode(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsUseTypicalResultFlowMode");

	UScriptHelperClient_IsUseTypicalResultFlowMode_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsUpdateSkip
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsUpdateSkip(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsUpdateSkip");

	UScriptHelperClient_IsUpdateSkip_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsUIAutoTest
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsUIAutoTest()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsUIAutoTest");

	UScriptHelperClient_IsUIAutoTest_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsTypicalMode
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsTypicalMode(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsTypicalMode");

	UScriptHelperClient_IsTypicalMode_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsTest
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsTest()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsTest");

	UScriptHelperClient_IsTest_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsTableDataExist_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::IsTableDataExist_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsTableDataExist_LuaState");

	UScriptHelperClient_IsTableDataExist_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsSystemVPNOpened
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsSystemVPNOpened()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsSystemVPNOpened");

	UScriptHelperClient_IsSystemVPNOpened_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsSupportVulkan
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsSupportVulkan()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsSupportVulkan");

	UScriptHelperClient_IsSupportVulkan_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsSplitMiniPakVersion
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsSplitMiniPakVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsSplitMiniPakVersion");

	UScriptHelperClient_IsSplitMiniPakVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsSplitMapPakVersion
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsSplitMapPakVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsSplitMapPakVersion");

	UScriptHelperClient_IsSplitMapPakVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.isSkipUpdateByRepair
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::isSkipUpdateByRepair(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.isSkipUpdateByRepair");

	UScriptHelperClient_isSkipUpdateByRepair_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsShipping
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsShipping()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsShipping");

	UScriptHelperClient_IsShipping_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsSavFileData
// ()
// Parameters:
// struct FString                 CompressedData                 (Parm, ZeroConstructor)
// int                            CompressedSize                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            UnCompressedSize               (Parm, ZeroConstructor, IsPlainOldData)
// int                            ToCheckEndWithCDLenght         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsSavFileData(const struct FString& CompressedData, int CompressedSize, int UnCompressedSize, int ToCheckEndWithCDLenght)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsSavFileData");

	UScriptHelperClient_IsSavFileData_Params params;
	params.CompressedData = CompressedData;
	params.CompressedSize = CompressedSize;
	params.UnCompressedSize = UnCompressedSize;
	params.ToCheckEndWithCDLenght = ToCheckEndWithCDLenght;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsRuningOnVulkan
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsRuningOnVulkan(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsRuningOnVulkan");

	UScriptHelperClient_IsRuningOnVulkan_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsReleaseVersion
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsReleaseVersion(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsReleaseVersion");

	UScriptHelperClient_IsReleaseVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsPVEMode
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsPVEMode(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsPVEMode");

	UScriptHelperClient_IsPVEMode_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsOpenAOS90FPSConfig
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsOpenAOS90FPSConfig()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsOpenAOS90FPSConfig");

	UScriptHelperClient_IsOpenAOS90FPSConfig_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsODPakMonted
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsODPakMonted(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsODPakMonted");

	UScriptHelperClient_IsODPakMonted_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsNotificationEnabled
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsNotificationEnabled()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsNotificationEnabled");

	UScriptHelperClient_IsNotificationEnabled_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsNoAuthMode
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsNoAuthMode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsNoAuthMode");

	UScriptHelperClient_IsNoAuthMode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsNetworkReachable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsNetworkReachable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsNetworkReachable");

	UScriptHelperClient_IsNetworkReachable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsNeedClearHiddenUI
// ()
// Parameters:
// class UFrontendHUD*            GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsNeedClearHiddenUI(class UFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsNeedClearHiddenUI");

	UScriptHelperClient_IsNeedClearHiddenUI_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsMounted
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsMounted(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsMounted");

	UScriptHelperClient_IsMounted_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsLaunchedByLocalNotification
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsLaunchedByLocalNotification()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsLaunchedByLocalNotification");

	UScriptHelperClient_IsLaunchedByLocalNotification_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsJaguar
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsJaguar()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsJaguar");

	UScriptHelperClient_IsJaguar_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsIPhoneFiveSOriginal
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsIPhoneFiveSOriginal()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsIPhoneFiveSOriginal");

	UScriptHelperClient_IsIPhoneFiveSOriginal_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsIPhoneFiveS
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsIPhoneFiveS(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsIPhoneFiveS");

	UScriptHelperClient_IsIPhoneFiveS_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsIOSVersionAbove13
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsIOSVersionAbove13()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsIOSVersionAbove13");

	UScriptHelperClient_IsIOSVersionAbove13_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallWX
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallWX(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallWX");

	UScriptHelperClient_IsInstallWX_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallWhatsapp
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallWhatsapp(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallWhatsapp");

	UScriptHelperClient_IsInstallWhatsapp_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallVK
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallVK(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallVK");

	UScriptHelperClient_IsInstallVK_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallTwitter
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallTwitter(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallTwitter");

	UScriptHelperClient_IsInstallTwitter_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallQQByiTOP
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallQQByiTOP(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallQQByiTOP");

	UScriptHelperClient_IsInstallQQByiTOP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallOpenRec
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallOpenRec(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallOpenRec");

	UScriptHelperClient_IsInstallOpenRec_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallMirrativ
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallMirrativ(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallMirrativ");

	UScriptHelperClient_IsInstallMirrativ_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallMessenger
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallMessenger(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallMessenger");

	UScriptHelperClient_IsInstallMessenger_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallLite
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallLite(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallLite");

	UScriptHelperClient_IsInstallLite_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallLine
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallLine(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallLine");

	UScriptHelperClient_IsInstallLine_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallFaceBook
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallFaceBook(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallFaceBook");

	UScriptHelperClient_IsInstallFaceBook_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsInstallDiscord
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsInstallDiscord(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsInstallDiscord");

	UScriptHelperClient_IsInstallDiscord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsHarmonyOS
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsHarmonyOS()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsHarmonyOS");

	UScriptHelperClient_IsHarmonyOS_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsHapticsEngineEnable
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsHapticsEngineEnable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsHapticsEngineEnable");

	UScriptHelperClient_IsHapticsEngineEnable_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsForCE
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsForCE()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsForCE");

	UScriptHelperClient_IsForCE_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsFileReady
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsFileReady(class UGameFrontendHUD* GameFrontendHUD, const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsFileReady");

	UScriptHelperClient_IsFileReady_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsFileExistsWithPakCheckMatchExt
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsFileExistsWithPakCheckMatchExt(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsFileExistsWithPakCheckMatchExt");

	UScriptHelperClient_IsFileExistsWithPakCheckMatchExt_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsFileExistsWithPakCheck
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsFileExistsWithPakCheck(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsFileExistsWithPakCheck");

	UScriptHelperClient_IsFileExistsWithPakCheck_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsFileExistsWithOutPakCheck
// ()
// Parameters:
// struct FString                 Path                           (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsFileExistsWithOutPakCheck(const struct FString& Path)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsFileExistsWithOutPakCheck");

	UScriptHelperClient_IsFileExistsWithOutPakCheck_Params params;
	params.Path = Path;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsFileExistByFileName
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsFileExistByFileName(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsFileExistByFileName");

	UScriptHelperClient_IsFileExistByFileName_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsFileExistByExtension
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Filename                       (Parm, ZeroConstructor)
// struct FString                 fileExtension                  (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsFileExistByExtension(class UGameFrontendHUD* GameFrontendHUD, const struct FString& Filename, const struct FString& fileExtension)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsFileExistByExtension");

	UScriptHelperClient_IsFileExistByExtension_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Filename = Filename;
	params.fileExtension = fileExtension;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsFileExist
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsFileExist(class UGameFrontendHUD* GameFrontendHUD, const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsFileExist");

	UScriptHelperClient_IsFileExist_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsEmulatorWhenInit
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsEmulatorWhenInit()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsEmulatorWhenInit");

	UScriptHelperClient_IsEmulatorWhenInit_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsEmulator
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsEmulator()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsEmulator");

	UScriptHelperClient_IsEmulator_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsEditorDedicatedServer
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsEditorDedicatedServer()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsEditorDedicatedServer");

	UScriptHelperClient_IsEditorDedicatedServer_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsEditor
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsEditor()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsEditor");

	UScriptHelperClient_IsEditor_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsDolbyAtmosSupported
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsDolbyAtmosSupported()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsDolbyAtmosSupported");

	UScriptHelperClient_IsDolbyAtmosSupported_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsDeviceSupportsViberation
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsDeviceSupportsViberation()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsDeviceSupportsViberation");

	UScriptHelperClient_IsDeviceSupportsViberation_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsDeviceSupportsHapticsEngine
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsDeviceSupportsHapticsEngine()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsDeviceSupportsHapticsEngine");

	UScriptHelperClient_IsDeviceSupportsHapticsEngine_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsDeviceHWSupportVulkan
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsDeviceHWSupportVulkan()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsDeviceHWSupportVulkan");

	UScriptHelperClient_IsDeviceHWSupportVulkan_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsDevelopment
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsDevelopment()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsDevelopment");

	UScriptHelperClient_IsDevelopment_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsConnected
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsConnected(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsConnected");

	UScriptHelperClient_IsConnected_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsCEVersion
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsCEVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsCEVersion");

	UScriptHelperClient_IsCEVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsCEHideLobbyUI
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsCEHideLobbyUI(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsCEHideLobbyUI");

	UScriptHelperClient_IsCEHideLobbyUI_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsBasePrefecthOpen
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsBasePrefecthOpen()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsBasePrefecthOpen");

	UScriptHelperClient_IsBasePrefecthOpen_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsAwakedByNotification
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsAwakedByNotification()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsAwakedByNotification");

	UScriptHelperClient_IsAwakedByNotification_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.IsAndroidHasGyr
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::IsAndroidHasGyr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.IsAndroidHasGyr");

	UScriptHelperClient_IsAndroidHasGyr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.InviteWhatsappOfflineFriends
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 Title                          (Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UScriptHelperClient::InviteWhatsappOfflineFriends(const struct FString& Title, const struct FString& Content, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InviteWhatsappOfflineFriends");

	UScriptHelperClient_InviteWhatsappOfflineFriends_Params params;
	params.Title = Title;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.InviteSystemOfflineFriends
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 Title                          (Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UScriptHelperClient::InviteSystemOfflineFriends(const struct FString& Title, const struct FString& Content, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InviteSystemOfflineFriends");

	UScriptHelperClient_InviteSystemOfflineFriends_Params params;
	params.Title = Title;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.InviteSMSOfflineFriends
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UScriptHelperClient::InviteSMSOfflineFriends(const struct FString& Content, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InviteSMSOfflineFriends");

	UScriptHelperClient_InviteSMSOfflineFriends_Params params;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.InviteLineOfflineFriends
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 Title                          (Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UScriptHelperClient::InviteLineOfflineFriends(const struct FString& Title, const struct FString& Content, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InviteLineOfflineFriends");

	UScriptHelperClient_InviteLineOfflineFriends_Params params;
	params.Title = Title;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.InviteFBOfflineFriends
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 Title                          (Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)
// struct FString                 link                           (Parm, ZeroConstructor)

void UScriptHelperClient::InviteFBOfflineFriends(const struct FString& Title, const struct FString& Content, const struct FString& link, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InviteFBOfflineFriends");

	UScriptHelperClient_InviteFBOfflineFriends_Params params;
	params.Title = Title;
	params.Content = Content;
	params.link = link;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.InstallNewApp
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::InstallNewApp(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InstallNewApp");

	UScriptHelperClient_InstallNewApp_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitVPN
// ()
// Parameters:
// struct FString                 InVPNGUID                      (Parm, ZeroConstructor)
// struct FString                 InClientVersion                (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::InitVPN(const struct FString& InVPNGUID, const struct FString& InClientVersion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitVPN");

	UScriptHelperClient_InitVPN_Params params;
	params.InVPNGUID = InVPNGUID;
	params.InClientVersion = InClientVersion;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.InitVlink
// ()

void UScriptHelperClient::InitVlink()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitVlink");

	UScriptHelperClient_InitVlink_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitQuantumPlatformMisc
// ()

void UScriptHelperClient::InitQuantumPlatformMisc()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitQuantumPlatformMisc");

	UScriptHelperClient_InitQuantumPlatformMisc_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitLoginAccount
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// uint64_t                       AccUin                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 AccPswd                        (Parm, ZeroConstructor)

void UScriptHelperClient::InitLoginAccount(uint64_t AccUin, const struct FString& AccPswd, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitLoginAccount");

	UScriptHelperClient_InitLoginAccount_Params params;
	params.AccUin = AccUin;
	params.AccPswd = AccPswd;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.InitJavaFunctions
// ()

void UScriptHelperClient::InitJavaFunctions()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitJavaFunctions");

	UScriptHelperClient_InitJavaFunctions_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitIMSDKEnv
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// uint32_t                       iEnv                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::InitIMSDKEnv(uint32_t iEnv, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitIMSDKEnv");

	UScriptHelperClient_InitIMSDKEnv_Params params;
	params.iEnv = iEnv;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.InitializePuffer
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           needCheck                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            maxDownloadsPerTask            (Parm, ZeroConstructor, IsPlainOldData)
// int                            maxDownTask                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            maxDownloadSpeed               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           useOldInterface                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           removeOldWhenUpdate            (Parm, ZeroConstructor, IsPlainOldData)
// int                            versionType                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::InitializePuffer(class UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitializePuffer");

	UScriptHelperClient_InitializePuffer_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.needCheck = needCheck;
	params.maxDownloadsPerTask = maxDownloadsPerTask;
	params.maxDownTask = maxDownTask;
	params.maxDownloadSpeed = maxDownloadSpeed;
	params.useOldInterface = useOldInterface;
	params.removeOldWhenUpdate = removeOldWhenUpdate;
	params.versionType = versionType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitializeLaggingReporter
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::InitializeLaggingReporter(class UGameFrontendHUD* GameFrontendHUD, bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitializeLaggingReporter");

	UScriptHelperClient_InitializeLaggingReporter_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitHF
// ()

void UScriptHelperClient::InitHF()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitHF");

	UScriptHelperClient_InitHF_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitGCloudRemoteConfig
// ()

void UScriptHelperClient::InitGCloudRemoteConfig()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitGCloudRemoteConfig");

	UScriptHelperClient_InitGCloudRemoteConfig_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.InitDH
// ()
// Parameters:
// struct FString                 gen                            (Parm, ZeroConstructor)
// struct FString                 prime                          (Parm, ZeroConstructor)
// int                            v_srand                        (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::InitDH(const struct FString& gen, const struct FString& prime, int v_srand)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.InitDH");

	UScriptHelperClient_InitDH_Params params;
	params.gen = gen;
	params.prime = prime;
	params.v_srand = v_srand;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.Ini_UpdateMemResource
// ()
// Parameters:
// struct FString                 KeyWord                        (Parm, ZeroConstructor)
// struct FString                 CMDvalue                       (Parm, ZeroConstructor)

void UScriptHelperClient::Ini_UpdateMemResource(const struct FString& KeyWord, const struct FString& CMDvalue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Ini_UpdateMemResource");

	UScriptHelperClient_Ini_UpdateMemResource_Params params;
	params.KeyWord = KeyWord;
	params.CMDvalue = CMDvalue;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.HtmlEncode
// ()
// Parameters:
// struct FString                 UnencodedString                (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::HtmlEncode(const struct FString& UnencodedString)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HtmlEncode");

	UScriptHelperClient_HtmlEncode_Params params;
	params.UnencodedString = UnencodedString;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.HideH5WebView
// ()

void UScriptHelperClient::HideH5WebView()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HideH5WebView");

	UScriptHelperClient_HideH5WebView_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.HaveReceivedNoticeCallback
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::HaveReceivedNoticeCallback()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HaveReceivedNoticeCallback");

	UScriptHelperClient_HaveReceivedNoticeCallback_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.HasRemoteConfigReady
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::HasRemoteConfigReady()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HasRemoteConfigReady");

	UScriptHelperClient_HasRemoteConfigReady_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.HasNotice
// ()
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Scene                          (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::HasNotice(int Type, const struct FString& Scene)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HasNotice");

	UScriptHelperClient_HasNotice_Params params;
	params.Type = Type;
	params.Scene = Scene;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.HasNotchInScreen
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::HasNotchInScreen()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HasNotchInScreen");

	UScriptHelperClient_HasNotchInScreen_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.HasDownloadedBasePak
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::HasDownloadedBasePak()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HasDownloadedBasePak");

	UScriptHelperClient_HasDownloadedBasePak_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.HasActiveWifi
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::HasActiveWifi()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.HasActiveWifi");

	UScriptHelperClient_HasActiveWifi_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GotoPlatformAppraise
// ()

void UScriptHelperClient::GotoPlatformAppraise()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GotoPlatformAppraise");

	UScriptHelperClient_GotoPlatformAppraise_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GMTestAllocUObjs
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            Num                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GMTestAllocUObjs(class UGameFrontendHUD* GameFrontendHUD, int Num)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GMTestAllocUObjs");

	UScriptHelperClient_GMTestAllocUObjs_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Num = Num;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GMH5Enable
// ()
// Parameters:
// bool                           Flag                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GMH5Enable(bool Flag)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GMH5Enable");

	UScriptHelperClient_GMH5Enable_Params params;
	params.Flag = Flag;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GetWidgetsByClass
// ()
// Parameters:
// class UWidget*                 Parent                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UClass*                  Type                           (Parm, ZeroConstructor, IsPlainOldData)
// TArray<class UWidget*>         Children                       (Parm, OutParm, ZeroConstructor)

void UScriptHelperClient::GetWidgetsByClass(class UWidget* Parent, class UClass* Type, TArray<class UWidget*>* Children)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetWidgetsByClass");

	UScriptHelperClient_GetWidgetsByClass_Params params;
	params.Parent = Parent;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Children != nullptr)
		*Children = params.Children;
}


// Function Client.ScriptHelperClient.GetWebViewTicket
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetWebViewTicket(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetWebViewTicket");

	UScriptHelperClient_GetWebViewTicket_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetWeaponDIYIconPath
// ()
// Parameters:
// struct FString                 PlayerUID                      (Parm, ZeroConstructor)
// int                            WeaponId                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 PlanID                         (Parm, ZeroConstructor)
// bool                           relativePath                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            Width                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            Height                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetWeaponDIYIconPath(const struct FString& PlayerUID, int WeaponId, const struct FString& PlanID, bool relativePath, int Width, int Height)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetWeaponDIYIconPath");

	UScriptHelperClient_GetWeaponDIYIconPath_Params params;
	params.PlayerUID = PlayerUID;
	params.WeaponId = WeaponId;
	params.PlanID = PlanID;
	params.relativePath = relativePath;
	params.Width = Width;
	params.Height = Height;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetUserVulkanSetting
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GetUserVulkanSetting()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetUserVulkanSetting");

	UScriptHelperClient_GetUserVulkanSetting_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetUnrealNetworkStatus
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetUnrealNetworkStatus(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetUnrealNetworkStatus");

	UScriptHelperClient_GetUnrealNetworkStatus_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetUIRectOffset
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetUIRectOffset()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetUIRectOffset");

	UScriptHelperClient_GetUIRectOffset_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetToken
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetToken(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetToken");

	UScriptHelperClient_GetToken_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetTimeInMiliSeconds
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UScriptHelperClient::GetTimeInMiliSeconds()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetTimeInMiliSeconds");

	UScriptHelperClient_GetTimeInMiliSeconds_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetTelecomSvr
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetTelecomSvr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetTelecomSvr");

	UScriptHelperClient_GetTelecomSvr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetTCDeviceLevel
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetTCDeviceLevel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetTCDeviceLevel");

	UScriptHelperClient_GetTCDeviceLevel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetTableData_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetTableData_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetTableData_LuaState");

	UScriptHelperClient_GetTableData_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetTableCount
// ()
// Parameters:
// struct FString                 tableName                      (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetTableCount(const struct FString& tableName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetTableCount");

	UScriptHelperClient_GetTableCount_Params params;
	params.tableName = tableName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetTable_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetTable_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetTable_LuaState");

	UScriptHelperClient_GetTable_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetSystemLanguage_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetSystemLanguage_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetSystemLanguage_LuaState");

	UScriptHelperClient_GetSystemLanguage_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetSubsideFeatureLevel
// ()
// Parameters:
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UScriptHelperClient::GetSubsideFeatureLevel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetSubsideFeatureLevel");

	UScriptHelperClient_GetSubsideFeatureLevel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetSrcVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetSrcVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetSrcVersion");

	UScriptHelperClient_GetSrcVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetSplitMapConfigInfo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetSplitMapConfigInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetSplitMapConfigInfo");

	UScriptHelperClient_GetSplitMapConfigInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetSpecialData
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetSpecialData()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetSpecialData");

	UScriptHelperClient_GetSpecialData_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetSoundEffectQuality
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetSoundEffectQuality()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetSoundEffectQuality");

	UScriptHelperClient_GetSoundEffectQuality_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetShaderPrecompileProgress
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetShaderPrecompileProgress()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetShaderPrecompileProgress");

	UScriptHelperClient_GetShaderPrecompileProgress_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetServerDelay
// ()
// Parameters:
// struct FString                 ServerAddress                  (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetServerDelay(const struct FString& ServerAddress)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetServerDelay");

	UScriptHelperClient_GetServerDelay_Params params;
	params.ServerAddress = ServerAddress;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetScreenWidthForWebview
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetScreenWidthForWebview()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetScreenWidthForWebview");

	UScriptHelperClient_GetScreenWidthForWebview_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetScreenWidth
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetScreenWidth()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetScreenWidth");

	UScriptHelperClient_GetScreenWidth_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetScreenHole
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetScreenHole()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetScreenHole");

	UScriptHelperClient_GetScreenHole_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetScreenHight
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetScreenHight()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetScreenHight");

	UScriptHelperClient_GetScreenHight_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetScreenHeightForWebview
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetScreenHeightForWebview()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetScreenHeightForWebview");

	UScriptHelperClient_GetScreenHeightForWebview_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetScreenDensity
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetScreenDensity()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetScreenDensity");

	UScriptHelperClient_GetScreenDensity_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetRemarkNameByGIDWithObj
// ()
// Parameters:
// class UObject*                 Obj                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 gid                            (Parm, ZeroConstructor)
// struct FString                 PlayerName                     (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetRemarkNameByGIDWithObj(class UObject* Obj, const struct FString& gid, const struct FString& PlayerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetRemarkNameByGIDWithObj");

	UScriptHelperClient_GetRemarkNameByGIDWithObj_Params params;
	params.Obj = Obj;
	params.gid = gid;
	params.PlayerName = PlayerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetRemarkNameByGID
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 gid                            (Parm, ZeroConstructor)
// struct FString                 PlayerName                     (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetRemarkNameByGID(class UGameFrontendHUD* GameFrontendHUD, const struct FString& gid, const struct FString& PlayerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetRemarkNameByGID");

	UScriptHelperClient_GetRemarkNameByGID_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.gid = gid;
	params.PlayerName = PlayerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetRegisterChannelID
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetRegisterChannelID(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetRegisterChannelID");

	UScriptHelperClient_GetRegisterChannelID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetRedBloodSwitch
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GetRedBloodSwitch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetRedBloodSwitch");

	UScriptHelperClient_GetRedBloodSwitch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPufferInitResult
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GetPufferInitResult(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPufferInitResult");

	UScriptHelperClient_GetPufferInitResult_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPufferInitErrCode
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UScriptHelperClient::GetPufferInitErrCode(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPufferInitErrCode");

	UScriptHelperClient_GetPufferInitErrCode_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPublishRegion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPublishRegion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPublishRegion");

	UScriptHelperClient_GetPublishRegion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPublicKey
// ()
// Parameters:
// struct FString                 cli_pri_key                    (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPublicKey(const struct FString& cli_pri_key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPublicKey");

	UScriptHelperClient_GetPublicKey_Params params;
	params.cli_pri_key = cli_pri_key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPrivateKey
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPrivateKey()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPrivateKey");

	UScriptHelperClient_GetPrivateKey_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPingReportInfo
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPingReportInfo(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPingReportInfo");

	UScriptHelperClient_GetPingReportInfo_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPingReportData
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPingReportData(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPingReportData");

	UScriptHelperClient_GetPingReportData_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPhysicalFileTime
// ()
// Parameters:
// struct FString                 InPath                         (Parm, ZeroConstructor)
// int64_t                        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t UScriptHelperClient::GetPhysicalFileTime(const struct FString& InPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPhysicalFileTime");

	UScriptHelperClient_GetPhysicalFileTime_Params params;
	params.InPath = InPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPhoneType
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPhoneType()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPhoneType");

	UScriptHelperClient_GetPhoneType_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPhoneDeviceID
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPhoneDeviceID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPhoneDeviceID");

	UScriptHelperClient_GetPhoneDeviceID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPhoneAdvertisingID
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPhoneAdvertisingID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPhoneAdvertisingID");

	UScriptHelperClient_GetPhoneAdvertisingID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetPackChannel
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetPackChannel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetPackChannel");

	UScriptHelperClient_GetPackChannel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetOSVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetOSVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetOSVersion");

	UScriptHelperClient_GetOSVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetODPaksFileUseTime
// ()
// Parameters:
// struct FString                 DumpFilename                   (Parm, ZeroConstructor)
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScriptHelperClient::GetODPaksFileUseTime(const struct FString& DumpFilename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetODPaksFileUseTime");

	UScriptHelperClient_GetODPaksFileUseTime_Params params;
	params.DumpFilename = DumpFilename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetNotificationExtraDataString
// ()
// Parameters:
// struct FString                 Key                            (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetNotificationExtraDataString(const struct FString& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetNotificationExtraDataString");

	UScriptHelperClient_GetNotificationExtraDataString_Params params;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetNotchSize
// ()
// Parameters:
// TArray<int>                    ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<int> UScriptHelperClient::GetNotchSize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetNotchSize");

	UScriptHelperClient_GetNotchSize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetNetWorkType
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetNetWorkType()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetNetWorkType");

	UScriptHelperClient_GetNetWorkType_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetNativeVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetNativeVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetNativeVersion");

	UScriptHelperClient_GetNativeVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetNativePackageTag
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetNativePackageTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetNativePackageTag");

	UScriptHelperClient_GetNativePackageTag_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetMyFriendObservers
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScriptHelperClient::GetMyFriendObservers(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetMyFriendObservers");

	UScriptHelperClient_GetMyFriendObservers_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetMidasPF_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetMidasPF_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetMidasPF_LuaState");

	UScriptHelperClient_GetMidasPF_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetMidasPayChannel_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetMidasPayChannel_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetMidasPayChannel_LuaState");

	UScriptHelperClient_GetMidasPayChannel_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetMemoryStats_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetMemoryStats_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetMemoryStats_LuaState");

	UScriptHelperClient_GetMemoryStats_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetMemorySize
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetMemorySize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetMemorySize");

	UScriptHelperClient_GetMemorySize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetLuaRootDir
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetLuaRootDir()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetLuaRootDir");

	UScriptHelperClient_GetLuaRootDir_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetLoginChannel
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetLoginChannel(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetLoginChannel");

	UScriptHelperClient_GetLoginChannel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetLaunchLocalNotificationID
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetLaunchLocalNotificationID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetLaunchLocalNotificationID");

	UScriptHelperClient_GetLaunchLocalNotificationID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetKnownMissingPackage
// ()
// Parameters:
// struct FString                 PackageName                    (Parm, ZeroConstructor)
// struct FString                 DumpFilename                   (Parm, ZeroConstructor)
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScriptHelperClient::GetKnownMissingPackage(const struct FString& PackageName, const struct FString& DumpFilename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetKnownMissingPackage");

	UScriptHelperClient_GetKnownMissingPackage_Params params;
	params.PackageName = PackageName;
	params.DumpFilename = DumpFilename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetiTOPLbsDelay
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetiTOPLbsDelay()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetiTOPLbsDelay");

	UScriptHelperClient_GetiTOPLbsDelay_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetITopGameId
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetITopGameId(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetITopGameId");

	UScriptHelperClient_GetITopGameId_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIsSecretVersion
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetIsSecretVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIsSecretVersion");

	UScriptHelperClient_GetIsSecretVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIsPlayerUsingVPN
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GetIsPlayerUsingVPN()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIsPlayerUsingVPN");

	UScriptHelperClient_GetIsPlayerUsingVPN_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIsOpenBattlePlayback
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GetIsOpenBattlePlayback(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIsOpenBattlePlayback");

	UScriptHelperClient_GetIsOpenBattlePlayback_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIPRegion
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetIPRegion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIPRegion");

	UScriptHelperClient_GetIPRegion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIpAddrByHost
// ()
// Parameters:
// struct FString                 Host                           (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetIpAddrByHost(const struct FString& Host)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIpAddrByHost");

	UScriptHelperClient_GetIpAddrByHost_Params params;
	params.Host = Host;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIpAddr
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetIpAddr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIpAddr");

	UScriptHelperClient_GetIpAddr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIntDefaultOffset
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetIntDefaultOffset()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIntDefaultOffset");

	UScriptHelperClient_GetIntDefaultOffset_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetInstallChannelID
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetInstallChannelID(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetInstallChannelID");

	UScriptHelperClient_GetInstallChannelID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetIMSDKEnv
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetIMSDKEnv()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetIMSDKEnv");

	UScriptHelperClient_GetIMSDKEnv_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetH5CacheStatus
// ()
// Parameters:
// struct FString                 ModuleName                     (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GetH5CacheStatus(const struct FString& ModuleName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetH5CacheStatus");

	UScriptHelperClient_GetH5CacheStatus_Params params;
	params.ModuleName = ModuleName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetGvoiceReconnectInfo
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// TMap<struct FString, struct FString> Data                           (ConstParm, Parm, ZeroConstructor)

void UScriptHelperClient::GetGvoiceReconnectInfo(class UGameFrontendHUD* GameFrontendHUD, TMap<struct FString, struct FString> Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGvoiceReconnectInfo");

	UScriptHelperClient_GetGvoiceReconnectInfo_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GetGroupInfo
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            SnsAction                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FGroupInfoWrapper       ReturnValue                    (Parm, OutParm, ReturnParm)

struct FGroupInfoWrapper UScriptHelperClient::GetGroupInfo(int SnsAction, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGroupInfo");

	UScriptHelperClient_GetGroupInfo_Params params;
	params.SnsAction = SnsAction;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetGoogleServiceVersionCode
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetGoogleServiceVersionCode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGoogleServiceVersionCode");

	UScriptHelperClient_GetGoogleServiceVersionCode_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetGLVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetGLVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGLVersion");

	UScriptHelperClient_GetGLVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetGLType
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetGLType()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGLType");

	UScriptHelperClient_GetGLType_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetGameStatus
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetGameStatus(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGameStatus");

	UScriptHelperClient_GetGameStatus_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetGameModeID
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetGameModeID(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGameModeID");

	UScriptHelperClient_GetGameModeID_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetGameMasterGUID
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetGameMasterGUID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetGameMasterGUID");

	UScriptHelperClient_GetGameMasterGUID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetFPS
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UScriptHelperClient::GetFPS()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetFPS");

	UScriptHelperClient_GetFPS_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetFileSizeOnDiskBytes
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// int64_t                        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t UScriptHelperClient::GetFileSizeOnDiskBytes(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetFileSizeOnDiskBytes");

	UScriptHelperClient_GetFileSizeOnDiskBytes_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetFileSizeOnDisk
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UScriptHelperClient::GetFileSizeOnDisk(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetFileSizeOnDisk");

	UScriptHelperClient_GetFileSizeOnDisk_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetFileSizeCompressed
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// uint64_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint64_t UScriptHelperClient::GetFileSizeCompressed(class UGameFrontendHUD* GameFrontendHUD, const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetFileSizeCompressed");

	UScriptHelperClient_GetFileSizeCompressed_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetFileDirPath
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetFileDirPath(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetFileDirPath");

	UScriptHelperClient_GetFileDirPath_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetFBFriendsUnregistered
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// uint32_t                       page                           (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Count                          (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Type                           (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 extend                         (Parm, ZeroConstructor)

void UScriptHelperClient::GetFBFriendsUnregistered(uint32_t page, uint32_t Count, uint32_t Type, const struct FString& extend, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetFBFriendsUnregistered");

	UScriptHelperClient_GetFBFriendsUnregistered_Params params;
	params.page = page;
	params.Count = Count;
	params.Type = Type;
	params.extend = extend;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.GetExactDeviceLevel
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetExactDeviceLevel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetExactDeviceLevel");

	UScriptHelperClient_GetExactDeviceLevel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetEncodeUrl
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetEncodeUrl(const struct FString& URL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetEncodeUrl");

	UScriptHelperClient_GetEncodeUrl_Params params;
	params.URL = URL;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetEmulatorName
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetEmulatorName()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetEmulatorName");

	UScriptHelperClient_GetEmulatorName_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetDSVersion
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetDSVersion(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetDSVersion");

	UScriptHelperClient_GetDSVersion_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetDeviceQualityLevel
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetDeviceQualityLevel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetDeviceQualityLevel");

	UScriptHelperClient_GetDeviceQualityLevel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetDevicePlatformName
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetDevicePlatformName()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetDevicePlatformName");

	UScriptHelperClient_GetDevicePlatformName_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetDeviceModel
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetDeviceModel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetDeviceModel");

	UScriptHelperClient_GetDeviceModel_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetDeviceMaxSupportSoundEffect
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetDeviceMaxSupportSoundEffect()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetDeviceMaxSupportSoundEffect");

	UScriptHelperClient_GetDeviceMaxSupportSoundEffect_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetDeviceInfo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetDeviceInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetDeviceInfo");

	UScriptHelperClient_GetDeviceInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetDeviceFreeSpace
// ()
// Parameters:
// uint64_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint64_t UScriptHelperClient::GetDeviceFreeSpace()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetDeviceFreeSpace");

	UScriptHelperClient_GetDeviceFreeSpace_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetCurrentRHILevel
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetCurrentRHILevel(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetCurrentRHILevel");

	UScriptHelperClient_GetCurrentRHILevel_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetCurrentLanguage_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetCurrentLanguage_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetCurrentLanguage_LuaState");

	UScriptHelperClient_GetCurrentLanguage_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetCurrentChannel
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetCurrentChannel(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetCurrentChannel");

	UScriptHelperClient_GetCurrentChannel_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetCpuType
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetCpuType()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetCpuType");

	UScriptHelperClient_GetCpuType_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetCDNUpdateInfo
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// TMap<struct FString, struct FString> Data                           (ConstParm, Parm, ZeroConstructor)

void UScriptHelperClient::GetCDNUpdateInfo(class UGameFrontendHUD* GameFrontendHUD, TMap<struct FString, struct FString> Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetCDNUpdateInfo");

	UScriptHelperClient_GetCDNUpdateInfo_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GetBuildVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetBuildVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetBuildVersion");

	UScriptHelperClient_GetBuildVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetBattleKey
// ()
// Parameters:
// struct FString                 svr_pub_key                    (Parm, ZeroConstructor)
// struct FString                 cli_pri_key                    (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetBattleKey(const struct FString& svr_pub_key, const struct FString& cli_pri_key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetBattleKey");

	UScriptHelperClient_GetBattleKey_Params params;
	params.svr_pub_key = svr_pub_key;
	params.cli_pri_key = cli_pri_key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAreaIPNo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetAreaIPNo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAreaIPNo");

	UScriptHelperClient_GetAreaIPNo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAppVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetAppVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAppVersion");

	UScriptHelperClient_GetAppVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetApplicationVersion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetApplicationVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetApplicationVersion");

	UScriptHelperClient_GetApplicationVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAOSSHOP
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetAOSSHOP()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAOSSHOP");

	UScriptHelperClient_GetAOSSHOP_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAndroidSysInfo
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetAndroidSysInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAndroidSysInfo");

	UScriptHelperClient_GetAndroidSysInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAndroidSOVersion
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetAndroidSOVersion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAndroidSOVersion");

	UScriptHelperClient_GetAndroidSOVersion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAndroidMaxStackSize
// ()
// Parameters:
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UScriptHelperClient::GetAndroidMaxStackSize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAndroidMaxStackSize");

	UScriptHelperClient_GetAndroidMaxStackSize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAndroidMaxFDNum
// ()
// Parameters:
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UScriptHelperClient::GetAndroidMaxFDNum()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAndroidMaxFDNum");

	UScriptHelperClient_GetAndroidMaxFDNum_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAndroidCurrentFDNum
// ()
// Parameters:
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UScriptHelperClient::GetAndroidCurrentFDNum()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAndroidCurrentFDNum");

	UScriptHelperClient_GetAndroidCurrentFDNum_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAndroidBuildForArm
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GetAndroidBuildForArm()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAndroidBuildForArm");

	UScriptHelperClient_GetAndroidBuildForArm_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAllLocalNotificationIDs
// ()
// Parameters:
// TArray<int>                    ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<int> UScriptHelperClient::GetAllLocalNotificationIDs()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAllLocalNotificationIDs");

	UScriptHelperClient_GetAllLocalNotificationIDs_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAllFilesInDir
// ()
// Parameters:
// struct FString                 Dir                            (Parm, ZeroConstructor)
// struct FString                 Pattern                        (Parm, ZeroConstructor)
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScriptHelperClient::GetAllFilesInDir(const struct FString& Dir, const struct FString& Pattern)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAllFilesInDir");

	UScriptHelperClient_GetAllFilesInDir_Params params;
	params.Dir = Dir;
	params.Pattern = Pattern;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAccountRegion
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetAccountRegion()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAccountRegion");

	UScriptHelperClient_GetAccountRegion_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GetAccessToken
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GetAccessToken(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GetAccessToken");

	UScriptHelperClient_GetAccessToken_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GenerateQRImage
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            Tag                            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            Size                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Content                        (Parm, ZeroConstructor)
// struct FString                 logoPath                       (Parm, ZeroConstructor)

void UScriptHelperClient::GenerateQRImage(int Tag, int Size, const struct FString& Content, const struct FString& logoPath, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GenerateQRImage");

	UScriptHelperClient_GenerateQRImage_Params params;
	params.Tag = Tag;
	params.Size = Size;
	params.Content = Content;
	params.logoPath = logoPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.GEMReportSubEvent
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 EventName                      (Parm, ZeroConstructor)
// struct FString                 SubEventName                   (Parm, ZeroConstructor)
// TArray<struct FString>         eventParams                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UScriptHelperClient::GEMReportSubEvent(class UGameFrontendHUD* GameFrontendHUD, const struct FString& EventName, const struct FString& SubEventName, TArray<struct FString> eventParams)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GEMReportSubEvent");

	UScriptHelperClient_GEMReportSubEvent_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.EventName = EventName;
	params.SubEventName = SubEventName;
	params.eventParams = eventParams;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GEMReportShaderPrecompileEvent
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           IsSuccess                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 strDesc                        (Parm, ZeroConstructor)

void UScriptHelperClient::GEMReportShaderPrecompileEvent(class UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, const struct FString& strDesc)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GEMReportShaderPrecompileEvent");

	UScriptHelperClient_GEMReportShaderPrecompileEvent_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.IsSuccess = IsSuccess;
	params.strDesc = strDesc;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GEMReportEvent
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 EventName                      (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> eventParams                    (Parm, ZeroConstructor)

void UScriptHelperClient::GEMReportEvent(class UGameFrontendHUD* GameFrontendHUD, const struct FString& EventName, TMap<struct FString, struct FString> eventParams)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GEMReportEvent");

	UScriptHelperClient_GEMReportEvent_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.EventName = EventName;
	params.eventParams = eventParams;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GEMReportEnterLobbyEvent
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           IsSuccess                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 strDesc                        (Parm, ZeroConstructor)

void UScriptHelperClient::GEMReportEnterLobbyEvent(class UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, const struct FString& strDesc)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GEMReportEnterLobbyEvent");

	UScriptHelperClient_GEMReportEnterLobbyEvent_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.IsSuccess = IsSuccess;
	params.strDesc = strDesc;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GCloudRemoteConfigGetString
// ()
// Parameters:
// struct FString                 InKey                          (Parm, ZeroConstructor)
// struct FString                 InDefaultValue                 (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GCloudRemoteConfigGetString(const struct FString& InKey, const struct FString& InDefaultValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GCloudRemoteConfigGetString");

	UScriptHelperClient_GCloudRemoteConfigGetString_Params params;
	params.InKey = InKey;
	params.InDefaultValue = InDefaultValue;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GCloudRemoteConfigGetInt
// ()
// Parameters:
// struct FString                 InKey                          (Parm, ZeroConstructor)
// int                            InDefaultValue                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GCloudRemoteConfigGetInt(const struct FString& InKey, int InDefaultValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GCloudRemoteConfigGetInt");

	UScriptHelperClient_GCloudRemoteConfigGetInt_Params params;
	params.InKey = InKey;
	params.InDefaultValue = InDefaultValue;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GCloudRemoteConfigGetBool
// ()
// Parameters:
// struct FString                 InKey                          (Parm, ZeroConstructor)
// bool                           InDefaultValue                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GCloudRemoteConfigGetBool(const struct FString& InKey, bool InDefaultValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GCloudRemoteConfigGetBool");

	UScriptHelperClient_GCloudRemoteConfigGetBool_Params params;
	params.InKey = InKey;
	params.InDefaultValue = InDefaultValue;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameMasterSetUserInfo
// ()
// Parameters:
// struct FString                 InPaidInfo                     (Parm, ZeroConstructor)
// struct FString                 InUserToken                    (Parm, ZeroConstructor)
// struct FString                 InAppId                        (Parm, ZeroConstructor)

void UScriptHelperClient::GameMasterSetUserInfo(const struct FString& InPaidInfo, const struct FString& InUserToken, const struct FString& InAppId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterSetUserInfo");

	UScriptHelperClient_GameMasterSetUserInfo_Params params;
	params.InPaidInfo = InPaidInfo;
	params.InUserToken = InUserToken;
	params.InAppId = InAppId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterSetUsableRegion
// ()
// Parameters:
// struct FString                 InRegion                       (Parm, ZeroConstructor)

void UScriptHelperClient::GameMasterSetUsableRegion(const struct FString& InRegion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterSetUsableRegion");

	UScriptHelperClient_GameMasterSetUsableRegion_Params params;
	params.InRegion = InRegion;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterSetUdpEchoPort
// ()
// Parameters:
// int                            InPort                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameMasterSetUdpEchoPort(int InPort)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterSetUdpEchoPort");

	UScriptHelperClient_GameMasterSetUdpEchoPort_Params params;
	params.InPort = InPort;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterSetOnlyWifiAccel
// ()
// Parameters:
// bool                           InOn                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameMasterSetOnlyWifiAccel(bool InOn)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterSetOnlyWifiAccel");

	UScriptHelperClient_GameMasterSetOnlyWifiAccel_Params params;
	params.InOn = InOn;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterSetFreeFlowUser
// ()
// Parameters:
// int                            InType                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameMasterSetFreeFlowUser(int InType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterSetFreeFlowUser");

	UScriptHelperClient_GameMasterSetFreeFlowUser_Params params;
	params.InType = InType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterOnNetDelay
// ()
// Parameters:
// int                            InMillis                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameMasterOnNetDelay(int InMillis)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterOnNetDelay");

	UScriptHelperClient_GameMasterOnNetDelay_Params params;
	params.InMillis = InMillis;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterIsAccelOpened
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GameMasterIsAccelOpened()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterIsAccelOpened");

	UScriptHelperClient_GameMasterIsAccelOpened_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameMasterInit
// ()
// Parameters:
// int                            InHookType                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 InGuid                         (Parm, ZeroConstructor)
// struct FString                 InLibs                         (Parm, ZeroConstructor)
// int                            InEchoPort                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GameMasterInit(int InHookType, const struct FString& InGuid, const struct FString& InLibs, int InEchoPort)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterInit");

	UScriptHelperClient_GameMasterInit_Params params;
	params.InHookType = InHookType;
	params.InGuid = InGuid;
	params.InLibs = InLibs;
	params.InEchoPort = InEchoPort;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameMasterGetWebUIUrl
// ()
// Parameters:
// int                            InType                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GameMasterGetWebUIUrl(int InType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterGetWebUIUrl");

	UScriptHelperClient_GameMasterGetWebUIUrl_Params params;
	params.InType = InType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameMasterGetVIPValidTime
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GameMasterGetVIPValidTime()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterGetVIPValidTime");

	UScriptHelperClient_GameMasterGetVIPValidTime_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameMasterGetUserID
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::GameMasterGetUserID()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterGetUserID");

	UScriptHelperClient_GameMasterGetUserID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameMasterGetAccelerationStatus
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::GameMasterGetAccelerationStatus()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterGetAccelerationStatus");

	UScriptHelperClient_GameMasterGetAccelerationStatus_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameMasterClearAccelAddr
// ()

void UScriptHelperClient::GameMasterClearAccelAddr()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterClearAccelAddr");

	UScriptHelperClient_GameMasterClearAccelAddr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterBeginRound
// ()
// Parameters:
// struct FString                 InOpenId                       (Parm, ZeroConstructor)
// struct FString                 InPvpId                        (Parm, ZeroConstructor)

void UScriptHelperClient::GameMasterBeginRound(const struct FString& InOpenId, const struct FString& InPvpId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterBeginRound");

	UScriptHelperClient_GameMasterBeginRound_Params params;
	params.InOpenId = InOpenId;
	params.InPvpId = InPvpId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterAddNewArenaAddress
// ()
// Parameters:
// struct FString                 InProtocol                     (Parm, ZeroConstructor)
// struct FString                 InIp                           (Parm, ZeroConstructor)
// int                            InPort                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameMasterAddNewArenaAddress(const struct FString& InProtocol, const struct FString& InIp, int InPort)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterAddNewArenaAddress");

	UScriptHelperClient_GameMasterAddNewArenaAddress_Params params;
	params.InProtocol = InProtocol;
	params.InIp = InIp;
	params.InPort = InPort;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameMasterAddAccelAddr
// ()
// Parameters:
// struct FString                 InProtocol                     (Parm, ZeroConstructor)
// struct FString                 InIp                           (Parm, ZeroConstructor)
// int                            InPort                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameMasterAddAccelAddr(const struct FString& InProtocol, const struct FString& InIp, int InPort)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameMasterAddAccelAddr");

	UScriptHelperClient_GameMasterAddAccelAddr_Params params;
	params.InProtocol = InProtocol;
	params.InIp = InIp;
	params.InPort = InPort;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoySwitchOn
// ()
// Parameters:
// int                            isOn                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameJoySwitchOn(int isOn)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoySwitchOn");

	UScriptHelperClient_GameJoySwitchOn_Params params;
	params.isOn = isOn;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoyStopManualRecord
// ()

void UScriptHelperClient::GameJoyStopManualRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoyStopManualRecord");

	UScriptHelperClient_GameJoyStopManualRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoyStartMomentsRecord
// ()

void UScriptHelperClient::GameJoyStartMomentsRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoyStartMomentsRecord");

	UScriptHelperClient_GameJoyStartMomentsRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoyStartManualRecord
// ()

void UScriptHelperClient::GameJoyStartManualRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoyStartManualRecord");

	UScriptHelperClient_GameJoyStartManualRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoySetVideoQuality
// ()
// Parameters:
// int                            Quality                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameJoySetVideoQuality(int Quality)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoySetVideoQuality");

	UScriptHelperClient_GameJoySetVideoQuality_Params params;
	params.Quality = Quality;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoySetMomentRecordSwitchOn
// ()
// Parameters:
// int                            isOn                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameJoySetMomentRecordSwitchOn(int isOn)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoySetMomentRecordSwitchOn");

	UScriptHelperClient_GameJoySetMomentRecordSwitchOn_Params params;
	params.isOn = isOn;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoySetLuaguage
// ()

void UScriptHelperClient::GameJoySetLuaguage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoySetLuaguage");

	UScriptHelperClient_GameJoySetLuaguage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoySetCurrentRecorderPosition
// ()
// Parameters:
// float                          X                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Y                              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::GameJoySetCurrentRecorderPosition(float X, float Y)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoySetCurrentRecorderPosition");

	UScriptHelperClient_GameJoySetCurrentRecorderPosition_Params params;
	params.X = X;
	params.Y = Y;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoyIsSDKFeatureSupport
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::GameJoyIsSDKFeatureSupport()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoyIsSDKFeatureSupport");

	UScriptHelperClient_GameJoyIsSDKFeatureSupport_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.GameJoyGenerateMomentsVideo
// ()
// Parameters:
// TArray<struct FTimeStamp>      shortVideosTimeStampList       (Parm, ZeroConstructor)
// TArray<struct FTimeStamp>      largeVideosTimeStampList       (Parm, ZeroConstructor)
// struct FString                 Title                          (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> ExtraInfo                      (Parm, ZeroConstructor)

void UScriptHelperClient::GameJoyGenerateMomentsVideo(TArray<struct FTimeStamp> shortVideosTimeStampList, TArray<struct FTimeStamp> largeVideosTimeStampList, const struct FString& Title, TMap<struct FString, struct FString> ExtraInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoyGenerateMomentsVideo");

	UScriptHelperClient_GameJoyGenerateMomentsVideo_Params params;
	params.shortVideosTimeStampList = shortVideosTimeStampList;
	params.largeVideosTimeStampList = largeVideosTimeStampList;
	params.Title = Title;
	params.ExtraInfo = ExtraInfo;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoyEndMomentsRecord
// ()

void UScriptHelperClient::GameJoyEndMomentsRecord()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoyEndMomentsRecord");

	UScriptHelperClient_GameJoyEndMomentsRecord_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.GameJoyClearMomentsVideo
// ()

void UScriptHelperClient::GameJoyClearMomentsVideo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.GameJoyClearMomentsVideo");

	UScriptHelperClient_GameJoyClearMomentsVideo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.FullPathFileExist
// ()
// Parameters:
// struct FString                 Filename                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::FullPathFileExist(const struct FString& Filename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.FullPathFileExist");

	UScriptHelperClient_FullPathFileExist_Params params;
	params.Filename = Filename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.FlushKnownMissingPackageRefObject
// ()

void UScriptHelperClient::FlushKnownMissingPackageRefObject()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.FlushKnownMissingPackageRefObject");

	UScriptHelperClient_FlushKnownMissingPackageRefObject_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.FinishPufferUpdateInDolphin
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           IsFinished                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::FinishPufferUpdateInDolphin(class UGameFrontendHUD* GameFrontendHUD, bool IsFinished)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.FinishPufferUpdateInDolphin");

	UScriptHelperClient_FinishPufferUpdateInDolphin_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.IsFinished = IsFinished;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.FindFilesRecursiveSkipPakPlatform
// ()
// Parameters:
// struct FString                 Dir                            (Parm, ZeroConstructor)
// struct FString                 Pattern                        (Parm, ZeroConstructor)
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScriptHelperClient::FindFilesRecursiveSkipPakPlatform(const struct FString& Dir, const struct FString& Pattern)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.FindFilesRecursiveSkipPakPlatform");

	UScriptHelperClient_FindFilesRecursiveSkipPakPlatform_Params params;
	params.Dir = Dir;
	params.Pattern = Pattern;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.FindFiles_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::FindFiles_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.FindFiles_LuaState");

	UScriptHelperClient_FindFiles_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.FileSystemTesting
// ()
// Parameters:
// uint32_t                       Count                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::FileSystemTesting(uint32_t Count)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.FileSystemTesting");

	UScriptHelperClient_FileSystemTesting_Params params;
	params.Count = Count;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ExitGameForSafety
// ()

void UScriptHelperClient::ExitGameForSafety()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ExitGameForSafety");

	UScriptHelperClient_ExitGameForSafety_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ExitGame
// ()

void UScriptHelperClient::ExitGame()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ExitGame");

	UScriptHelperClient_ExitGame_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnterLoading
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnterLoading(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnterLoading");

	UScriptHelperClient_EnterLoading_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnterFightChat
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 gid                            (Parm, ZeroConstructor)

void UScriptHelperClient::EnterFightChat(class UGameFrontendHUD* GameFrontendHUD, const struct FString& gid)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnterFightChat");

	UScriptHelperClient_EnterFightChat_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.gid = gid;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnterBattleStandAlone
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 MapPath                        (Parm, ZeroConstructor)
// uint32_t                       PlayerKey                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 PlayerName                     (Parm, ZeroConstructor)

void UScriptHelperClient::EnterBattleStandAlone(class UGameFrontendHUD* GameFrontendHUD, const struct FString& MapPath, uint32_t PlayerKey, const struct FString& PlayerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnterBattleStandAlone");

	UScriptHelperClient_EnterBattleStandAlone_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.MapPath = MapPath;
	params.PlayerKey = PlayerKey;
	params.PlayerName = PlayerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnterBattle
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 HostnameOrIP                   (Parm, ZeroConstructor)
// uint32_t                       Port                           (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       PlayerKey                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 PlayerName                     (Parm, ZeroConstructor)
// struct FString                 PacketKey                      (Parm, ZeroConstructor)
// uint64_t                       GameID                         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           IsObserver                     (Parm, ZeroConstructor, IsPlainOldData)
// TMap<int, struct FString>      AdvConfig                      (Parm, ZeroConstructor)
// int                            WaterType                      (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       WaterUserID                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnterBattle(class UGameFrontendHUD* GameFrontendHUD, const struct FString& HostnameOrIP, uint32_t Port, uint32_t PlayerKey, const struct FString& PlayerName, const struct FString& PacketKey, uint64_t GameID, bool IsObserver, TMap<int, struct FString> AdvConfig, int WaterType, uint32_t WaterUserID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnterBattle");

	UScriptHelperClient_EnterBattle_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.HostnameOrIP = HostnameOrIP;
	params.Port = Port;
	params.PlayerKey = PlayerKey;
	params.PlayerName = PlayerName;
	params.PacketKey = PacketKey;
	params.GameID = GameID;
	params.IsObserver = IsObserver;
	params.AdvConfig = AdvConfig;
	params.WaterType = WaterType;
	params.WaterUserID = WaterUserID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EncryptUID
// ()
// Parameters:
// struct FString                 sUid                           (Parm, ZeroConstructor)
// struct FString                 sKey                           (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::EncryptUID(const struct FString& sUid, const struct FString& sKey)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EncryptUID");

	UScriptHelperClient_EncryptUID_Params params;
	params.sUid = sUid;
	params.sKey = sKey;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.EnableUseOldInterface
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableUseOldInterface(class UGameFrontendHUD* GameFrontendHUD, bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableUseOldInterface");

	UScriptHelperClient_EnableUseOldInterface_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableTxtCheck
// ()

void UScriptHelperClient::EnableTxtCheck()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableTxtCheck");

	UScriptHelperClient_EnableTxtCheck_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableReportGVoiceEvent
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GVoiceInitGVoiceComponentReportEnable (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GVoiceJoinRoomReportEnable     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GVoiceQuitRoomReportEnable     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GVoiceJoinLbsRoomReportEnable  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GVoiceQuitLbsRoomReportEnable  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GVoiceOnJoinTeamRoomReportEnable (Parm, ZeroConstructor, IsPlainOldData)
// bool                           GVoiceOnJoinLbsRoomReportEnable (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableReportGVoiceEvent(class UGameFrontendHUD* GameFrontendHUD, bool GVoiceInitGVoiceComponentReportEnable, bool GVoiceJoinRoomReportEnable, bool GVoiceQuitRoomReportEnable, bool GVoiceJoinLbsRoomReportEnable, bool GVoiceQuitLbsRoomReportEnable, bool GVoiceOnJoinTeamRoomReportEnable, bool GVoiceOnJoinLbsRoomReportEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableReportGVoiceEvent");

	UScriptHelperClient_EnableReportGVoiceEvent_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.GVoiceInitGVoiceComponentReportEnable = GVoiceInitGVoiceComponentReportEnable;
	params.GVoiceJoinRoomReportEnable = GVoiceJoinRoomReportEnable;
	params.GVoiceQuitRoomReportEnable = GVoiceQuitRoomReportEnable;
	params.GVoiceJoinLbsRoomReportEnable = GVoiceJoinLbsRoomReportEnable;
	params.GVoiceQuitLbsRoomReportEnable = GVoiceQuitLbsRoomReportEnable;
	params.GVoiceOnJoinTeamRoomReportEnable = GVoiceOnJoinTeamRoomReportEnable;
	params.GVoiceOnJoinLbsRoomReportEnable = GVoiceOnJoinLbsRoomReportEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableLocalizationStatus
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Status                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableLocalizationStatus(class UGameFrontendHUD* GameFrontendHUD, bool Status)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableLocalizationStatus");

	UScriptHelperClient_EnableLocalizationStatus_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Status = Status;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableIosStuckWork
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnable                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableIosStuckWork(class UGameFrontendHUD* GameFrontendHUD, bool bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableIosStuckWork");

	UScriptHelperClient_EnableIosStuckWork_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableGvoiceGemReport
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableGvoiceGemReport(class UGameFrontendHUD* GameFrontendHUD, bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableGvoiceGemReport");

	UScriptHelperClient_EnableGvoiceGemReport_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableGvoice
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableGvoice(class UGameFrontendHUD* GameFrontendHUD, bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableGvoice");

	UScriptHelperClient_EnableGvoice_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableCampGvoice
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableCampGvoice(class UGameFrontendHUD* GameFrontendHUD, bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableCampGvoice");

	UScriptHelperClient_EnableCampGvoice_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableAutoObjectRefreshStage
// ()
// Parameters:
// bool                           bEnable                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableAutoObjectRefreshStage(bool bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableAutoObjectRefreshStage");

	UScriptHelperClient_EnableAutoObjectRefreshStage_Params params;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.EnableAudioRouteChangedNotify
// ()
// Parameters:
// bool                           Enable                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::EnableAudioRouteChangedNotify(bool Enable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.EnableAudioRouteChangedNotify");

	UScriptHelperClient_EnableAudioRouteChangedNotify_Params params;
	params.Enable = Enable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.DumpOpenReadCollect
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 DumpFilename                   (Parm, ZeroConstructor)

void UScriptHelperClient::DumpOpenReadCollect(class UGameFrontendHUD* GameFrontendHUD, const struct FString& DumpFilename)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DumpOpenReadCollect");

	UScriptHelperClient_DumpOpenReadCollect_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.DumpFilename = DumpFilename;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.Disconnect
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::Disconnect(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.Disconnect");

	UScriptHelperClient_Disconnect_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.DisableRepairResource
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::DisableRepairResource(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DisableRepairResource");

	UScriptHelperClient_DisableRepairResource_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.DirectToSetting
// ()

void UScriptHelperClient::DirectToSetting()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DirectToSetting");

	UScriptHelperClient_DirectToSetting_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.DestroyConnector
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::DestroyConnector(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DestroyConnector");

	UScriptHelperClient_DestroyConnector_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.DeleteFile
// ()
// Parameters:
// struct FString                 fullPath                       (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::DeleteFile(const struct FString& fullPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DeleteFile");

	UScriptHelperClient_DeleteFile_Params params;
	params.fullPath = fullPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.DeleteDirectory
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)

void UScriptHelperClient::DeleteDirectory(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DeleteDirectory");

	UScriptHelperClient_DeleteDirectory_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.DelayToSetAutoInitFacebookLog
// ()
// Parameters:
// bool                           IsAutoInit                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::DelayToSetAutoInitFacebookLog(bool IsAutoInit)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DelayToSetAutoInitFacebookLog");

	UScriptHelperClient_DelayToSetAutoInitFacebookLog_Params params;
	params.IsAutoInit = IsAutoInit;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.DelayToInitFacebookSDK
// ()
// Parameters:
// bool                           IsAutoInit                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           WithLaunchOption               (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::DelayToInitFacebookSDK(bool IsAutoInit, bool WithLaunchOption)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DelayToInitFacebookSDK");

	UScriptHelperClient_DelayToInitFacebookSDK_Params params;
	params.IsAutoInit = IsAutoInit;
	params.WithLaunchOption = WithLaunchOption;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.DelayInitThirdPartSDK
// ()

void UScriptHelperClient::DelayInitThirdPartSDK()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.DelayInitThirdPartSDK");

	UScriptHelperClient_DelayInitThirdPartSDK_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CreateHapticsEngine
// ()
// Parameters:
// struct FScriptDelegate         Callback                       (Parm, ZeroConstructor)

void UScriptHelperClient::CreateHapticsEngine(const struct FScriptDelegate& Callback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CreateHapticsEngine");

	UScriptHelperClient_CreateHapticsEngine_Params params;
	params.Callback = Callback;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForWrite
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ConvertToAbsolutePathForExternalAppForWrite(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForWrite");

	UScriptHelperClient_ConvertToAbsolutePathForExternalAppForWrite_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForRead
// ()
// Parameters:
// struct FString                 FilePath                       (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ConvertToAbsolutePathForExternalAppForRead(const struct FString& FilePath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForRead");

	UScriptHelperClient_ConvertToAbsolutePathForExternalAppForRead_Params params;
	params.FilePath = FilePath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ConvertRelativePathToFull
// ()
// Parameters:
// struct FString                 InPath                         (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ConvertRelativePathToFull(const struct FString& InPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ConvertRelativePathToFull");

	UScriptHelperClient_ConvertRelativePathToFull_Params params;
	params.InPath = InPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ConvertGamePathToRelativeFilePath
// ()
// Parameters:
// struct FString                 Path                           (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ConvertGamePathToRelativeFilePath(const struct FString& Path)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ConvertGamePathToRelativeFilePath");

	UScriptHelperClient_ConvertGamePathToRelativeFilePath_Params params;
	params.Path = Path;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.ConnectToURL
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 URL                            (Parm, ZeroConstructor)
// int                            ConnectTimeOutSeconds          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ConnectToURL(const struct FString& URL, int ConnectTimeOutSeconds, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ConnectToURL");

	UScriptHelperClient_ConnectToURL_Params params;
	params.URL = URL;
	params.ConnectTimeOutSeconds = ConnectTimeOutSeconds;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.ComputerName
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::ComputerName()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ComputerName");

	UScriptHelperClient_ComputerName_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.CloseWebView
// ()

void UScriptHelperClient::CloseWebView()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CloseWebView");

	UScriptHelperClient_CloseWebView_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CloseVLink
// ()

void UScriptHelperClient::CloseVLink()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CloseVLink");

	UScriptHelperClient_CloseVLink_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CloseVideoListDialog
// ()

void UScriptHelperClient::CloseVideoListDialog()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CloseVideoListDialog");

	UScriptHelperClient_CloseVideoListDialog_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CloseH5WebView
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::CloseH5WebView(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CloseH5WebView");

	UScriptHelperClient_CloseH5WebView_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClipBoardCopy
// ()
// Parameters:
// struct FString                 Text                           (Parm, ZeroConstructor)

void UScriptHelperClient::ClipBoardCopy(const struct FString& Text)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClipBoardCopy");

	UScriptHelperClient_ClipBoardCopy_Params params;
	params.Text = Text;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClientKickPlayerFromGame
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ClientKickPlayerFromGame(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClientKickPlayerFromGame");

	UScriptHelperClient_ClientKickPlayerFromGame_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClientEnterWarMode
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ClientEnterWarMode(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClientEnterWarMode");

	UScriptHelperClient_ClientEnterWarMode_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClientConfirmReturnToGame
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ClientConfirmReturnToGame(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClientConfirmReturnToGame");

	UScriptHelperClient_ClientConfirmReturnToGame_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClientConfirmMisKill
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            bConfirm                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ClientConfirmMisKill(class UGameFrontendHUD* GameFrontendHUD, int bConfirm)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClientConfirmMisKill");

	UScriptHelperClient_ClientConfirmMisKill_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bConfirm = bConfirm;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClearUpdatedSoPatch
// ()

void UScriptHelperClient::ClearUpdatedSoPatch()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClearUpdatedSoPatch");

	UScriptHelperClient_ClearUpdatedSoPatch_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClearNotifications
// ()

void UScriptHelperClient::ClearNotifications()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClearNotifications");

	UScriptHelperClient_ClearNotifications_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClearNotice
// ()

void UScriptHelperClient::ClearNotice()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClearNotice");

	UScriptHelperClient_ClearNotice_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ClearChannelID
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ClearChannelID(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClearChannelID");

	UScriptHelperClient_ClearChannelID_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.ClearAllLocalNotifications
// ()

void UScriptHelperClient::ClearAllLocalNotifications()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ClearAllLocalNotifications");

	UScriptHelperClient_ClearAllLocalNotifications_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CheckRegisterGestureConflictWithZoom
// ()

void UScriptHelperClient::CheckRegisterGestureConflictWithZoom()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CheckRegisterGestureConflictWithZoom");

	UScriptHelperClient_CheckRegisterGestureConflictWithZoom_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CheckFilesInPak
// ()
// Parameters:
// TArray<struct FString>         Files                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FString>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FString> UScriptHelperClient::CheckFilesInPak(TArray<struct FString> Files)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CheckFilesInPak");

	UScriptHelperClient_CheckFilesInPak_Params params;
	params.Files = Files;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.CheckBeforeInitPuffer
// ()

void UScriptHelperClient::CheckBeforeInitPuffer()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CheckBeforeInitPuffer");

	UScriptHelperClient_CheckBeforeInitPuffer_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.ChangeLocalizationReleaseTestStatus
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Status                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::ChangeLocalizationReleaseTestStatus(class UGameFrontendHUD* GameFrontendHUD, bool Status)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.ChangeLocalizationReleaseTestStatus");

	UScriptHelperClient_ChangeLocalizationReleaseTestStatus_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Status = Status;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CanUseHapticsEngine
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::CanUseHapticsEngine()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CanUseHapticsEngine");

	UScriptHelperClient_CanUseHapticsEngine_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.CancelLocalNotification
// ()
// Parameters:
// int                            NotificationID                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::CancelLocalNotification(int NotificationID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CancelLocalNotification");

	UScriptHelperClient_CancelLocalNotification_Params params;
	params.NotificationID = NotificationID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CallIngameFirstTimeTips
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 tableName                      (Parm, ZeroConstructor)
// struct FString                 FunctionName                   (Parm, ZeroConstructor)

void UScriptHelperClient::CallIngameFirstTimeTips(class UGameFrontendHUD* GameFrontendHUD, const struct FString& tableName, const struct FString& FunctionName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CallIngameFirstTimeTips");

	UScriptHelperClient_CallIngameFirstTimeTips_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.tableName = tableName;
	params.FunctionName = FunctionName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CallEngineGC
// ()

void UScriptHelperClient::CallEngineGC()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CallEngineGC");

	UScriptHelperClient_CallEngineGC_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.CacheH5WebView
// ()
// Parameters:
// struct FString                 ModuleName                     (Parm, ZeroConstructor)

void UScriptHelperClient::CacheH5WebView(const struct FString& ModuleName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.CacheH5WebView");

	UScriptHelperClient_CacheH5WebView_Params params;
	params.ModuleName = ModuleName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.BuglySetAppVersion
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 Version                        (Parm, ZeroConstructor)

void UScriptHelperClient::BuglySetAppVersion(const struct FString& Version, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.BuglySetAppVersion");

	UScriptHelperClient_BuglySetAppVersion_Params params;
	params.Version = Version;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.BuglyPutUserData
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FString                 Key                            (Parm, ZeroConstructor)
// struct FString                 Value                          (Parm, ZeroConstructor)

void UScriptHelperClient::BuglyPutUserData(const struct FString& Key, const struct FString& Value, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.BuglyPutUserData");

	UScriptHelperClient_BuglyPutUserData_Params params;
	params.Key = Key;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.BuglyPostException
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            Category                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Reason                         (Parm, ZeroConstructor)

void UScriptHelperClient::BuglyPostException(int Category, const struct FString& Reason, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.BuglyPostException");

	UScriptHelperClient_BuglyPostException_Params params;
	params.Category = Category;
	params.Reason = Reason;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.BuglyLog
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            Level                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Tag                            (Parm, ZeroConstructor)
// struct FString                 Log                            (Parm, ZeroConstructor)
// bool                           needDump                       (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::BuglyLog(int Level, const struct FString& Tag, const struct FString& Log, bool needDump, TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.BuglyLog");

	UScriptHelperClient_BuglyLog_Params params;
	params.Level = Level;
	params.Tag = Tag;
	params.Log = Log;
	params.needDump = needDump;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.AutoTestWaitForUIWithName
// ()
// Parameters:
// struct FString                 UIName                         (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestWaitForUIWithName(const struct FString& UIName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestWaitForUIWithName");

	UScriptHelperClient_AutoTestWaitForUIWithName_Params params;
	params.UIName = UIName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestWaitForSecond
// ()
// Parameters:
// int                            sec                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestWaitForSecond(int sec)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestWaitForSecond");

	UScriptHelperClient_AutoTestWaitForSecond_Params params;
	params.sec = sec;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestWaitForJumpPlane
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::AutoTestWaitForJumpPlane()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestWaitForJumpPlane");

	UScriptHelperClient_AutoTestWaitForJumpPlane_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestVehicleDriverShoot
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestVehicleDriverShoot(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestVehicleDriverShoot");

	UScriptHelperClient_AutoTestVehicleDriverShoot_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestVaultWall
// ()

void UScriptHelperClient::AutoTestVaultWall()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestVaultWall");

	UScriptHelperClient_AutoTestVaultWall_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestUsePropSkillClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestUsePropSkillClientEx(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestUsePropSkillClientEx");

	UScriptHelperClient_AutoTestUsePropSkillClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestUseItemClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ItemId                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestUseItemClientEx(class UGameFrontendHUD* GameFrontendHUD, int ItemId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestUseItemClientEx");

	UScriptHelperClient_AutoTestUseItemClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ItemId = ItemId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestUseItem
// ()
// Parameters:
// int                            ItemId                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestUseItem(int ItemId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestUseItem");

	UScriptHelperClient_AutoTestUseItem_Params params;
	params.ItemId = ItemId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestUpgradePropSkillClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ItemId                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestUpgradePropSkillClientEx(class UGameFrontendHUD* GameFrontendHUD, int ItemId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestUpgradePropSkillClientEx");

	UScriptHelperClient_AutoTestUpgradePropSkillClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ItemId = ItemId;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestToggleVehicleSync
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Val                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestToggleVehicleSync(class UGameFrontendHUD* GameFrontendHUD, bool Val)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestToggleVehicleSync");

	UScriptHelperClient_AutoTestToggleVehicleSync_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.Val = Val;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestThrowBoomOnlyClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            SkillID                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestThrowBoomOnlyClientEx(class UGameFrontendHUD* GameFrontendHUD, int SkillID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestThrowBoomOnlyClientEx");

	UScriptHelperClient_AutoTestThrowBoomOnlyClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.SkillID = SkillID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestThrowBoom
// ()
// Parameters:
// int                            SkillID                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestThrowBoom(int SkillID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestThrowBoom");

	UScriptHelperClient_AutoTestThrowBoom_Params params;
	params.SkillID = SkillID;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSwitchWeapon
// ()
// Parameters:
// int                            WeaponType                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSwitchWeapon(int WeaponType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSwitchWeapon");

	UScriptHelperClient_AutoTestSwitchWeapon_Params params;
	params.WeaponType = WeaponType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSwitchMode
// ()
// Parameters:
// struct FString                 FunName                        (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestSwitchMode(const struct FString& FunName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSwitchMode");

	UScriptHelperClient_AutoTestSwitchMode_Params params;
	params.FunName = FunName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSwitchGameStatus
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   GameStatus                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Options                        (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestSwitchGameStatus(class UGameFrontendHUD* GameFrontendHUD, const struct FName& GameStatus, const struct FString& Options)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSwitchGameStatus");

	UScriptHelperClient_AutoTestSwitchGameStatus_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.GameStatus = GameStatus;
	params.Options = Options;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestStopRecordStats
// ()

void UScriptHelperClient::AutoTestStopRecordStats()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestStopRecordStats");

	UScriptHelperClient_AutoTestStopRecordStats_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestStartRecordStats
// ()
// Parameters:
// struct FString                 FileStr                        (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestStartRecordStats(const struct FString& FileStr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestStartRecordStats");

	UScriptHelperClient_AutoTestStartRecordStats_Params params;
	params.FileStr = FileStr;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestStartFireOnlyClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            sec                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestStartFireOnlyClientEx(class UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z, int sec)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestStartFireOnlyClientEx");

	UScriptHelperClient_AutoTestStartFireOnlyClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.X = X;
	params.Y = Y;
	params.Z = Z;
	params.sec = sec;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestStartFire
// ()
// Parameters:
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            sec                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestStartFire(int X, int Y, int Z, int sec)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestStartFire");

	UScriptHelperClient_AutoTestStartFire_Params params;
	params.X = X;
	params.Y = Y;
	params.Z = Z;
	params.sec = sec;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSpecating
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            leftTeamCnt                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSpecating(class UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSpecating");

	UScriptHelperClient_AutoTestSpecating_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.leftTeamCnt = leftTeamCnt;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSpawnVehicle
// ()
// Parameters:
// struct FString                 ResPath                        (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestSpawnVehicle(const struct FString& ResPath)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSpawnVehicle");

	UScriptHelperClient_AutoTestSpawnVehicle_Params params;
	params.ResPath = ResPath;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSetVehicleRotation
// ()
// Parameters:
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSetVehicleRotation(int X, int Y, int Z)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSetVehicleRotation");

	UScriptHelperClient_AutoTestSetVehicleRotation_Params params;
	params.X = X;
	params.Y = Y;
	params.Z = Z;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSetRecordFrequency
// ()
// Parameters:
// uint32_t                       Frequency                      (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSetRecordFrequency(uint32_t Frequency)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSetRecordFrequency");

	UScriptHelperClient_AutoTestSetRecordFrequency_Params params;
	params.Frequency = Frequency;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSetActorRotation
// ()
// Parameters:
// float                          Rate                           (Parm, ZeroConstructor, IsPlainOldData)
// float                          Speed                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSetActorRotation(float Rate, float Speed)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSetActorRotation");

	UScriptHelperClient_AutoTestSetActorRotation_Params params;
	params.Rate = Rate;
	params.Speed = Speed;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSetActorPitch
// ()
// Parameters:
// float                          Rate                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSetActorPitch(float Rate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSetActorPitch");

	UScriptHelperClient_AutoTestSetActorPitch_Params params;
	params.Rate = Rate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSetActorFacePoint
// ()
// Parameters:
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSetActorFacePoint(int X, int Y, int Z)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSetActorFacePoint");

	UScriptHelperClient_AutoTestSetActorFacePoint_Params params;
	params.X = X;
	params.Y = Y;
	params.Z = Z;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestSendBuffertoSvr
// ()
// Parameters:
// TScriptInterface<class UClientNetInterface> ClientNetInterface             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestSendBuffertoSvr(TScriptInterface<class UClientNetInterface>* ClientNetInterface)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestSendBuffertoSvr");

	UScriptHelperClient_AutoTestSendBuffertoSvr_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ClientNetInterface != nullptr)
		*ClientNetInterface = params.ClientNetInterface;
}


// Function Client.ScriptHelperClient.AutoTestReloadOnlyClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestReloadOnlyClientEx(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestReloadOnlyClientEx");

	UScriptHelperClient_AutoTestReloadOnlyClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestPickupItemOnlyClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D UScriptHelperClient::AutoTestPickupItemOnlyClientEx(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestPickupItemOnlyClientEx");

	UScriptHelperClient_AutoTestPickupItemOnlyClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestPickupItem
// ()
// Parameters:
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D UScriptHelperClient::AutoTestPickupItem()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestPickupItem");

	UScriptHelperClient_AutoTestPickupItem_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestOpenTraceRPC
// ()

void UScriptHelperClient::AutoTestOpenTraceRPC()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestOpenTraceRPC");

	UScriptHelperClient_AutoTestOpenTraceRPC_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestOpenScope
// ()
// Parameters:
// bool                           bOpenScope                     (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestOpenScope(bool bOpenScope)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestOpenScope");

	UScriptHelperClient_AutoTestOpenScope_Params params;
	params.bOpenScope = bOpenScope;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestOpenDoorOnlyClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            bOpen                          (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestOpenDoorOnlyClientEx(class UGameFrontendHUD* GameFrontendHUD, int bOpen)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestOpenDoorOnlyClientEx");

	UScriptHelperClient_AutoTestOpenDoorOnlyClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bOpen = bOpen;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestMustDie
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            leftTeamCnt                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestMustDie(class UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestMustDie");

	UScriptHelperClient_AutoTestMustDie_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.leftTeamCnt = leftTeamCnt;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestMoveVehicleForward
// ()
// Parameters:
// float                          Speed                          (Parm, ZeroConstructor, IsPlainOldData)
// float                          Rate                           (Parm, ZeroConstructor, IsPlainOldData)
// float                          sec                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestMoveVehicleForward(float Speed, float Rate, float sec)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestMoveVehicleForward");

	UScriptHelperClient_AutoTestMoveVehicleForward_Params params;
	params.Speed = Speed;
	params.Rate = Rate;
	params.sec = sec;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestMoveToPoint
// ()
// Parameters:
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestMoveToPoint(int X, int Y, int Z)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestMoveToPoint");

	UScriptHelperClient_AutoTestMoveToPoint_Params params;
	params.X = X;
	params.Y = Y;
	params.Z = Z;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestJumpPlane
// ()
// Parameters:
// int                            sec                            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestJumpPlane(int sec)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestJumpPlane");

	UScriptHelperClient_AutoTestJumpPlane_Params params;
	params.sec = sec;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestJump
// ()

void UScriptHelperClient::AutoTestJump()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestJump");

	UScriptHelperClient_AutoTestJump_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestIsOnVehicle
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::AutoTestIsOnVehicle(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestIsOnVehicle");

	UScriptHelperClient_AutoTestIsOnVehicle_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestIsDriver
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::AutoTestIsDriver(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestIsDriver");

	UScriptHelperClient_AutoTestIsDriver_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestInputMovement
// ()
// Parameters:
// float                          Rate                           (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestInputMovement(float Rate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestInputMovement");

	UScriptHelperClient_AutoTestInputMovement_Params params;
	params.Rate = Rate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGMVehicleMoveAndTowardClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// float                          X                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Y                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Z                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          x1                             (Parm, ZeroConstructor, IsPlainOldData)
// float                          y1                             (Parm, ZeroConstructor, IsPlainOldData)
// float                          Z1                             (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestGMVehicleMoveAndTowardClientEx(class UGameFrontendHUD* GameFrontendHUD, float X, float Y, float Z, float x1, float y1, float Z1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGMVehicleMoveAndTowardClientEx");

	UScriptHelperClient_AutoTestGMVehicleMoveAndTowardClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.X = X;
	params.Y = Y;
	params.Z = Z;
	params.x1 = x1;
	params.y1 = y1;
	params.Z1 = Z1;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGMGotoClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestGMGotoClientEx(class UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGMGotoClientEx");

	UScriptHelperClient_AutoTestGMGotoClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.X = X;
	params.Y = Y;
	params.Z = Z;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGMGoto
// ()
// Parameters:
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestGMGoto(int X, int Y, int Z)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGMGoto");

	UScriptHelperClient_AutoTestGMGoto_Params params;
	params.X = X;
	params.Y = Y;
	params.Z = Z;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGMCommand
// ()
// Parameters:
// struct FString                 Command                        (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestGMCommand(const struct FString& Command)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGMCommand");

	UScriptHelperClient_AutoTestGMCommand_Params params;
	params.Command = Command;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGetVehicleLocationClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector UScriptHelperClient::AutoTestGetVehicleLocationClientEx(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetVehicleLocationClientEx");

	UScriptHelperClient_AutoTestGetVehicleLocationClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetVehicleLocation
// ()
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector UScriptHelperClient::AutoTestGetVehicleLocation()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetVehicleLocation");

	UScriptHelperClient_AutoTestGetVehicleLocation_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetRuntimeStats
// ()

void UScriptHelperClient::AutoTestGetRuntimeStats()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetRuntimeStats");

	UScriptHelperClient_AutoTestGetRuntimeStats_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGetOnVehicle
// ()

void UScriptHelperClient::AutoTestGetOnVehicle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetOnVehicle");

	UScriptHelperClient_AutoTestGetOnVehicle_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGetOffVehicle
// ()

void UScriptHelperClient::AutoTestGetOffVehicle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetOffVehicle");

	UScriptHelperClient_AutoTestGetOffVehicle_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestGetNearVehiclePos
// ()
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector UScriptHelperClient::AutoTestGetNearVehiclePos()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetNearVehiclePos");

	UScriptHelperClient_AutoTestGetNearVehiclePos_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetMapName
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::AutoTestGetMapName()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetMapName");

	UScriptHelperClient_AutoTestGetMapName_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetGameModeState
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::AutoTestGetGameModeState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetGameModeState");

	UScriptHelperClient_AutoTestGetGameModeState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetFrameInfo
// ()
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector UScriptHelperClient::AutoTestGetFrameInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetFrameInfo");

	UScriptHelperClient_AutoTestGetFrameInfo_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetDis2D
// ()
// Parameters:
// int                            X                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Y                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            Z                              (Parm, ZeroConstructor, IsPlainOldData)
// int                            x2                             (Parm, ZeroConstructor, IsPlainOldData)
// int                            y2                             (Parm, ZeroConstructor, IsPlainOldData)
// int                            z2                             (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UScriptHelperClient::AutoTestGetDis2D(int X, int Y, int Z, int x2, int y2, int z2)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetDis2D");

	UScriptHelperClient_AutoTestGetDis2D_Params params;
	params.X = X;
	params.Y = Y;
	params.Z = Z;
	params.x2 = x2;
	params.y2 = y2;
	params.z2 = z2;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetCircleLocationClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector UScriptHelperClient::AutoTestGetCircleLocationClientEx(class UGameFrontendHUD* GameFrontendHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetCircleLocationClientEx");

	UScriptHelperClient_AutoTestGetCircleLocationClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetActorName
// ()
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperClient::AutoTestGetActorName()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetActorName");

	UScriptHelperClient_AutoTestGetActorName_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetActorLocationListClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ActorType                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeRadius                    (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FVector>         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FVector> UScriptHelperClient::AutoTestGetActorLocationListClientEx(class UGameFrontendHUD* GameFrontendHUD, int ActorType, float RangeRadius)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetActorLocationListClientEx");

	UScriptHelperClient_AutoTestGetActorLocationListClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ActorType = ActorType;
	params.RangeRadius = RangeRadius;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestGetActorLocation
// ()
// Parameters:
// struct FString                 PlayerName                     (Parm, ZeroConstructor)
// struct FVector                 ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector UScriptHelperClient::AutoTestGetActorLocation(const struct FString& PlayerName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestGetActorLocation");

	UScriptHelperClient_AutoTestGetActorLocation_Params params;
	params.PlayerName = PlayerName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestForceVehiclePosPullClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bNext                          (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UScriptHelperClient::AutoTestForceVehiclePosPullClientEx(class UGameFrontendHUD* GameFrontendHUD, bool bNext)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestForceVehiclePosPullClientEx");

	UScriptHelperClient_AutoTestForceVehiclePosPullClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.bNext = bNext;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AutoTestEnableUITest
// ()

void UScriptHelperClient::AutoTestEnableUITest()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestEnableUITest");

	UScriptHelperClient_AutoTestEnableUITest_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestDropItemClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ItemId                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            nCount                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestDropItemClientEx(class UGameFrontendHUD* GameFrontendHUD, int ItemId, int nCount)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestDropItemClientEx");

	UScriptHelperClient_AutoTestDropItemClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ItemId = ItemId;
	params.nCount = nCount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestContinuousMoveTo
// ()
// Parameters:
// float                          X                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Y                              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Z                              (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestContinuousMoveTo(float X, float Y, float Z)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestContinuousMoveTo");

	UScriptHelperClient_AutoTestContinuousMoveTo_Params params;
	params.X = X;
	params.Y = Y;
	params.Z = Z;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestConsoleCommand
// ()
// Parameters:
// struct FString                 Command                        (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestConsoleCommand(const struct FString& Command)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestConsoleCommand");

	UScriptHelperClient_AutoTestConsoleCommand_Params params;
	params.Command = Command;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestCloseTraceRPC
// ()

void UScriptHelperClient::AutoTestCloseTraceRPC()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestCloseTraceRPC");

	UScriptHelperClient_AutoTestCloseTraceRPC_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestClickButton
// ()
// Parameters:
// struct FString                 ButtonName                     (Parm, ZeroConstructor)

void UScriptHelperClient::AutoTestClickButton(const struct FString& ButtonName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestClickButton");

	UScriptHelperClient_AutoTestClickButton_Params params;
	params.ButtonName = ButtonName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestAddItemClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ItemId                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            nCount                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestAddItemClientEx(class UGameFrontendHUD* GameFrontendHUD, int ItemId, int nCount)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestAddItemClientEx");

	UScriptHelperClient_AutoTestAddItemClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.ItemId = ItemId;
	params.nCount = nCount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoTestAddItem
// ()
// Parameters:
// int                            ItemId                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            nCount                         (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AutoTestAddItem(int ItemId, int nCount)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoTestAddItem");

	UScriptHelperClient_AutoTestAddItem_Params params;
	params.ItemId = ItemId;
	params.nCount = nCount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AutoMoveToTargetPosClientEx
// ()
// Parameters:
// class UGameFrontendHUD*        GameFrontendHUD                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 targetPos                      (Parm, IsPlainOldData)

void UScriptHelperClient::AutoMoveToTargetPosClientEx(class UGameFrontendHUD* GameFrontendHUD, const struct FVector& targetPos)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AutoMoveToTargetPosClientEx");

	UScriptHelperClient_AutoMoveToTargetPosClientEx_Params params;
	params.GameFrontendHUD = GameFrontendHUD;
	params.targetPos = targetPos;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AskForNotificationPermission
// ()

void UScriptHelperClient::AskForNotificationPermission()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AskForNotificationPermission");

	UScriptHelperClient_AskForNotificationPermission_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AndroidShouldShowPermissionRationale
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::AndroidShouldShowPermissionRationale()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AndroidShouldShowPermissionRationale");

	UScriptHelperClient_AndroidShouldShowPermissionRationale_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AndroidCheckPermission
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperClient::AndroidCheckPermission()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AndroidCheckPermission");

	UScriptHelperClient_AndroidCheckPermission_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperClient.AkAudio_UnloadInitBank
// ()

void UScriptHelperClient::AkAudio_UnloadInitBank()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AkAudio_UnloadInitBank");

	UScriptHelperClient_AkAudio_UnloadInitBank_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AkAudio_UnloadAllFilePackages
// ()

void UScriptHelperClient::AkAudio_UnloadAllFilePackages()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AkAudio_UnloadAllFilePackages");

	UScriptHelperClient_AkAudio_UnloadAllFilePackages_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AkAudio_StopAllSounds
// ()
// Parameters:
// bool                           bShouldStopUISounds            (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AkAudio_StopAllSounds(bool bShouldStopUISounds)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AkAudio_StopAllSounds");

	UScriptHelperClient_AkAudio_StopAllSounds_Params params;
	params.bShouldStopUISounds = bShouldStopUISounds;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AkAudio_LoadInitBank
// ()

void UScriptHelperClient::AkAudio_LoadInitBank()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AkAudio_LoadInitBank");

	UScriptHelperClient_AkAudio_LoadInitBank_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AkAudio_Flush
// ()
// Parameters:
// class UWorld*                  WorldToFlush                   (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AkAudio_Flush(class UWorld* WorldToFlush)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AkAudio_Flush");

	UScriptHelperClient_AkAudio_Flush_Params params;
	params.WorldToFlush = WorldToFlush;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AkAudio_ClearBanks
// ()

void UScriptHelperClient::AkAudio_ClearBanks()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AkAudio_ClearBanks");

	UScriptHelperClient_AkAudio_ClearBanks_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AddKnownMissingPackage
// ()
// Parameters:
// struct FString                 PackageName                    (Parm, ZeroConstructor)
// class UObject*                 BindObj                        (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AddKnownMissingPackage(const struct FString& PackageName, class UObject* BindObj)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AddKnownMissingPackage");

	UScriptHelperClient_AddKnownMissingPackage_Params params;
	params.PackageName = PackageName;
	params.BindObj = BindObj;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AddCrashContextData
// ()
// Parameters:
// int                            Key                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Val                            (Parm, ZeroConstructor)
// bool                           bAppendTimeStamp               (Parm, ZeroConstructor, IsPlainOldData)
// int                            reportLevel                    (Parm, ZeroConstructor, IsPlainOldData)

void UScriptHelperClient::AddCrashContextData(int Key, const struct FString& Val, bool bAppendTimeStamp, int reportLevel)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AddCrashContextData");

	UScriptHelperClient_AddCrashContextData_Params params;
	params.Key = Key;
	params.Val = Val;
	params.bAppendTimeStamp = bAppendTimeStamp;
	params.reportLevel = reportLevel;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ScriptHelperClient.AddAttachFileString
// ()
// Parameters:
// struct FString                 Type                           (Parm, ZeroConstructor)
// bool                           bClear                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 strinfo                        (Parm, OutParm, ZeroConstructor)

void UScriptHelperClient::AddAttachFileString(const struct FString& Type, bool bClear, struct FString* strinfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperClient.AddAttachFileString");

	UScriptHelperClient_AddAttachFileString_Params params;
	params.Type = Type;
	params.bClear = bClear;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (strinfo != nullptr)
		*strinfo = params.strinfo;
}


// Function Client.ScriptHelperEngine.TestLz4Decompress
// ()
// Parameters:
// TArray<unsigned char>          Source                         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           bEnable                        (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<unsigned char> UScriptHelperEngine::TestLz4Decompress(TArray<unsigned char> Source, bool bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperEngine.TestLz4Decompress");

	UScriptHelperEngine_TestLz4Decompress_Params params;
	params.Source = Source;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperEngine.TestLz4Compress
// ()
// Parameters:
// TArray<unsigned char>          Source                         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<unsigned char>          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<unsigned char> UScriptHelperEngine::TestLz4Compress(TArray<unsigned char> Source)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperEngine.TestLz4Compress");

	UScriptHelperEngine_TestLz4Compress_Params params;
	params.Source = Source;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperEngine.ReplaceEmoji
// ()
// Parameters:
// struct FString                 Content                        (Parm, ZeroConstructor)
// int                            MaxEmojiNum                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 SpecialCharacter               (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UScriptHelperEngine::ReplaceEmoji(const struct FString& Content, int MaxEmojiNum, const struct FString& SpecialCharacter)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperEngine.ReplaceEmoji");

	UScriptHelperEngine_ReplaceEmoji_Params params;
	params.Content = Content;
	params.MaxEmojiNum = MaxEmojiNum;
	params.SpecialCharacter = SpecialCharacter;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperEngine.IsLowMemoryDevice
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UScriptHelperEngine::IsLowMemoryDevice()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperEngine.IsLowMemoryDevice");

	UScriptHelperEngine_IsLowMemoryDevice_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperEngine.GetMemoryUsedVirtualInKB
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UScriptHelperEngine::GetMemoryUsedVirtualInKB()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperEngine.GetMemoryUsedVirtualInKB");

	UScriptHelperEngine_GetMemoryUsedVirtualInKB_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ScriptHelperEngine.GetMemoryUsedPhysicalInKB
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UScriptHelperEngine::GetMemoryUsedPhysicalInKB()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ScriptHelperEngine.GetMemoryUsedPhysicalInKB");

	UScriptHelperEngine_GetMemoryUsedPhysicalInKB_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.SDKCallbackHelper.Init
// ()

void USDKCallbackHelper::Init()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.SDKCallbackHelper.Init");

	USDKCallbackHelper_Init_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.SDKCallbackHelper.GetInstance
// ()
// Parameters:
// class USDKCallbackHelper*      ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class USDKCallbackHelper* USDKCallbackHelper::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.SDKCallbackHelper.GetInstance");

	USDKCallbackHelper_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.STExtraClientUtils.GetWidgetHandleAsyncWithCallBack
// ()
// Parameters:
// class UObject*                 WorldContext                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ModuleName                     (Parm, ZeroConstructor)
// struct FString                 WidgetKey                      (Parm, ZeroConstructor)
// struct FScriptDelegate         Callback                       (Parm, ZeroConstructor)

void USTExtraClientUtils::GetWidgetHandleAsyncWithCallBack(class UObject* WorldContext, const struct FString& ModuleName, const struct FString& WidgetKey, const struct FScriptDelegate& Callback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.STExtraClientUtils.GetWidgetHandleAsyncWithCallBack");

	USTExtraClientUtils_GetWidgetHandleAsyncWithCallBack_Params params;
	params.WorldContext = WorldContext;
	params.ModuleName = ModuleName;
	params.WidgetKey = WidgetKey;
	params.Callback = Callback;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.STExtraClientUtils.GetDynamicWidgetHandle
// ()
// Parameters:
// class UObject*                 WorldContext                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ModuleName                     (Parm, ZeroConstructor)
// struct FString                 WidetKey                       (Parm, ZeroConstructor)
// class UUAEUserWidget*          ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UUAEUserWidget* USTExtraClientUtils::GetDynamicWidgetHandle(class UObject* WorldContext, const struct FString& ModuleName, const struct FString& WidetKey)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.STExtraClientUtils.GetDynamicWidgetHandle");

	USTExtraClientUtils_GetDynamicWidgetHandle_Params params;
	params.WorldContext = WorldContext;
	params.ModuleName = ModuleName;
	params.WidetKey = WidetKey;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.STExtraClientUtils.GetBPUtils
// ()
// Parameters:
// class USTExtraClientUIBPUtils* ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class USTExtraClientUIBPUtils* USTExtraClientUtils::GetBPUtils()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.STExtraClientUtils.GetBPUtils");

	USTExtraClientUtils_GetBPUtils_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.STExtraClientUtils.AsyncLoadAssetInstWithCallback
// ()
// Parameters:
// struct FString                 InPath                         (Parm, ZeroConstructor)
// struct FScriptDelegate         Callback                       (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int USTExtraClientUtils::AsyncLoadAssetInstWithCallback(const struct FString& InPath, const struct FScriptDelegate& Callback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.STExtraClientUtils.AsyncLoadAssetInstWithCallback");

	USTExtraClientUtils_AsyncLoadAssetInstWithCallback_Params params;
	params.InPath = InPath;
	params.Callback = Callback;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.STExtraClientUIBPUtils.OnAsyncAssetLoaded
// ()
// Parameters:
// struct FSoftObjectPath         InSoftPath                     (Parm)
// int                            RequestIdx                     (Parm, ZeroConstructor, IsPlainOldData)

void USTExtraClientUIBPUtils::OnAsyncAssetLoaded(const struct FSoftObjectPath& InSoftPath, int RequestIdx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.STExtraClientUIBPUtils.OnAsyncAssetLoaded");

	USTExtraClientUIBPUtils_OnAsyncAssetLoaded_Params params;
	params.InSoftPath = InSoftPath;
	params.RequestIdx = RequestIdx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.STExtraClientUIBPUtils.AsyncLoadAssetInstWithCallback
// ()
// Parameters:
// struct FString                 InPath                         (Parm, ZeroConstructor)
// struct FScriptDelegate         Callback                       (Parm, ZeroConstructor)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int USTExtraClientUIBPUtils::AsyncLoadAssetInstWithCallback(const struct FString& InPath, const struct FScriptDelegate& Callback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.STExtraClientUIBPUtils.AsyncLoadAssetInstWithCallback");

	USTExtraClientUIBPUtils_AsyncLoadAssetInstWithCallback_Params params;
	params.InPath = InPath;
	params.Callback = Callback;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.Translator.TranslateV2
// ()
// Parameters:
// int                            Channel                        (Parm, ZeroConstructor, IsPlainOldData)
// int                            ID                             (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Text                           (Parm, ZeroConstructor)

void UTranslator::TranslateV2(int Channel, int ID, const struct FString& Text)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.TranslateV2");

	UTranslator_TranslateV2_Params params;
	params.Channel = Channel;
	params.ID = ID;
	params.Text = Text;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.Translate
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// struct FString                 Verb                           (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> Headers                        (ConstParm, Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UTranslator::Translate(const struct FString& URL, const struct FString& Verb, TMap<struct FString, struct FString> Headers, const struct FString& Content)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.Translate");

	UTranslator_Translate_Params params;
	params.URL = URL;
	params.Verb = Verb;
	params.Headers = Headers;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.PostMsg
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UTranslator::PostMsg(const struct FString& URL, const struct FString& Content)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.PostMsg");

	UTranslator_PostMsg_Params params;
	params.URL = URL;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.OnTranslateV2
// ()
// Parameters:
// bool                           Success                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Data                           (Parm, ZeroConstructor)

void UTranslator::OnTranslateV2(bool Success, const struct FString& Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.OnTranslateV2");

	UTranslator_OnTranslateV2_Params params;
	params.Success = Success;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.Translator.OnTranslate__DelegateSignature
// ()
// Parameters:
// bool                           IsSuccess                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 LanguageFrom                   (Parm, ZeroConstructor)
// struct FString                 Translation                    (Parm, ZeroConstructor)

void UTranslator::OnTranslate__DelegateSignature(bool IsSuccess, const struct FString& LanguageFrom, const struct FString& Translation)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.Translator.OnTranslate__DelegateSignature");

	UTranslator_OnTranslate__DelegateSignature_Params params;
	params.IsSuccess = IsSuccess;
	params.LanguageFrom = LanguageFrom;
	params.Translation = Translation;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.OnTranslate
// ()
// Parameters:
// bool                           Success                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Data                           (Parm, ZeroConstructor)

void UTranslator::OnTranslate(bool Success, const struct FString& Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.OnTranslate");

	UTranslator_OnTranslate_Params params;
	params.Success = Success;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.OnGetAccessTokenV2
// ()
// Parameters:
// bool                           Success                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Data                           (Parm, ZeroConstructor)

void UTranslator::OnGetAccessTokenV2(bool Success, const struct FString& Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.OnGetAccessTokenV2");

	UTranslator_OnGetAccessTokenV2_Params params;
	params.Success = Success;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.Translator.OnGetAccessToken__DelegateSignature
// ()
// Parameters:
// bool                           IsSuccess                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Token                          (Parm, ZeroConstructor)

void UTranslator::OnGetAccessToken__DelegateSignature(bool IsSuccess, const struct FString& Token)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.Translator.OnGetAccessToken__DelegateSignature");

	UTranslator_OnGetAccessToken__DelegateSignature_Params params;
	params.IsSuccess = IsSuccess;
	params.Token = Token;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.OnGetAccessToken
// ()
// Parameters:
// bool                           Success                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Data                           (Parm, ZeroConstructor)

void UTranslator::OnGetAccessToken(bool Success, const struct FString& Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.OnGetAccessToken");

	UTranslator_OnGetAccessToken_Params params;
	params.Success = Success;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.OnDetectV2
// ()
// Parameters:
// bool                           Success                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Data                           (Parm, ZeroConstructor)

void UTranslator::OnDetectV2(bool Success, const struct FString& Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.OnDetectV2");

	UTranslator_OnDetectV2_Params params;
	params.Success = Success;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.Translator.OnDetect__DelegateSignature
// ()
// Parameters:
// bool                           IsSuccess                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 from                           (Parm, ZeroConstructor)
// struct FString                 to                             (Parm, ZeroConstructor)

void UTranslator::OnDetect__DelegateSignature(bool IsSuccess, const struct FString& from, const struct FString& to)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.Translator.OnDetect__DelegateSignature");

	UTranslator_OnDetect__DelegateSignature_Params params;
	params.IsSuccess = IsSuccess;
	params.from = from;
	params.to = to;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.OnDetect
// ()
// Parameters:
// bool                           Success                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Data                           (Parm, ZeroConstructor)

void UTranslator::OnDetect(bool Success, const struct FString& Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.OnDetect");

	UTranslator_OnDetect_Params params;
	params.Success = Success;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.HasTranslating
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UTranslator::HasTranslating()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.HasTranslating");

	UTranslator_HasTranslating_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.Translator.GetAccessToken
// ()
// Parameters:
// bool                           bForceGet                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 URL                            (Parm, ZeroConstructor)
// struct FString                 Verb                           (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> Headers                        (ConstParm, Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UTranslator::GetAccessToken(bool bForceGet, const struct FString& URL, const struct FString& Verb, TMap<struct FString, struct FString> Headers, const struct FString& Content)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.GetAccessToken");

	UTranslator_GetAccessToken_Params params;
	params.bForceGet = bForceGet;
	params.URL = URL;
	params.Verb = Verb;
	params.Headers = Headers;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.Translator.Detect
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)
// struct FString                 Verb                           (Parm, ZeroConstructor)
// TMap<struct FString, struct FString> Headers                        (ConstParm, Parm, ZeroConstructor)
// struct FString                 Content                        (Parm, ZeroConstructor)

void UTranslator::Detect(const struct FString& URL, const struct FString& Verb, TMap<struct FString, struct FString> Headers, const struct FString& Content)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.Translator.Detect");

	UTranslator_Detect_Params params;
	params.URL = URL;
	params.Verb = Verb;
	params.Headers = Headers;
	params.Content = Content;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.TssManager.SendSkdData_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UTssManager::SendSkdData_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TssManager.SendSkdData_LuaState");

	UTssManager_SendSkdData_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TssManager.SendEigeninfoData_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UTssManager::SendEigeninfoData_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TssManager.SendEigeninfoData_LuaState");

	UTssManager_SendEigeninfoData_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TssManager.SaveSendEigeninfoCode_LuaState
// ()
// Parameters:
// uint32_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint32_t UTssManager::SaveSendEigeninfoCode_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TssManager.SaveSendEigeninfoCode_LuaState");

	UTssManager_SaveSendEigeninfoCode_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TssManager.OnRecvData_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UTssManager::OnRecvData_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TssManager.OnRecvData_LuaState");

	UTssManager_OnRecvData_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TssManager.GetUserTag4Lua_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UTssManager::GetUserTag4Lua_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TssManager.GetUserTag4Lua_LuaState");

	UTssManager_GetUserTag4Lua_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TssManager.GetDeviceFeature_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UTssManager::GetDeviceFeature_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TssManager.GetDeviceFeature_LuaState");

	UTssManager_GetDeviceFeature_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.TssManager.EigenArrayObfuscationVerify_LuaState
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UTssManager::EigenArrayObfuscationVerify_LuaState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.TssManager.EigenArrayObfuscationVerify_LuaState");

	UTssManager_EigenArrayObfuscationVerify_LuaState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.UTRichTextBlock.SetText
// ()
// Parameters:
// struct FText                   InText                         (Parm)

void UUTRichTextBlock::SetText(const struct FText& InText)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UTRichTextBlock.SetText");

	UUTRichTextBlock_SetText_Params params;
	params.InText = InText;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.UTRichTextBlock.SetGameFrontendHUD
// ()
// Parameters:
// class UGameFrontendHUD*        InHUD                          (Parm, ZeroConstructor, IsPlainOldData)

void UUTRichTextBlock::SetGameFrontendHUD(class UGameFrontendHUD* InHUD)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UTRichTextBlock.SetGameFrontendHUD");

	UUTRichTextBlock_SetGameFrontendHUD_Params params;
	params.InHUD = InHUD;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.UTRichTextBlock.OnHyperlinkClickedEvent__DelegateSignature
// ()
// Parameters:
// struct FMetaDataHolder         MetaDataHolder                 (ConstParm, Parm, OutParm, ReferenceParm)

void UUTRichTextBlock::OnHyperlinkClickedEvent__DelegateSignature(const struct FMetaDataHolder& MetaDataHolder)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.UTRichTextBlock.OnHyperlinkClickedEvent__DelegateSignature");

	UUTRichTextBlock_OnHyperlinkClickedEvent__DelegateSignature_Params params;
	params.MetaDataHolder = MetaDataHolder;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.UTRichTextBlock.GetText
// ()
// Parameters:
// struct FText                   ReturnValue                    (Parm, OutParm, ReturnParm)

struct FText UUTRichTextBlock::GetText()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UTRichTextBlock.GetText");

	UUTRichTextBlock_GetText_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.AEVarButton.SetTouchMethod
// ()
// Parameters:
// TEnumAsByte<EButtonTouchMethod> InTouchMethod                  (Parm, ZeroConstructor, IsPlainOldData)

void UAEVarButton::SetTouchMethod(TEnumAsByte<EButtonTouchMethod> InTouchMethod)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AEVarButton.SetTouchMethod");

	UAEVarButton_SetTouchMethod_Params params;
	params.InTouchMethod = InTouchMethod;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AEVarButton.SetStyle
// ()
// Parameters:
// struct FButtonStyle            InStyle                        (ConstParm, Parm, OutParm, ReferenceParm)

void UAEVarButton::SetStyle(const struct FButtonStyle& InStyle)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AEVarButton.SetStyle");

	UAEVarButton_SetStyle_Params params;
	params.InStyle = InStyle;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AEVarButton.SetColorAndOpacity
// ()
// Parameters:
// struct FLinearColor            InColorAndOpacity              (Parm, IsPlainOldData)

void UAEVarButton::SetColorAndOpacity(const struct FLinearColor& InColorAndOpacity)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AEVarButton.SetColorAndOpacity");

	UAEVarButton_SetColorAndOpacity_Params params;
	params.InColorAndOpacity = InColorAndOpacity;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AEVarButton.SetClickMethod
// ()
// Parameters:
// TEnumAsByte<EButtonClickMethod> InClickMethod                  (Parm, ZeroConstructor, IsPlainOldData)

void UAEVarButton::SetClickMethod(TEnumAsByte<EButtonClickMethod> InClickMethod)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AEVarButton.SetClickMethod");

	UAEVarButton_SetClickMethod_Params params;
	params.InClickMethod = InClickMethod;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AEVarButton.SetBackgroundColor
// ()
// Parameters:
// struct FLinearColor            InBackgroundColor              (Parm, IsPlainOldData)

void UAEVarButton::SetBackgroundColor(const struct FLinearColor& InBackgroundColor)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AEVarButton.SetBackgroundColor");

	UAEVarButton_SetBackgroundColor_Params params;
	params.InBackgroundColor = InBackgroundColor;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.AEVarButton.IsPressed
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UAEVarButton::IsPressed()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.AEVarButton.IsPressed");

	UAEVarButton_IsPressed_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseFallC.SetScrollOffset
// ()
// Parameters:
// float                          NewScrollOffset                (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::SetScrollOffset(float NewScrollOffset)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.SetScrollOffset");

	UReuseFallC_SetScrollOffset_Params params;
	params.NewScrollOffset = NewScrollOffset;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.SetItemSize
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)
// float                          __Size                         (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::SetItemSize(int __Idx, float __Size)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.SetItemSize");

	UReuseFallC_SetItemSize_Params params;
	params.__Idx = __Idx;
	params.__Size = __Size;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.SetItemFullStyle
// ()
// Parameters:
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::SetItemFullStyle(int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.SetItemFullStyle");

	UReuseFallC_SetItemFullStyle_Params params;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.SetCurItemClass
// ()
// Parameters:
// struct FString                 StrName                        (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UReuseFallC::SetCurItemClass(const struct FString& StrName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.SetCurItemClass");

	UReuseFallC_SetCurItemClass_Params params;
	params.StrName = StrName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseFallC.ScrollToStart
// ()

void UReuseFallC::ScrollToStart()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.ScrollToStart");

	UReuseFallC_ScrollToStart_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.ScrollToEnd
// ()

void UReuseFallC::ScrollToEnd()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.ScrollToEnd");

	UReuseFallC_ScrollToEnd_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.ResetCurItemClassToDefault
// ()

void UReuseFallC::ResetCurItemClassToDefault()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.ResetCurItemClassToDefault");

	UReuseFallC_ResetCurItemClassToDefault_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.Reload
// ()
// Parameters:
// int                            __ItemCount                    (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::Reload(int __ItemCount)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.Reload");

	UReuseFallC_Reload_Params params;
	params.__ItemCount = __ItemCount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.RefreshOne
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::RefreshOne(int __Idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.RefreshOne");

	UReuseFallC_RefreshOne_Params params;
	params.__Idx = __Idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.Refresh
// ()

void UReuseFallC::Refresh()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.Refresh");

	UReuseFallC_Refresh_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseFallC.OnUpdateItemDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::OnUpdateItemDelegate__DelegateSignature(class UUserWidget* Widget, int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseFallC.OnUpdateItemDelegate__DelegateSignature");

	UReuseFallC_OnUpdateItemDelegate__DelegateSignature_Params params;
	params.Widget = Widget;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseFallC.OnTouchFinishDelegate__DelegateSignature
// ()

void UReuseFallC::OnTouchFinishDelegate__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseFallC.OnTouchFinishDelegate__DelegateSignature");

	UReuseFallC_OnTouchFinishDelegate__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.OnTouchFinishCallback
// ()

void UReuseFallC::OnTouchFinishCallback()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.OnTouchFinishCallback");

	UReuseFallC_OnTouchFinishCallback_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseFallC.OnOverscrollStateDelegate__DelegateSignature
// ()
// Parameters:
// EReuseFallOverscrollState      State                          (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::OnOverscrollStateDelegate__DelegateSignature(EReuseFallOverscrollState State)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseFallC.OnOverscrollStateDelegate__DelegateSignature");

	UReuseFallC_OnOverscrollStateDelegate__DelegateSignature_Params params;
	params.State = State;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseFallC.OnCreateItemDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::OnCreateItemDelegate__DelegateSignature(class UUserWidget* Widget, int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseFallC.OnCreateItemDelegate__DelegateSignature");

	UReuseFallC_OnCreateItemDelegate__DelegateSignature_Params params;
	params.Widget = Widget;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseFallC.OnBeforeNewItemDelegate__DelegateSignature
// ()
// Parameters:
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::OnBeforeNewItemDelegate__DelegateSignature(int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseFallC.OnBeforeNewItemDelegate__DelegateSignature");

	UReuseFallC_OnBeforeNewItemDelegate__DelegateSignature_Params params;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseFallC.OnAfterNewItemDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::OnAfterNewItemDelegate__DelegateSignature(class UUserWidget* Widget, int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseFallC.OnAfterNewItemDelegate__DelegateSignature");

	UReuseFallC_OnAfterNewItemDelegate__DelegateSignature_Params params;
	params.Widget = Widget;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.JumpByIdx
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bImmedia                       (Parm, ZeroConstructor, IsPlainOldData)

void UReuseFallC::JumpByIdx(int __Idx, bool bImmedia)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.JumpByIdx");

	UReuseFallC_JumpByIdx_Params params;
	params.__Idx = __Idx;
	params.bImmedia = bImmedia;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.GetViewSize
// ()
// Parameters:
// struct FVector2D               ReturnValue                    (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)

struct FVector2D UReuseFallC::GetViewSize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.GetViewSize");

	UReuseFallC_GetViewSize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseFallC.GetScrollOffset
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UReuseFallC::GetScrollOffset()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.GetScrollOffset");

	UReuseFallC_GetScrollOffset_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseFallC.GetOverscrollState
// ()
// Parameters:
// EReuseFallOverscrollState      ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EReuseFallOverscrollState UReuseFallC::GetOverscrollState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.GetOverscrollState");

	UReuseFallC_GetOverscrollState_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseFallC.GetContentSize
// ()
// Parameters:
// struct FVector2D               ReturnValue                    (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)

struct FVector2D UReuseFallC::GetContentSize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.GetContentSize");

	UReuseFallC_GetContentSize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseFallC.ClearItemFullStyle
// ()

void UReuseFallC::ClearItemFullStyle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.ClearItemFullStyle");

	UReuseFallC_ClearItemFullStyle_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseFallC.Clear
// ()

void UReuseFallC::Clear()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseFallC.Clear");

	UReuseFallC_Clear_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.SetTitleSlotAutoSize
// ()
// Parameters:
// bool                           as                             (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::SetTitleSlotAutoSize(bool as)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.SetTitleSlotAutoSize");

	UReuseListC_SetTitleSlotAutoSize_Params params;
	params.as = as;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.SetTitleSize
// ()
// Parameters:
// int                            sz                             (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::SetTitleSize(int sz)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.SetTitleSize");

	UReuseListC_SetTitleSize_Params params;
	params.sz = sz;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.SetScrollOffset
// ()
// Parameters:
// float                          NewScrollOffset                (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::SetScrollOffset(float NewScrollOffset)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.SetScrollOffset");

	UReuseListC_SetScrollOffset_Params params;
	params.NewScrollOffset = NewScrollOffset;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.ScrollToStart
// ()

void UReuseListC::ScrollToStart()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.ScrollToStart");

	UReuseListC_ScrollToStart_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.ScrollToEnd
// ()

void UReuseListC::ScrollToEnd()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.ScrollToEnd");

	UReuseListC_ScrollToEnd_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.Reset
// ()
// Parameters:
// class UClass*                  __ItemClass                    (Parm, ZeroConstructor, IsPlainOldData)
// EReuseListStyle                __Style                        (Parm, ZeroConstructor, IsPlainOldData)
// int                            __ItemWidth                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            __ItemHeight                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            __PaddingX                     (Parm, ZeroConstructor, IsPlainOldData)
// int                            __PaddingY                     (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::Reset(class UClass* __ItemClass, EReuseListStyle __Style, int __ItemWidth, int __ItemHeight, int __PaddingX, int __PaddingY)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.Reset");

	UReuseListC_Reset_Params params;
	params.__ItemClass = __ItemClass;
	params.__Style = __Style;
	params.__ItemWidth = __ItemWidth;
	params.__ItemHeight = __ItemHeight;
	params.__PaddingX = __PaddingX;
	params.__PaddingY = __PaddingY;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.Reload
// ()
// Parameters:
// int                            __ItemCount                    (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::Reload(int __ItemCount)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.Reload");

	UReuseListC_Reload_Params params;
	params.__ItemCount = __ItemCount;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.RefreshParam
// ()
// Parameters:
// struct FString                 _Param                         (Parm, ZeroConstructor)

void UReuseListC::RefreshParam(const struct FString& _Param)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.RefreshParam");

	UReuseListC_RefreshParam_Params params;
	params._Param = _Param;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.RefreshOneParam
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 _Param                         (Parm, ZeroConstructor)

void UReuseListC::RefreshOneParam(int __Idx, const struct FString& _Param)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.RefreshOneParam");

	UReuseListC_RefreshOneParam_Params params;
	params.__Idx = __Idx;
	params._Param = _Param;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.RefreshOne
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::RefreshOne(int __Idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.RefreshOne");

	UReuseListC_RefreshOne_Params params;
	params.__Idx = __Idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.Refresh
// ()

void UReuseListC::Refresh()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.Refresh");

	UReuseListC_Refresh_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseListC.OnUpdateItemParamDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Param                          (Parm, ZeroConstructor)

void UReuseListC::OnUpdateItemParamDelegate__DelegateSignature(class UUserWidget* Widget, int idx, const struct FString& Param)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseListC.OnUpdateItemParamDelegate__DelegateSignature");

	UReuseListC_OnUpdateItemParamDelegate__DelegateSignature_Params params;
	params.Widget = Widget;
	params.idx = idx;
	params.Param = Param;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseListC.OnUpdateItemDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::OnUpdateItemDelegate__DelegateSignature(class UUserWidget* Widget, int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseListC.OnUpdateItemDelegate__DelegateSignature");

	UReuseListC_OnUpdateItemDelegate__DelegateSignature_Params params;
	params.Widget = Widget;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseListC.OnScrollItemDelegate__DelegateSignature
// ()
// Parameters:
// int                            BeginIdx                       (Parm, ZeroConstructor, IsPlainOldData)
// int                            EndIdx                         (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::OnScrollItemDelegate__DelegateSignature(int BeginIdx, int EndIdx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseListC.OnScrollItemDelegate__DelegateSignature");

	UReuseListC_OnScrollItemDelegate__DelegateSignature_Params params;
	params.BeginIdx = BeginIdx;
	params.EndIdx = EndIdx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReuseListC.OnCreateItemDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UReuseListC::OnCreateItemDelegate__DelegateSignature(class UUserWidget* Widget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReuseListC.OnCreateItemDelegate__DelegateSignature");

	UReuseListC_OnCreateItemDelegate__DelegateSignature_Params params;
	params.Widget = Widget;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.JumpByIdxStyle
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)
// EReuseListJumpStyle            __Style                        (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::JumpByIdxStyle(int __Idx, EReuseListJumpStyle __Style)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.JumpByIdxStyle");

	UReuseListC_JumpByIdxStyle_Params params;
	params.__Idx = __Idx;
	params.__Style = __Style;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.JumpByIdx
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)

void UReuseListC::JumpByIdx(int __Idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.JumpByIdx");

	UReuseListC_JumpByIdx_Params params;
	params.__Idx = __Idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReuseListC.GetViewSize
// ()
// Parameters:
// struct FVector2D               ReturnValue                    (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)

struct FVector2D UReuseListC::GetViewSize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetViewSize");

	UReuseListC_GetViewSize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetScrollOffset
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UReuseListC::GetScrollOffset()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetScrollOffset");

	UReuseListC_GetScrollOffset_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetPaddingY
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReuseListC::GetPaddingY()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetPaddingY");

	UReuseListC_GetPaddingY_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetPaddingX
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReuseListC::GetPaddingX()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetPaddingX");

	UReuseListC_GetPaddingX_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetItemWidthAndPaddingX
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReuseListC::GetItemWidthAndPaddingX()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetItemWidthAndPaddingX");

	UReuseListC_GetItemWidthAndPaddingX_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetItemWidth
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReuseListC::GetItemWidth()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetItemWidth");

	UReuseListC_GetItemWidth_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetItemHeightAndPaddingY
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReuseListC::GetItemHeightAndPaddingY()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetItemHeightAndPaddingY");

	UReuseListC_GetItemHeightAndPaddingY_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetItemHeight
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReuseListC::GetItemHeight()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetItemHeight");

	UReuseListC_GetItemHeight_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetContentSize
// ()
// Parameters:
// struct FVector2D               ReturnValue                    (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)

struct FVector2D UReuseListC::GetContentSize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetContentSize");

	UReuseListC_GetContentSize_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.GetAllWidgetItems
// ()
// Parameters:
// TArray<class UUserWidget*>     ResultItemList                 (Parm, OutParm, ZeroConstructor)

void UReuseListC::GetAllWidgetItems(TArray<class UUserWidget*>* ResultItemList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.GetAllWidgetItems");

	UReuseListC_GetAllWidgetItems_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ResultItemList != nullptr)
		*ResultItemList = params.ResultItemList;
}


// Function Client.ReuseListC.FindItem
// ()
// Parameters:
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)
// class UUserWidget*             ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UUserWidget* UReuseListC::FindItem(int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.FindItem");

	UReuseListC_FindItem_Params params;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReuseListC.Clear
// ()

void UReuseListC::Clear()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReuseListC.Clear");

	UReuseListC_Clear_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReusePageC.SetAutoPlayRate
// ()
// Parameters:
// float                          Rate                           (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::SetAutoPlayRate(float Rate)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.SetAutoPlayRate");

	UReusePageC_SetAutoPlayRate_Params params;
	params.Rate = Rate;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReusePageC.SelectPage
// ()
// Parameters:
// int                            __Idx                          (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::SelectPage(int __Idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.SelectPage");

	UReusePageC_SelectPage_Params params;
	params.__Idx = __Idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReusePageC.Reload
// ()
// Parameters:
// int                            __Count                        (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::Reload(int __Count)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.Reload");

	UReusePageC_Reload_Params params;
	params.__Count = __Count;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReusePageC.Play
// ()
// Parameters:
// bool                           bPlay                          (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::Play(bool bPlay)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.Play");

	UReusePageC_Play_Params params;
	params.bPlay = bPlay;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReusePageC.OnUpdateItemDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// int                            idx                            (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::OnUpdateItemDelegate__DelegateSignature(class UUserWidget* Widget, int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReusePageC.OnUpdateItemDelegate__DelegateSignature");

	UReusePageC_OnUpdateItemDelegate__DelegateSignature_Params params;
	params.Widget = Widget;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReusePageC.OnPageChangedDelegate__DelegateSignature
// ()
// Parameters:
// int                            PageIdx                        (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::OnPageChangedDelegate__DelegateSignature(int PageIdx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReusePageC.OnPageChangedDelegate__DelegateSignature");

	UReusePageC_OnPageChangedDelegate__DelegateSignature_Params params;
	params.PageIdx = PageIdx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReusePageC.OnEndScrollDelegate__DelegateSignature
// ()
// Parameters:
// int                            PageIdx                        (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::OnEndScrollDelegate__DelegateSignature(int PageIdx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReusePageC.OnEndScrollDelegate__DelegateSignature");

	UReusePageC_OnEndScrollDelegate__DelegateSignature_Params params;
	params.PageIdx = PageIdx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReusePageC.OnEndDragDelegate__DelegateSignature
// ()
// Parameters:
// int                            PageIdx                        (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::OnEndDragDelegate__DelegateSignature(int PageIdx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReusePageC.OnEndDragDelegate__DelegateSignature");

	UReusePageC_OnEndDragDelegate__DelegateSignature_Params params;
	params.PageIdx = PageIdx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReusePageC.OnCreateItemDelegate__DelegateSignature
// ()
// Parameters:
// class UUserWidget*             Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UReusePageC::OnCreateItemDelegate__DelegateSignature(class UUserWidget* Widget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReusePageC.OnCreateItemDelegate__DelegateSignature");

	UReusePageC_OnCreateItemDelegate__DelegateSignature_Params params;
	params.Widget = Widget;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.ReusePageC.OnBeginDragDelegate__DelegateSignature
// ()

void UReusePageC::OnBeginDragDelegate__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.ReusePageC.OnBeginDragDelegate__DelegateSignature");

	UReusePageC_OnBeginDragDelegate__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReusePageC.MovePrePage
// ()

void UReusePageC::MovePrePage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.MovePrePage");

	UReusePageC_MovePrePage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReusePageC.MoveNextPage
// ()

void UReusePageC::MoveNextPage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.MoveNextPage");

	UReusePageC_MoveNextPage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.ReusePageC.IsDraging
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UReusePageC::IsDraging()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.IsDraging");

	UReusePageC_IsDraging_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReusePageC.GetPageCount
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReusePageC::GetPageCount()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.GetPageCount");

	UReusePageC_GetPageCount_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReusePageC.GetPage
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UReusePageC::GetPage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.GetPage");

	UReusePageC_GetPage_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReusePageC.GetOffset
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UReusePageC::GetOffset()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.GetOffset");

	UReusePageC_GetOffset_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReusePageC.GetAutoPlayRate
// ()
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UReusePageC::GetAutoPlayRate()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.GetAutoPlayRate");

	UReusePageC_GetAutoPlayRate_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.ReusePageC.GetAllItems
// ()
// Parameters:
// TArray<class UUserWidget*>     ResultItemList                 (Parm, OutParm, ZeroConstructor)
// bool                           OnlyVisible                    (Parm, ZeroConstructor, IsPlainOldData)

void UReusePageC::GetAllItems(bool OnlyVisible, TArray<class UUserWidget*>* ResultItemList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.GetAllItems");

	UReusePageC_GetAllItems_Params params;
	params.OnlyVisible = OnlyVisible;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (ResultItemList != nullptr)
		*ResultItemList = params.ResultItemList;
}


// Function Client.ReusePageC.ClearCache
// ()

void UReusePageC::ClearCache()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.ReusePageC.ClearCache");

	UReusePageC_ClearCache_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.UDPPingCollector.TickUDPPing
// ()
// Parameters:
// float                          DeltaTime                      (Parm, ZeroConstructor, IsPlainOldData)

void UUDPPingCollector::TickUDPPing(float DeltaTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.TickUDPPing");

	UUDPPingCollector_TickUDPPing_Params params;
	params.DeltaTime = DeltaTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.UDPPingCollector.setUDPPingServerAddress
// ()
// Parameters:
// struct FString                 ServerIP                       (Parm, ZeroConstructor)
// struct FString                 ServerPort                     (Parm, ZeroConstructor)
// int                            ZoneID                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            WaterMarkType                  (Parm, ZeroConstructor, IsPlainOldData)

void UUDPPingCollector::setUDPPingServerAddress(const struct FString& ServerIP, const struct FString& ServerPort, int ZoneID, int WaterMarkType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.setUDPPingServerAddress");

	UUDPPingCollector_setUDPPingServerAddress_Params params;
	params.ServerIP = ServerIP;
	params.ServerPort = ServerPort;
	params.ZoneID = ZoneID;
	params.WaterMarkType = WaterMarkType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.UDPPingCollector.PingServer
// ()
// Parameters:
// struct FString                 address                        (Parm, ZeroConstructor)
// float                          Timeout                        (Parm, ZeroConstructor, IsPlainOldData)
// int                            WaterMarkType                  (Parm, ZeroConstructor, IsPlainOldData)

void UUDPPingCollector::PingServer(const struct FString& address, float Timeout, int WaterMarkType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.PingServer");

	UUDPPingCollector_PingServer_Params params;
	params.address = address;
	params.Timeout = Timeout;
	params.WaterMarkType = WaterMarkType;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.UDPPingCollector.OnPingServerResultDelegate__DelegateSignature
// ()
// Parameters:
// struct FString                 address                        (Parm, ZeroConstructor)
// int                            IsSuccess                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          Time                           (Parm, ZeroConstructor, IsPlainOldData)

void UUDPPingCollector::OnPingServerResultDelegate__DelegateSignature(const struct FString& address, int IsSuccess, float Time)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.UDPPingCollector.OnPingServerResultDelegate__DelegateSignature");

	UUDPPingCollector_OnPingServerResultDelegate__DelegateSignature_Params params;
	params.address = address;
	params.IsSuccess = IsSuccess;
	params.Time = Time;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.UDPPingCollector.IsChooingZoneAccess
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UUDPPingCollector::IsChooingZoneAccess()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.IsChooingZoneAccess");

	UUDPPingCollector_IsChooingZoneAccess_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.UDPPingCollector.isAllZoneHasPingValue
// ()
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UUDPPingCollector::isAllZoneHasPingValue()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.isAllZoneHasPingValue");

	UUDPPingCollector_isAllZoneHasPingValue_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.UDPPingCollector.Init
// ()
// Parameters:
// float                          MinPingintervalTime            (Parm, ZeroConstructor, IsPlainOldData)
// float                          pingintervalTime               (Parm, ZeroConstructor, IsPlainOldData)
// float                          pingTimeoutSecond              (Parm, ZeroConstructor, IsPlainOldData)
// float                          normalDelayMilliSecond         (Parm, ZeroConstructor, IsPlainOldData)
// float                          maxAutoChooseZoneDelayMilliSecond (Parm, ZeroConstructor, IsPlainOldData)

void UUDPPingCollector::Init(float MinPingintervalTime, float pingintervalTime, float pingTimeoutSecond, float normalDelayMilliSecond, float maxAutoChooseZoneDelayMilliSecond)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.Init");

	UUDPPingCollector_Init_Params params;
	params.MinPingintervalTime = MinPingintervalTime;
	params.pingintervalTime = pingintervalTime;
	params.pingTimeoutSecond = pingTimeoutSecond;
	params.normalDelayMilliSecond = normalDelayMilliSecond;
	params.maxAutoChooseZoneDelayMilliSecond = maxAutoChooseZoneDelayMilliSecond;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.UDPPingCollector.GetZoneServerDelay
// ()
// Parameters:
// struct FString                 ServerAddress                  (Parm, ZeroConstructor)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UUDPPingCollector::GetZoneServerDelay(const struct FString& ServerAddress)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.GetZoneServerDelay");

	UUDPPingCollector_GetZoneServerDelay_Params params;
	params.ServerAddress = ServerAddress;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.UDPPingCollector.GetMinDealyAddress
// ()
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UUDPPingCollector::GetMinDealyAddress()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.GetMinDealyAddress");

	UUDPPingCollector_GetMinDealyAddress_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function Client.UDPPingCollector.ChoosingZone
// ()
// Parameters:
// int                            ZoneID                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 AddrIP                         (Parm, ZeroConstructor)

void UUDPPingCollector::ChoosingZone(int ZoneID, const struct FString& AddrIP)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.UDPPingCollector.ChoosingZone");

	UUDPPingCollector_ChoosingZone_Params params;
	params.ZoneID = ZoneID;
	params.AddrIP = AddrIP;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.WINSDKFBWebLogin.OnWINSDKHttpResponed__DelegateSignature
// ()
// Parameters:
// bool                           requestSucc                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 txtContent                     (Parm, ZeroConstructor)

void UWINSDKFBWebLogin::OnWINSDKHttpResponed__DelegateSignature(bool requestSucc, const struct FString& txtContent)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.WINSDKFBWebLogin.OnWINSDKHttpResponed__DelegateSignature");

	UWINSDKFBWebLogin_OnWINSDKHttpResponed__DelegateSignature_Params params;
	params.requestSucc = requestSucc;
	params.txtContent = txtContent;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction Client.WINSDKFBWebLogin.OnUrlChanged__DelegateSignature
// ()
// Parameters:
// struct FText                   Text                           (ConstParm, Parm, OutParm, ReferenceParm)

void UWINSDKFBWebLogin::OnUrlChanged__DelegateSignature(const struct FText& Text)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction Client.WINSDKFBWebLogin.OnUrlChanged__DelegateSignature");

	UWINSDKFBWebLogin_OnUrlChanged__DelegateSignature_Params params;
	params.Text = Text;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.WINSDKFBWebLogin.LoadURL
// ()
// Parameters:
// struct FString                 NewURL                         (Parm, ZeroConstructor)

void UWINSDKFBWebLogin::LoadURL(const struct FString& NewURL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.WINSDKFBWebLogin.LoadURL");

	UWINSDKFBWebLogin_LoadURL_Params params;
	params.NewURL = NewURL;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Client.WINSDKFBWebLogin.DoHttpRequest
// ()
// Parameters:
// struct FString                 URL                            (Parm, ZeroConstructor)

void UWINSDKFBWebLogin::DoHttpRequest(const struct FString& URL)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Client.WINSDKFBWebLogin.DoHttpRequest");

	UWINSDKFBWebLogin_DoHttpRequest_Params params;
	params.URL = URL;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

