#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function GlobalLuaWidget.GlobalLuaWidget_C.GetNewLevelTaskData
struct UGlobalLuaWidget_C_GetNewLevelTaskData_Params
{
	struct FString                                     TaskId;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	bool                                               Has;                                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FBP_STRUCT_NewLevelTask_type                BP_STRUCT_NewLevelTask_type;                              // (Parm, OutParm)
};

}

