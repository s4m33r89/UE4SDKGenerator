#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Editor_login.Editor_login_C.SetFpsByIndex
struct AEditor_login_C_SetFpsByIndex_Params
{
	int                                                idx;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Editor_login.Editor_login_C.InpActEvt_Android_Back_K2Node_InputKeyEvent_2
struct AEditor_login_C_InpActEvt_Android_Back_K2Node_InputKeyEvent_2_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.ReceiveBeginPlay
struct AEditor_login_C_ReceiveBeginPlay_Params
{
};

// Function Editor_login.Editor_login_C.ExecuteUbergraph_Editor_login
struct AEditor_login_C_ExecuteUbergraph_Editor_login_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

