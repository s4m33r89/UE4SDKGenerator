#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_CorpsConfig_type.BP_STRUCT_CorpsConfig_type
// 0x0020
struct FBP_STRUCT_CorpsConfig_type
{
	struct FString                                     ConfigValue_0_306151800211D5305EAE9A9700E1D6A5;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ConfigName_1_72343280216367E6602CC642010A9D65;            // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

