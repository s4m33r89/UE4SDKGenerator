#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass Global_Bp.Global_Bp_C
// 0x0120 (0x04F0 - 0x03D0)
class UGlobal_Bp_C : public UUAEUserWidget
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x03D0(0x0008) (Transient, DuplicateTransient)
	class USettingConfig_C*                            SettingConfigObject;                                      // 0x03D8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TMap<struct FString, class UTexture2D*>            corpsIconTextureMap;                                      // 0x03E0(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class Abp_global_C*                                bp_global;                                                // 0x0430(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData)
	TMap<struct FString, class UTexture2D*>            rankTextureMap;                                           // 0x0438(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<int, class UUserWidget*>                      dragDropItemMap;                                          // 0x0488(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	bool                                               isPostProcessVolumeInit;                                  // 0x04D8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x04D9(0x0007) MISSED OFFSET
	class APostProcessVolume*                          postProcessClassic;                                       // 0x04E0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData)
	class ACameraPostProcessActor_C*                   cameraPostProcessActor;                                   // 0x04E8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("WidgetBlueprintGeneratedClass Global_Bp.Global_Bp_C");
		return pStaticClass;
	}


	void InitFireGyroSensibilitySettingData(class USettingConfig_C* ServerSettingConfig);
	void MapFromCBToESBH(class USettingConfig_C* SettingConfig);
	void InitMirrorObjMapPickupSetting(class USettingConfig_C* ServerSettingConfig);
	void STATIC_InitThrowObjMapPickupSetting(class USettingConfig_C* ServerSettingConfig);
	void STATIC_InitDrugMapPickupSetting(class USettingConfig_C* ServerSettingConfig);
	void InitBasicSettingData(class USettingConfig_C* ServerSettingConfig);
	void InitPickupSettingData_XT(class USettingConfig_C* SettingConfig);
	void STATIC_InitPickupSettingData(class USettingConfig_C* ServerSettingConfig);
	void STATIC_InitSensibilitySettingData(class USettingConfig_C* ServerSettingConfig);
	void SetGrenadeDefaultPickValue();
	void STATIC_InitMapFromCBToES();
	void MapFromCBToESGlobal(class USettingConfig_C* SettingConfig);
	void STATIC_MapFromCBToESJK(class USettingConfig_C* SettingConfig);
	void STATIC_MapFromCBToESVN(class USettingConfig_C* SettingConfig);
	void STATIC_LoadSettingConfigFromSlot();
	void UpdateBigHandOperateRedPoint();
	void STATIC_SetPostProcessSettings(int ID, float Time, bool isReverse, bool isClosing);
	void DestroyLobbyCameras();
	void STATIC_GetShadowDistanceScale();
	void STATIC_SetShadowDistanceScale();
	void ShowItemPreviewPress();
	void STATIC_ShowItemPreviewClick(int ItemId);
	void STATIC_TryLoadAdvertise();
	void STATIC_SaveAnniversaryNeedShow();
	void GetAnniversaryNeedShow();
	void STATIC_SaveResidentEvilNeedShow();
	void GetResidentEvilNeedShow();
	void SaveLobbySkinID();
	void STATIC_SaveChristmasNeedShow();
	void GetChristmasNeedShow();
	void SaveRechargePayPos();
	void GetRechargePayPos();
	void SaveMallShow10Animation();
	void GetMallShow10Animation();
	void STATIC_GetLocalizeStringWithNum();
	void GetLobbySkinIDAndBgmID();
	void SwitchLobbyMeshBg();
	void SwitchWarzoneCamera();
	void STATIC_LoadAdvertise();
	void STATIC_PlayAdvertise();
	void STATIC_SetGlobalConfigData();
	void GetGlobalConfigData();
	void SwitchCameraFarImmediate();
	void SwitchWarzoneBG();
	void GetDragDropWidget(int dragDropType);
	void GetRankTexture(int rankIntegral, class UTexture2D** Output);
	void STATIC_SetCorpsShopRedPoint();
	void GetCorpsIconTexture(int IconID, class UTexture2D** Value);
	void GetFrameTexture(int frameLevel, class UTexture2D** Output);
	void STATIC_EnterCreateRoleDelay();
	void EnterCreateRole();
	void STATIC_EnterFightStopMusic();
	void EventAndroidQuitGame();
	void QuitGame();
	void STATIC_EnterLobby();
	void EnterLogin();
	void Construct();
	void LockLobbyMaxFps();
	void RecoverMaxFps();
	void SwitchLobbySkin();
	void ExecuteUbergraph_Global_Bp(int EntryPoint);
};


}

