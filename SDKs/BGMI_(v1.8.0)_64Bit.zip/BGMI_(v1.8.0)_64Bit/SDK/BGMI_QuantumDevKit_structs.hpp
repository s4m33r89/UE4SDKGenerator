#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum QuantumDevKit.EQuantumFirebaseRemoteConfigStatus
enum class EQuantumFirebaseRemoteConfigStatus : uint8_t
{
	EQuantumFirebaseRemoteConfigStatus__kUnfetched = 0,
	EQuantumFirebaseRemoteConfigStatus__kFetchedSuccessfully = 1,
	EQuantumFirebaseRemoteConfigStatus__kFetchedFailed = 2,
	EQuantumFirebaseRemoteConfigStatus__EQuantumFirebaseRemoteConfigStatus_MAX = 3
};



}

