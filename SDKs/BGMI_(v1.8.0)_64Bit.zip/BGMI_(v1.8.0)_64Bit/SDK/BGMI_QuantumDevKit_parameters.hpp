#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetStatus
struct UQuantumFirebaseRemoteConfig_GetStatus_Params
{
	EQuantumFirebaseRemoteConfigStatus                 ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetRemoteConfig
struct UQuantumFirebaseRemoteConfig_GetRemoteConfig_Params
{
	struct FString                                     ConfigNameToQuery;                                        // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetInstance
struct UQuantumFirebaseRemoteConfig_GetInstance_Params
{
	class UQuantumFirebaseRemoteConfig*                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

