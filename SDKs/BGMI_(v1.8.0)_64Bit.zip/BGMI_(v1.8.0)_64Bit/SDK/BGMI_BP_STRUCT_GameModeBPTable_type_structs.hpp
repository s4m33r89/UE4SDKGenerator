#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_GameModeBPTable_type.BP_STRUCT_GameModeBPTable_type
// 0x0028
struct FBP_STRUCT_GameModeBPTable_type
{
	int                                                ID_0_5A5311F84AF5AD63F284598DF413D62D;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     CName_1_120D6DB74537DE28D87E4BAD2052E558;                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_2_D808EF6946A66B7E51F6318FC7CCE098;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

