#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LocalizeRes_type.BP_STRUCT_LocalizeRes_type
// 0x0014
struct FBP_STRUCT_LocalizeRes_type
{
	struct FString                                     TextValue_0_4D37165A410D67320AF278A1C1028E4F;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TextId_1_20B947934F165858A322E599888F816E;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

