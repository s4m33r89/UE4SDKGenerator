#pragma once

// Battlegrounds Mobile India (1.8.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct PandoraComponent.PandoraLuaBPVar
// 0x0020
struct FPandoraLuaBPVar
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0000(0x0020) MISSED OFFSET
};

}

